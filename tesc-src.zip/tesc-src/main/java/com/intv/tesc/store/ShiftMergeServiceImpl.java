package com.intv.tesc.store;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Service to merge overlapping or contiguous shifts into a consolidated list.
 */
public class ShiftMergeServiceImpl implements ShiftMergeService {

	// Helper class representing a time interval.
	private static class Interval {
		int start, end;

		Interval(int start, int end) {
			this.start = start;
			this.end = end;
		}
	}

	@Override
	public List<ShiftTime> merge(List<ShiftTime> shifts) {
		if (shifts == null || shifts.isEmpty()) {
			return List.of();
		}

		// Normalize shifts: Handle shifts that span midnight.
		List<Interval> intervals = shifts.stream().map(shift -> {
			int start = shift.getStart();
			int end = shift.getEnd();
			if (start > end) { // Shift spans midnight
				return new Interval(start, end + 24);
			} else {
				return new Interval(start, end);
			}
		}).sorted(Comparator.comparingInt(interval -> interval.start)).toList();

		// Merge overlapping or contiguous intervals.
		List<Interval> mergedIntervals = new ArrayList<>();
		Interval referenceInterval = intervals.get(0);
		mergedIntervals.add(referenceInterval);

		for (int i = 1; i < intervals.size(); i++) {

			Interval current = intervals.get(i);

			// overlapping interval
			if (current.start <= referenceInterval.end) {
				referenceInterval.end = Math.max(referenceInterval.end, current.end);
			} else {
				mergedIntervals.add(current);
				// now currentInterval will act as new referenceInterval
				referenceInterval = current;
			}
		}

		// Convert merged intervals back to ShiftTime, ensuring 0-23 range.
		return mergedIntervals.stream().map(interval -> new ShiftTime(interval.start % 24, interval.end % 24)).toList();
	}
}
