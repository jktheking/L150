package com.intv.tesc.store;

import java.util.List;

/**
 * Dummy implementation of ColleagueShiftRepository.
 */
public class ColleagueShiftRepositoryImpl implements ColleagueShiftRepository {

	@Override
	public List<ShiftTime> getStoreShifts(String empId, String storeId) {
		// TODO: This would typically fetch data from a database.
		return List.of();
	}
}
