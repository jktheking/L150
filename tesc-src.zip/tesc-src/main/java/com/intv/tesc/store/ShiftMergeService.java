package com.intv.tesc.store;

import java.util.List;

/**
 * Interface for merging shift time intervals.
 */
public interface ShiftMergeService {
	List<ShiftTime> merge(List<ShiftTime> shifts);
}
