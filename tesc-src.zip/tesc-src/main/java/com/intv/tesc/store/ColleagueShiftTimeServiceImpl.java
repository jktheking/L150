package com.intv.tesc.store;

import java.util.List;

/**
 * Service implementation to fetch and merge colleague shift times.
 */
public class ColleagueShiftTimeServiceImpl implements ColleagueShiftTimeService {

	private final ColleagueShiftRepository colleagueShiftRepository;
	private final ShiftMergeService shiftMergeService;

	public ColleagueShiftTimeServiceImpl(ColleagueShiftRepository colleagueShiftRepository,
			ShiftMergeService shiftMergeService) {
		this.colleagueShiftRepository = colleagueShiftRepository;
		this.shiftMergeService = shiftMergeService;
	}

	@Override
	public List<ShiftTime> fetchColleagueShifts(String empId, String storeId) {
		List<ShiftTime> shifts = colleagueShiftRepository.getStoreShifts(empId, storeId);
		return shiftMergeService.merge(shifts);
	}
}
