package com.intv.tesc.store;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.intv.tesc.re.BeforeEach;

class ShiftTimeTest {

	private ShiftMergeService shiftMergeService;

	@BeforeEach
	void setUp() {
		shiftMergeService = new ShiftMergeServiceImpl();
	}

	@Test
	void givenNonOverlappingShifts_whenMerged_thenReturnsSameShifts() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(14, 16));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 10), new ShiftTime(14, 16)), result);
	}

	@Test
	void givenOverlappingShifts_whenMerged_thenReturnsMergedShifts() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(9, 12));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}

	@Test
	void givenContiguousShifts_whenMerged_thenReturnsSingleShift() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(10, 12));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}
}
