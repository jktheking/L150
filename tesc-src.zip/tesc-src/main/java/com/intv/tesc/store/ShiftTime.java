package com.intv.tesc.store;

import java.util.Objects;

/**
 * Represents a colleague's work shift with a start and end time. Ensures valid
 * time ranges between 0 and 23 (inclusive).
 */
public class ShiftTime {
	private final int start;
	private final int end;

	public ShiftTime(int start, int end) {
		// Validate that both times are within a 24-hour format.
		if (start < 0 || start >= 24 || end < 0 || end >= 24) {
			throw new IllegalArgumentException("Shift times must be between 0 and 23 inclusive.");
		}
		this.start = start;
		this.end = end;
	}

	public static ShiftTime of(ShiftTime shiftTime) {
		return new ShiftTime(shiftTime.start, shiftTime.end);
	}

	public int getStart() {
		return start;
	}

	public int getEnd() {
		return end;
	}

	@Override
	public String toString() {
		return String.format("ShiftTime [start=%d, end=%d]", start, end);
	}

	@Override
	public int hashCode() {
		return Objects.hash(end, start);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ShiftTime other = (ShiftTime) obj;
		return end == other.end && start == other.start;
	}

}
