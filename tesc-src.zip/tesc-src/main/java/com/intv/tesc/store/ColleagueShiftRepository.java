package com.intv.tesc.store;

import java.util.List;

/**
 * Repository for fetching shift data from storage.
 */
public interface ColleagueShiftRepository {
	List<ShiftTime> getStoreShifts(String empId, String storeId);
}
