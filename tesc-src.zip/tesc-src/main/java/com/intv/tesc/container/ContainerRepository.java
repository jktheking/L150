package com.intv.tesc.container;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ContainerRepository {
	private final List<Container> containers;

	public ContainerRepository(List<Container> containers) {
		this.containers = new ArrayList<>(containers);
	}

	/**
	 * Returns all containers that have a volume greater than or equal to the given
	 * order volume. The list is sorted in ascending order of volume to prioritize
	 * smaller containers first.
	 */
	public List<Container> getSuitableContainers(int orderVolume) {
		return containers.stream().filter(container -> container.getVolume() >= orderVolume)
				.sorted(Comparator.comparingInt(Container::getVolume)).collect(Collectors.toList());
	}
}
