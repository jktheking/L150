package com.intv.tesc.container;

public class ContainerServiceException extends RuntimeException {

	private static final long serialVersionUID = -7980285081168959484L;

	public ContainerServiceException(String message) {
		super(message);
	}

}
