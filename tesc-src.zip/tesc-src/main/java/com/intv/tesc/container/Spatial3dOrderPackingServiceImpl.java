package com.intv.tesc.container;

import java.util.List;

public class Spatial3dOrderPackingServiceImpl implements OrderPackingService {
	private final ContainerRepository containerRepository;

	public Spatial3dOrderPackingServiceImpl(ContainerRepository containerRepository) {
		this.containerRepository = containerRepository;
	}

	@Override
	public String findOptimalContainer(Order order) {
		List<Container> suitableContainers = containerRepository.getSuitableContainers(order.getVolume());

		for (Container container : suitableContainers) {
			int[][][] space = new int[container.getLength()][container.getBreadth()][container.getHeight()];
			if (canFit(order.getItems(), container, space, 0)) {
				return container.getId();
			}
		}
		return "NO_CONTAINER";
	}

	@Override
	public int maxOrdersForContainer(Container container, List<Order> orders) {
		return backtrackMaxOrders(orders, 0, container, new boolean[orders.size()],
				new int[container.getLength()][container.getBreadth()][container.getHeight()]);
	}

	// Backtracking: Try to place order items into the container
	private boolean canFit(List<OrderItem> orderItems, Container container, int[][][] space, int index) {
		if (index == orderItems.size())
			return true;

		OrderItem orderItem = orderItems.get(index);
		Product product = orderItem.getProduct();
		int quantity = orderItem.getQuantity();

		for (int q = 0; q < quantity; q++) {
			for (int i = 0; i < container.getLength(); i++) {
				for (int j = 0; j < container.getBreadth(); j++) {
					for (int k = 0; k < container.getHeight(); k++) {
						if (canPlace(space, i, j, k, product, container)) {
							place(space, i, j, k, product, 1);
							if (canFit(orderItems, container, space, index + 1))
								return true;
							place(space, i, j, k, product, 0); // Backtrack
						}
					}
				}
			}
		}
		return false;
	}

	private boolean canPlace(int[][][] space, int x, int y, int z, Product product, Container container) {
		if (x + product.getLength() > container.getLength() || y + product.getBreadth() > container.getBreadth()
				|| z + product.getHeight() > container.getHeight()) {
			return false;
		}

		for (int i = x; i < x + product.getLength(); i++) {
			for (int j = y; j < y + product.getBreadth(); j++) {
				for (int k = z; k < z + product.getHeight(); k++) {
					if (space[i][j][k] != 0)
						return false;
				}
			}
		}
		return true;
	}

	private void place(int[][][] space, int x, int y, int z, Product product, int val) {
		for (int i = x; i < x + product.getLength(); i++) {
			for (int j = y; j < y + product.getBreadth(); j++) {
				for (int k = z; k < z + product.getHeight(); k++) {
					space[i][j][k] = val;
				}
			}
		}
	}

	private int backtrackMaxOrders(List<Order> orders, int index, Container container, boolean[] used,
			int[][][] space) {
		int maxOrders = 0;

		for (int i = index; i < orders.size(); i++) {
			if (!used[i]) {
				if (canFit(orders.get(i).getItems(), container, space, 0)) {
					used[i] = true;
					maxOrders = Math.max(maxOrders, 1 + backtrackMaxOrders(orders, i + 1, container, used, space));
					used[i] = false; // Backtrack
				}
			}
		}
		return maxOrders;
	}
}