package com.intv.tesc.container;

import java.util.List;

interface OrderPackingService {

	String findOptimalContainer(Order order);

	int maxOrdersForContainer(Container container, List<Order> orders);
}
