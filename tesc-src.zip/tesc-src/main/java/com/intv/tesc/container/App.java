package com.intv.tesc.container;

import java.util.ArrayList;
import java.util.List;

public class App {

	public static void main(String[] args) {

		Product p1 = new Product("p1", 2, 4, 10);
		Product p2 = new Product("p2", 10, 30, 4);
		Product p3 = new Product("p3", 5, 6, 7);

		// Example Order: product 1 x3 and product 3 x7
		Order order = new Order();
		order.addItem(p1, 3);
		order.addItem(p2, 50);
		order.addItem(p3, 7);

		ContainerService svc = new ContainerServiceImpl();

		System.out.println("Suitable Container: " + svc.resolveSuitableContainer(order));

		System.out.println("Max Fillable Orders: " + svc.computeMaxFillableOrders(
				new ArrayList<>(List.of(order, order, order, order, order, order)), ContainerRepository.C2));
	}
}