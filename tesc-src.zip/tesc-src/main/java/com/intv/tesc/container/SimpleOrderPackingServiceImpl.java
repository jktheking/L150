package com.intv.tesc.container;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SimpleOrderPackingServiceImpl implements OrderPackingService {
	private final ContainerRepository containerRepository;

	public SimpleOrderPackingServiceImpl(ContainerRepository containerRepository) {
		this.containerRepository = containerRepository;
	}

	@Override
	public String findOptimalContainer(Order order) {
		List<Container> suitableContainers = containerRepository.getSuitableContainers(order.getVolume());

		for (Container container : suitableContainers) {
			if (canFitItems(container, order.getItems())) {
				return container.getId();
			}
		}
		return "NO_CONTAINER";
	}

	private boolean canFitItems(Container container, List<OrderItem> items) {
		int remainingVolume = container.getVolume();

		for (OrderItem item : items) {
			int itemVolume = item.getProduct().getVolume() * item.getQuantity();
			if (itemVolume > remainingVolume) {
				return false;
			}
			remainingVolume -= itemVolume;
		}
		return true;
	}

	@Override
	public int maxOrdersForContainer(Container container, List<Order> orders) {

		Collections.sort(orders, Comparator.comparing(Order::getVolume));

		int orderVolumeSum = 0;
		int count = 0;

		for (Order order : orders) {
			if (orderVolumeSum >= container.getVolume()) {
				break;
			}
			orderVolumeSum = orderVolumeSum + order.getVolume();
			count++;

		}
		return count;

	}
}
