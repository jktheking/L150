package com.intv.tesc.re;

import java.util.List;
import java.util.Map;

public class ReCore {
}

@FunctionalInterface
interface Rule<T extends RestrictionAttribute> {

	boolean evaluate(List<Item> items, T attribute);

}

class BulkBuyLimitCategoryRule implements Rule<Category> {

	private final RuleConfigGateway<Category, Integer> configGateway;

	public BulkBuyLimitCategoryRule(final RuleConfigGateway<Category, Integer> configGateway) {
		this.configGateway = configGateway;
	}

	@Override
	public boolean evaluate(List<Item> items, Category attribute) {
		return items.stream().mapToInt(Item::getQuantity).sum() <= configGateway.getConfiguredValue(attribute);
	}

}

interface RuleEngine {

	enum Status {
		MET, BREACHED;
	}

	Status evaluate(Order order);

}

interface RuleConfigGateway<A extends RestrictionAttribute, R> {

	R getConfiguredValue(A attribute);

}

class CategoryRuleConfigGateway implements RuleConfigGateway<Category, Integer> {

	private final int defaultt;

	private final Map<Category, Integer> config;

	public CategoryRuleConfigGateway(final Map<Category, Integer> config, int defaultt) {
		this.config = config;
		this.defaultt = defaultt;
	}

	@Override
	public Integer getConfiguredValue(Category attribute) {
		return config.getOrDefault(attribute, defaultt);
	}

}

class DefaultRuleEngine implements RuleEngine {

	// private static final Logger logger =
	// LoggerFactory.getLogger(DefaultRuleEngine.class);

	private Map<RestrictionAttribute, List<Rule<RestrictionAttribute>>> ruleResolverMap;

	public DefaultRuleEngine(Map<RestrictionAttribute, List<Rule<RestrictionAttribute>>> rules) {
		this.ruleResolverMap = rules;
	}

	@Override
	public Status evaluate(Order order) {

		Map<RestrictionAttribute, List<Item>> restrictionWiseOrder = order.getRestrictionAttributeMap();

		for (Map.Entry<RestrictionAttribute, List<Item>> restrictionWiseItems : restrictionWiseOrder.entrySet()) {

			RestrictionAttribute restrictionAttributeRuntime = restrictionWiseItems.getKey();
			List<Item> itemsRuntime = restrictionWiseItems.getValue();

			for (Rule<RestrictionAttribute> rule : resolveRules(restrictionAttributeRuntime)) {

				if (!rule.evaluate(itemsRuntime, restrictionAttributeRuntime)) {
					return Status.BREACHED;
				}
			}

		}

		return Status.MET;
	}

	public List<Rule<RestrictionAttribute>> resolveRules(RestrictionAttribute resAttribute) {
		return ruleResolverMap.getOrDefault(resAttribute, List.of());
	}
}
