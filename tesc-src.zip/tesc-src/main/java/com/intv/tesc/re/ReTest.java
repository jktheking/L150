package com.intv.tesc.re;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.test.re.BeforeEach;
import com.test.re.ExtendWith;
import com.test.re.InjectMocks;
import com.test.re.Mock;
import com.test.re.MockitoExtension;
import com.test.re.Test;

class DefaultRuleEngineTest {

	private DefaultRuleEngine ruleEngine;

	@BeforeEach
	void setUp() {
		// Define business restriction rules
		Map<Category, Integer> categoryLimits = new HashMap<>();
		categoryLimits.put(Category.PARACETAMOL, 5); // Cannot buy more than 5 Paracetamol
		int bulkBuyLimit = 10; // Cannot buy more than 10 of any product

		// Create Rule Config Gateway
		RuleConfigGateway<Category, Integer> categoryRuleConfigGateway = new CategoryRuleConfigGateway(categoryLimits,
				bulkBuyLimit);

		// Define Rules
		Rule<RestrictionAttribute> bulkBuyLimitCategoryRule = new BulkBuyLimitCategoryRule(categoryRuleConfigGateway);

		// Rule Resolver Map
		Map<RestrictionAttribute, List<Rule<RestrictionAttribute>>> rules = new HashMap<>();
		rules.put(Category.PARACETAMOL, List.of(bulkBuyLimitCategoryRule));

		ruleEngine = new DefaultRuleEngine(rules);
	}

	@Test
	void evaluate_ShouldReturnMet_WhenOrderCompliesWithRules() {
		List<Item> items = List.of(new Item(1, Category.PARACETAMOL, 3), new Item(2, Category.ANALGESIC, 3),
				new Item(3, Category.CHOCOLATE, 8), new Item(4, Category.PARACETAMOL, 2));

		Order order = new Order(items);
		assertEquals(RuleEngine.Status.MET, ruleEngine.evaluate(order));
	}

	@Test
	void evaluate_ShouldReturnBreached_WhenCategoryLimitIsExceeded() {
		List<Item> items = List.of(new Item(1, Category.PARACETAMOL, 4), new Item(2, Category.PARACETAMOL, 3) // Total
																												// Paracetamol
																												// = 7 >
																												// 5
		);

		Order order = new Order(items);
		assertEquals(RuleEngine.Status.BREACHED, ruleEngine.evaluate(order));
	}

	@Test
	void evaluate_ShouldReturnBreached_WhenBulkBuyLimitIsExceeded() {
		List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 6), new Item(2, Category.ANALGESIC, 5) // Total = 11
																											// > 10
		);

		Order order = new Order(items);
		assertEquals(RuleEngine.Status.BREACHED, ruleEngine.evaluate(order));
	}

	@Test
	void evaluate_ShouldReturnMet_WhenItemsAreWithinLimit() {
		List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 5), new Item(2, Category.ANALGESIC, 4),
				new Item(3, Category.PARACETAMOL, 2));

		Order order = new Order(items);
		assertEquals(RuleEngine.Status.MET, ruleEngine.evaluate(order));
	}

	@Test
	void evaluate_ShouldReturnMet_WhenNoItemsInOrder() {
		Order order = new Order(Collections.emptyList());
		assertEquals(RuleEngine.Status.MET, ruleEngine.evaluate(order));
	}
}

@ExtendWith(MockitoExtension.class)
class BulkBuyLimitCategoryRuleTest {

	@Mock
	private RuleConfigGateway<Category, Integer> configGateway;

	@InjectMocks
	private BulkBuyLimitCategoryRule bulkBuyLimitCategoryRule;

	@Test
	void givenValidItems_whenEvaluate_thenReturnTrue() {
		when(configGateway.getConfiguredValue(Category.CHOCOLATE)).thenReturn(10);

		List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 3), new Item(2, Category.CHOCOLATE, 6));

		assertTrue(bulkBuyLimitCategoryRule.evaluate(items, Category.CHOCOLATE));
	}

	@Test
	void givenInvalidItems_whenEvaluate_thenReturnFalse() {
		when(configGateway.getConfiguredValue(Category.CHOCOLATE)).thenReturn(10);

		List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 5), new Item(2, Category.CHOCOLATE, 6));

		assertFalse(bulkBuyLimitCategoryRule.evaluate(items, Category.CHOCOLATE));
	}

}
