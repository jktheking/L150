package com.intv.tesc.re;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class ReEntity {
}

interface RestrictionAttribute {
}

enum Category implements RestrictionAttribute {

	CHOCOLATE,

	PARACETAMOL,

	ANALGESIC,

	;

}

class Item {

	private final int productId;
	private final Category category;
	private final int quantity;

	public Item(int productId, Category category, int quantity) {
		this.productId = productId;
		this.category = category;
		this.quantity = quantity;
	}

	// getter

	public int getProductId() {
		return productId;
	}

	public Category getCategory() {
		return category;
	}

	public int getQuantity() {
		return quantity;
	}

}

class Order {

	/*
	 * Will extract all the restriction attribute from the order's items and group
	 * the items restriction attribute-wise
	 *
	 */
	private final Map<RestrictionAttribute, List<Item>> restrictionAttributeMap;

	public Order(List<Item> items) {
		this.restrictionAttributeMap = prepareRestrictionAttributeMap(items);
	}

	private Map<RestrictionAttribute, List<Item>> prepareRestrictionAttributeMap(final List<Item> items) {

		Map<Category, List<Item>> categoryItemMap = new EnumMap<>(Category.class);

		for (Item item : items) {
			categoryItemMap.computeIfAbsent(item.getCategory(), key -> new ArrayList<Item>()).add(item);
		}

		return Collections.unmodifiableMap(categoryItemMap);

	}

	public List<Item> getItems(RestrictionAttribute attribute) {
		return restrictionAttributeMap.get(attribute);
	}

	public Map<RestrictionAttribute, List<Item>> getRestrictionAttributeMap() {
		return restrictionAttributeMap;
	}

}
