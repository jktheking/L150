package com.intv.tesc.store;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class ColleagueShiftTimeTest {

	@Mock
	private ColleagueShiftRepository colleagueShiftRepository;

	@Mock
	private ShiftMergeService shiftMergeService;

	@InjectMocks
	private ColleagueShiftTimeServiceImpl colleagueShiftTimeImpl;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void shouldFetchAndMergeColleagueShifts() {
		// Given
		String empId = "E123";
		String storeId = "S001";

		List<ShiftTime> mockShifts = List.of(new ShiftTime(8, 10), new ShiftTime(10, 12), new ShiftTime(14, 19));

		List<ShiftTime> mergedShifts = List.of(new ShiftTime(8, 12), new ShiftTime(14, 19));

		when(colleagueShiftRepository.getStoreShifts(empId, storeId)).thenReturn(mockShifts);
		when(shiftMergeService.merge(mockShifts)).thenReturn(mergedShifts);

		// When
		List<ShiftTime> result = colleagueShiftTimeImpl.fetchColleagueShifts(empId, storeId);

		// Then
		assertEquals(mergedShifts, result);
		verify(colleagueShiftRepository, times(1)).getStoreShifts(empId, storeId);
		verify(shiftMergeService, times(1)).merge(mockShifts);
	}
}
