package com.intv.tesc.store;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class ShiftTimeTest {

	@Test
	void shouldCreateValidShiftTime() {
		// Given & When
		ShiftTime shiftTime = new ShiftTime(8, 12);

		// Then
		assertEquals(8, shiftTime.getStart());
		assertEquals(12, shiftTime.getEnd());
	}

	@Test
	void shouldThrowExceptionForInvalidStartTime() {
		// Given & When & Then
		Exception exception = assertThrows(IllegalArgumentException.class, () -> new ShiftTime(-1, 12));
		assertEquals("Shift times must be between 0 and 23 inclusive.", exception.getMessage());
	}

	@Test
	void shouldThrowExceptionForInvalidEndTime() {
		// Given & When & Then
		Exception exception = assertThrows(IllegalArgumentException.class, () -> new ShiftTime(8, 24));
		assertEquals("Shift times must be between 0 and 23 inclusive.", exception.getMessage());
	}

	@Test
	void shouldThrowExceptionForBothTimesOutOfRange() {
		// Given & When & Then
		Exception exception = assertThrows(IllegalArgumentException.class, () -> new ShiftTime(-5, 30));
		assertEquals("Shift times must be between 0 and 23 inclusive.", exception.getMessage());
	}

	@Test
	void shouldCreateShiftTimeUsingFactoryMethod() {
		// Given
		ShiftTime originalShift = new ShiftTime(10, 15);

		// When
		ShiftTime copiedShift = ShiftTime.of(originalShift);

		// Then
		assertNotSame(originalShift, copiedShift);
		assertEquals(10, copiedShift.getStart());
		assertEquals(15, copiedShift.getEnd());
	}

	@Test
	void shouldReturnCorrectToStringRepresentation() {
		// Given
		ShiftTime shiftTime = new ShiftTime(9, 17);

		// When
		String result = shiftTime.toString();

		// Then
		assertEquals("ShiftTime [start=9, end=17]", result);
	}
}
