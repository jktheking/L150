package com.intv.tesc.store;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ShiftMergeServiceTest {

	private ShiftMergeService shiftMergeService;

	@BeforeEach
	void setUp() {
		shiftMergeService = new ShiftMergeServiceImpl();
	}

	@Test
	void givenNonOverlappingShifts_whenMerged_thenReturnsSameShifts() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(14, 16));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 10), new ShiftTime(14, 16)), result);
	}

	@Test
	void givenOverlappingShifts_whenMerged_thenReturnsMergedShifts() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(9, 12));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}

	@Test
	void givenContiguousShifts_whenMerged_thenReturnsSingleShift() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(10, 12));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}

	@Test
	void givenShiftsAcrossMidnight_whenMerged_thenRetrunSingleShift() {
		List<ShiftTime> shifts = List.of(new ShiftTime(22, 2), new ShiftTime(20, 23));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(20, 2)), result);
	}

	@Test
	void givenFullyContainedShifts_whenMerged_thenIgnoresInnerShift() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 12), new ShiftTime(9, 11));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}

	@Test
	void givenEmptyShifts_whenMerged_thenReturnsEmptyList() {
		List<ShiftTime> shifts = List.of();
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertTrue(result.isEmpty());
	}

}
