package com.intv.tesc.container;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class OrderPackingServiceTest {
	private OrderPackingService orderPackingService;
	private Container smallContainer, mediumContainer, largeContainer;
	private List<Order> testOrders;

	@BeforeEach
	void setUp() {
		smallContainer = new Container("SMALL", 10, 20, 30);
		mediumContainer = new Container("MEDIUM", 50, 60, 70);
		largeContainer = new Container("LARGE", 100, 200, 300);

		List<Container> containers = Arrays.asList(smallContainer, mediumContainer, largeContainer);
		ContainerRepository repository = new ContainerRepository(containers);
		orderPackingService = new Spatial3dOrderPackingServiceImpl(repository);
		// orderPackingService = new SimpleOrderPackingServiceImpl(repository);

		List<Product> products = Arrays.asList(new Product("P1", 2, 4, 10), new Product("P2", 10, 30, 4),
				new Product("P3", 5, 6, 7));

		Order order1 = new Order();
		order1.addItem(products.get(0), 3);
		order1.addItem(products.get(2), 7);

		Order order2 = new Order();
		order2.addItem(products.get(1), 2);

		Order order3 = new Order();
		order3.addItem(products.get(2), 10);

		testOrders = Arrays.asList(order1, order2, order3);
	}

	@Test
	void testFindOptimalContainer_Success() {
		String result = orderPackingService.findOptimalContainer(testOrders.get(0));
		assertEquals("SMALL", result, "Order should fit into the Medium container");
	}

	@Test
	void testFindOptimalContainer_NoFit() {
		Order largeOrder = new Order();
		largeOrder.addItem(new Product("P4", 200, 200, 300), 1);

		String result = orderPackingService.findOptimalContainer(largeOrder);
		assertEquals("NO_CONTAINER", result, "No container should be able to fit this order");
	}

}
