package l150.systemdesign.crdt;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class ORSet<T> {
	private final Map<T, Set<UUID>> elements; // Stores elements with their unique IDs
	private final Map<T, Set<UUID>> tombstones; // Stores removed elements' IDs

	public ORSet() {
		this.elements = new HashMap<>();
		this.tombstones = new HashMap<>();
	}

	// Add an element with a unique identifier
	public void add(T element) {
		UUID id = UUID.randomUUID(); // Generate unique identifier
		elements.computeIfAbsent(element, k -> new HashSet<>()).add(id);
	}

	// Remove an element by moving its IDs to the tombstone set
	public void remove(T element) {
		if (elements.containsKey(element)) {
			tombstones.computeIfAbsent(element, k -> new HashSet<>()).addAll(elements.get(element));
			elements.remove(element);
		}
	}

	// Merge two OR-Sets
	public void merge(ORSet<T> other) {
		// Merge active elements
		for (Map.Entry<T, Set<UUID>> entry : other.elements.entrySet()) {
			elements.computeIfAbsent(entry.getKey(), k -> new HashSet<>()).addAll(entry.getValue());
		}

		// Merge tombstones
		for (Map.Entry<T, Set<UUID>> entry : other.tombstones.entrySet()) {
			tombstones.computeIfAbsent(entry.getKey(), k -> new HashSet<>()).addAll(entry.getValue());
		}

		// Ensure removed elements do not reappear
		for (T element : tombstones.keySet()) {
			if (elements.containsKey(element)) {
				elements.get(element).removeAll(tombstones.get(element));
				if (elements.get(element).isEmpty()) {
					elements.remove(element);
				}
			}
		}
	}

	// Get all active elements
	public Set<T> getElements() {
		return elements.keySet();
	}

	public static void main(String[] args) {
		ORSet<String> set1 = new ORSet<>();
		ORSet<String> set2 = new ORSet<>();

		set1.add("A");
		set1.add("B");
		set2.add("B");
		set2.add("C");

		set1.remove("B"); // B is removed from set1

		System.out.println("Set 1 before merge: " + set1.getElements());
		System.out.println("Set 2 before merge: " + set2.getElements());

		set1.merge(set2);

		System.out.println("Merged Set: " + set1.getElements()); // Should contain A, C but not B
	}
}
