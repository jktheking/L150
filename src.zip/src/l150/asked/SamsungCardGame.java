package l150.asked;

/**
 * 
 * You are given n cards, each of a specific value and type. There are 4 types
 * of cards, numbered from 1 to 4. Your task is to select exactly k cards from
 * the n cards such that the X factor is maximized. The X factor is calculated
 * as: X=sum of the values of the selected cards + squre_of(count of card from
 * each type).
 * 
 * <pre>
 * value_sum      = (a1 + a2 + a3) + (b1) + (c1)  + (d1 + d4) 
 *  coficient_sum =    (3^2)       +  1^2 +  1^2  +   (2^2)
 * 
 * </pre>
 * 
 * Write a function that finds the maximum X factor possible by selecting
 * exactly k cards.
 * 
 * 
 */

/**
 * 
 * Brute-force solution: find out all the possible combination set of k from n cards and then calculate
 * the sum using formula.
 * 
 * 
 * 
 * */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SamsungCardGame {

	static class Card {
		int value;
		int type;

		Card(int value, int type) {
			this.value = value;
			this.type = type;
		}
	}

	public static void main(String[] args) {
		List<Card> cards = Arrays.asList(new Card(20, 1), new Card(10, 2), new Card(10, 4), new Card(10, 3),
				new Card(12, 1), new Card(9, 2), new Card(3, 3), new Card(11, 1), new Card(2, 3));

		int k = 2;
		System.out.println("Max X Factor (Optimized): " + findMaxXFactor(cards, k));
	}

	static int findMaxXFactor(List<Card> cards, int k) {

		List<Integer>[] types = new ArrayList[5]; // index 1 to 4

		for (int i = 1; i <= 4; i++)
			types[i] = new ArrayList<>();

		for (Card card : cards) {
			types[card.type].add(card.value);
		}

		// Sort each type descending
		for (int i = 1; i <= 4; i++) {
			types[i].sort(Collections.reverseOrder());

		}

		// Compute prefix sums
		List<Integer>[] prefix = new ArrayList[5];
		for (int i = 1; i <= 4; i++) {
			prefix[i] = new ArrayList<>();
			prefix[i].add(0);
			for (int val : types[i]) {
				prefix[i].add(prefix[i].get(prefix[i].size() - 1) + val);
			}
		}

		int maxX = 0;

		// Try all (a + b + c + d = k)
		for (int a = 0; a <= k; a++) {
			for (int b = 0; b + a <= k; b++) {
				for (int c = 0; c + b + a <= k; c++) {
					int d = k - a - b - c;
					if (prefix[1].size() <= a || prefix[2].size() <= b || prefix[3].size() <= c
							|| prefix[4].size() <= d)
						continue;

					int sum = prefix[1].get(a) + prefix[2].get(b) + prefix[3].get(c) + prefix[4].get(d);

					int squares = a * a + b * b + c * c + d * d;
					maxX = Math.max(maxX, sum + squares);
				}
			}
		}

		return maxX;
	}
}
