package l150.ds.heap;

import java.util.Arrays;

/**
 * Heap is always a complete binary tree. All levels except the last are
 * completely filled. So we can maintain an array for heap. And can use BFS
 * indexing for calculating the left and right child index
 * 
 * L = 2*i +1 R = 2*i + 2
 * 
 * 
 * 
 * Insert O(log n)
 * 
 * Remove Min O(log n)
 * 
 * Peek (Get Min) O(1)
 * 
 * Heapify Up O(log n)
 * 
 * Heapify Down O(log n)
 * 
 * Expand Capacity O(n) (Amortized O(1))
 * 
 * Check Empty O(1)
 * 
 * Here search will have order of O(n)
 */

class MinHeap {
	private int[] heap;
	private int size;
	private int capacity;

	public MinHeap(int capacity) {
		this.capacity = capacity;
		this.size = 0;
		this.heap = new int[capacity];
	}

	// to get the parent we need to just use left_parent formula
	private int parent(int i) {
		// Left Parent = 2i + 1
		return (i - 1) / 2;
	}

	private int leftChild(int i) {
		return 2 * i + 1;
	}

	private int rightChild(int i) {
		return 2 * i + 2;
	}

	public void insert(int value) {
		if (size == capacity) {
			expandCapacity();
		}
		heap[size] = value;
		size++;
		heapifyUp(size - 1);
	}

	private void expandCapacity() {
		capacity *= 2;
		heap = Arrays.copyOf(heap, capacity);
	}

	// since it's array, so we will add the element at end of the array
	// then call heapifyUp using swap
	private void heapifyUp(int index) {
		while (index > 0 && heap[parent(index)] > heap[index]) {
			swap(parent(index), index);
			index = parent(index);
		}
	}

	public int removeMin() {
		if (size == 0) {
			throw new IllegalStateException("Heap is empty");
		}
		int min = heap[0];
		heap[0] = heap[size - 1];
		size--;
		heapifyDown(0);
		return min;
	}

	// Moves the element at index down to its correct position by comparing it with
	// its left and right children. If any child is smaller, it swaps and continues
	// recursively.
	private void heapifyDown(int index) {
		int smallest = index;
		int left = leftChild(index);
		int right = rightChild(index);

		if (left < size && heap[left] < heap[smallest]) {
			smallest = left;
		}
		if (right < size && heap[right] < heap[smallest]) {
			smallest = right;
		}

		// if in smallest either left or right index value came
		if (smallest != index) {
			swap(index, smallest);
			heapifyDown(smallest);
		}
	}

	// Moves the element at index down to its correct position by comparing it with
	// its left and right children. If any child is smaller, it swaps and continues
	// recursively.
	private void heapifyDownIterative(int index) {
		while (index < size) {
			int smallest = index;
			int left = leftChild(index);
			int right = rightChild(index);

			// Check if left child exists and is smaller than the current element
			if (left < size && heap[left] < heap[smallest]) {
				smallest = left;
			}

			// Check if right child exists and is smaller than the smallest found so far
			if (right < size && heap[right] < heap[smallest]) {
				smallest = right;
			}

			// If the smallest is still the current element, we're done
			if (smallest == index) {
				break;
			}

			// Swap with the smallest child and continue heapifying down
			swap(index, smallest);
			index = smallest;
		}
	}

	public int peek() {
		if (size == 0) {
			throw new IllegalStateException("Heap is empty");
		}
		return heap[0];
	}

	private void swap(int i, int j) {
		int temp = heap[i];
		heap[i] = heap[j];
		heap[j] = temp;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	public void printHeap() {
		System.out.println(Arrays.toString(Arrays.copyOf(heap, size)));
	}

	public static void main(String[] args) {
		MinHeap heap = new MinHeap(5);
		heap.insert(10);
		heap.insert(15);
		heap.insert(20);
		heap.insert(17);
		heap.insert(8);
		heap.printHeap(); // Should print [8, 10, 20, 17, 15]

		System.out.println("Min: " + heap.removeMin()); // Should remove 8
		heap.printHeap();
	}
}
