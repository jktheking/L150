package l150.perm.comb;

import java.util.Arrays;

/**
 *
 * You are a professional robber planning to rob houses along a street. Each
 * house has a certain amount of money stashed, the only constraint stopping you
 * from robbing each of them is that adjacent houses have security systems
 * connected and it will automatically contact the police if two adjacent houses
 * were broken into on the same night.
 *
 * Given an integer array nums representing the amount of money of each house,
 * return the maximum amount of money you can rob tonight without alerting the
 * police.
 *
 *
 *
 * Example 1:
 *
 * Input: nums = [1,2,3,1] Output: 4 Explanation: Rob house 1 (money = 1) and
 * then rob house 3 (money = 3). Total amount you can rob = 1 + 3 = 4. Example
 * 2:
 *
 * Input: nums = [2,7,9,3,1] Output: 12 Explanation: Rob house 1 (money = 2),
 * rob house 3 (money = 9) and rob house 5 (money = 1). Total amount you can rob
 * = 2 + 9 + 1 = 12.
 *
 *
 */
public class L198HouseRobber {

	public static void main(String[] args) {

	}

	/**
	 * <pre>
	 * Since as per the question we cannot rob consecutive house, means when
	 * we construct the solution then for ith house we will have two
	 * options for recursion tree:
	 *
	 * include the ith house and then skip the next house
	 * exclude the ith house and then consider the next house
	 *
	 * we will fix at level array position, means when all the elements are exhausted we
	 * reach the base condition
	 *
	 * </pre>
	 *
	 */ 

	public static void rob(int[] nums) {

		rob(nums);

		int[] memo = new int[nums.length];
		Arrays.fill(memo, -1);
		robMemoization(nums, 0, memo);

	}

	private static int rob(int[] nums, int idx) {

		int include = nums[idx] + rob(nums, idx + 2);
		int exclude = 0 + rob(nums, idx + 1);

		return Math.max(include, exclude);

	}

	private static int robMemoization(int[] nums, int idx, int[] memo) {

		if (idx >= nums.length)
			return 0;

		if (memo[idx] != -1)
			return memo[idx];

		int include = nums[idx] + robMemoization(nums, idx + 2, memo);
		int exclude = robMemoization(nums, idx + 1, memo);

		return memo[idx] = Math.max(include, exclude);

	}

	/**
	 * Against each element of input we will calculate two values:
	 *
	 * -- what is the maximum till now by including the current element ? 1.
	 * includeMax = previousExcludeMax + currentInclude
	 *
	 * -- what is the maximum till now by excluding the current element ? 2.
	 * excludeMax = Math.max(previousIncludeMax, previousExcludeMax)
	 *
	 */
	private static int robTabulation(int[] nums) {

		// dp[0] = will maintain include values
		// dp[1] = will maintain exclude values
		int[][] dp = new int[2][nums.length];

		// for first element includeMax is the value of first element itself.
		dp[0][0] = nums[0];
		// for first element excludeMax is 0 as there is nothing to consider and
		// identity of addition is 0.
		dp[1][0] = 0;

		for (int i = 1; i < nums.length; i++) {

			// includeMax = previousExcludeMax + currentInclude
			dp[0][i] = dp[1][i - 1] + nums[i];

			// excludeMax = Math.max(previousIncludeMax, previousExcludeMax)
			dp[1][i] = Math.max(dp[0][i - 1], dp[1][i - 1]);

		}
		return Math.max(dp[0][nums.length - 1], dp[1][nums.length - 1]);

	}

	/**
	 * Against each element of input we will calculate two values:
	 *
	 * -- what is the maximum till now by including the current element ?
	 *
	 * includeMax = previousExcludeMax + currentInclude
	 *
	 * -- what is the maximum till now by excluding the current element ?
	 *
	 * excludeMax = Math.max(previousIncludeMax, previousExcludeMax)
	 *
	 */
	private static int robTabulationOptimized(int[] nums) {

		int includeMax = nums[0];
		int excludeMax = 0;

		for (int i = 1; i < nums.length; i++) {

			int previousIncludeMax = includeMax;

			// includeMax = previousExcludeMax + currentInclude
			includeMax = excludeMax + nums[i];

			// excludeMax = Math.max(previousIncludeMax, previousExcludeMax)
			excludeMax = Math.max(previousIncludeMax, excludeMax);

		}
		return Math.max(includeMax, excludeMax);

	}

}
