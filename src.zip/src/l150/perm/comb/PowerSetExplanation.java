package l150.perm.comb;

import java.util.Arrays;

public class PowerSetExplanation {

	public static void main(String[] args) {

		printPowerSetByFixingPosition(new char[] { 'a', 'b', 'c' }, new char[3], 0);
		System.out.println("-----------------------------------");
		printPowerSetByFixingPositionAlt(new char[] { 'a', 'b', 'c' }, new char[3], 0);
		System.out.println("---------pascal identity expansion--------------------------");
		printPowerSetUsingPascalIdentityExpansion(new char[] { 'a', 'b', 'c' }, 0, new char[3]);

	}

	// note: input is hard fixed to position
	// at each level we apply the position as options with its respective input.
	public static void printPowerSetUsingPascalIdentityExpansion(char[] input, int pos, char[] output) {

		System.out.println(Arrays.toString(output));

//		if (pos == output.length) {
//			return;
//		}

		for (int i = pos; i < input.length; i++) {
			output[i] = input[i];
			printPowerSetUsingPascalIdentityExpansion(input, i + 1, output);
			output[i] = Character.MIN_VALUE;
		}
	}

	public static void printPowerSetByFixingPosition(char[] input, char[] output, int pos) {
		if (pos == output.length) {
			System.out.println(Arrays.toString(output));
			return;
		}
		// excluding p(i)
		printPowerSetByFixingPosition(input, output, pos + 1);

		output[pos] = input[pos];
		printPowerSetByFixingPosition(input, output, pos + 1);
		output[pos] = Character.MIN_VALUE;

	}

	public static void printPowerSetByFixingPositionAlt(char[] input, char[] output, int pos) {
		if (pos == output.length) {
			System.out.println(Arrays.toString(output));
			return;
		}

		output[pos] = input[pos];
		printPowerSetByFixingPosition(input, output, pos + 1);
		output[pos] = Character.MIN_VALUE;

		// excluding p(i)
		printPowerSetByFixingPosition(input, output, pos + 1);

	}

}
