package l150.perm.comb;

public class BackTrack {

	public static void main(String[] args) {

	}

	void place(int[][] grid, int queens) {

		for (int cell = 0; cell < 16; cell++) {

			int i = cell / 4;
			int j = cell % 4;

			if (isValidPosition(grid, i, j)) {

				grid[i][j] = queens;
				place(grid, queens + 1);
				grid[i][j] = 0;
			}

		}
	}

	private boolean isValidPosition(int[][] grid, int i, int j) {

		return false;
	}
}
