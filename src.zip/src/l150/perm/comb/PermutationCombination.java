package l150.perm.comb;

import java.util.Arrays;

public class PermutationCombination {

	public static void main(String[] args) {

		permute("ab".toCharArray(), 3);
		System.out.println("------------------------------------");
		permute("abc".toCharArray(), 2);
		System.out.println("-------------------------------------");
		combinationByPermutationStrategyByFixingInput("ab".toCharArray(), 0, new char[3], 0);

	}

	public static void permute(char[] input, int position) {

		if (input.length <= position) {
			permuteByFixingInput(input, 0, new char[position], new boolean[position]);
		} else {
			permuteByFixingPosition(input, new boolean[input.length], new char[position], 0);
		}

	}

	/**
	 * Since we are taking positions as option. i.e.
	 *
	 * - we apply first input at first level on each position.
	 *
	 * - we apply second input at second level on each remaining position .. and so
	 * on.
	 *
	 * So, if input is [a,b] and positions[-,-,-] then at first level we will have
	 * a--, -a-, --a as recursion-option branches of the tree. To generate the 2nd
	 * recursion-option branch we need to first remove the option tried in 1st
	 * recursion-option branch and then try the input. 'a--' -->[remove 'a' from
	 * position P1 and then try at P2] --> '-a-'. This can be done by backtracking
	 * on position array.
	 *
	 * At next level, we are applying the next-input char as options on remaining
	 * positions. How to know which all are the remaining positions on next level ?
	 * we need to pass the visitedPositions[] to next level. We need to mark them
	 * unvisited while trying the other branch of recursion(i.e. backtracking).
	 *
	 */
	private static void permuteByFixingInput(char[] input, int inputIdx, char[] output, boolean[] visitedPos) {

		if (inputIdx == input.length) {
			System.out.println(Arrays.toString(output));
			return;
		}

		// applying positions as options
		for (int i = 0; i < output.length; i++) {
			// visited helps applying remaining positions as options on next level
			if (!visitedPos[i]) {
				output[i] = input[inputIdx];
				visitedPos[i] = true;
				permuteByFixingInput(input, inputIdx + 1, output, visitedPos);
				output[i] = Character.MIN_VALUE;
				visitedPos[i] = false;
			}

		}

	}

	private static void permuteByFixingPosition(char[] input, boolean[] visitedInput, char[] output, int posIdx) {

		if (posIdx == output.length) {
			System.out.println(Arrays.toString(output));
			return;
		}

		// applying input as options
		for (int i = 0; i < input.length; i++) {
			// visited helps applying remaining input as options on next level
			if (!visitedInput[i]) {
				output[posIdx] = input[i];
				//we are using the i-th input option, so on next level we cannot use this i-th input as option.
				visitedInput[i] = true;
				permuteByFixingPosition(input, visitedInput, output, posIdx + 1);
				output[posIdx] = Character.MIN_VALUE;
				visitedInput[i] = false;

			}

		}

	}

	/**
	 *
	 * Here we need not to keep the track of visitedPositions, since we are applying
	 * next input in increasing order, so at next-level input will be tried on
	 * positions ahead of previous level
	 */
	public static void combinationByPermutationStrategyByFixingInput(char[] input, int nextInputIdx, char[] output,
			int nextPosIdx) {

		// base case on inputIndex as we are fixing input
		if (input.length == nextInputIdx) {
			System.out.println(Arrays.toString(output));
			return;
		}

		// apply positions as options starting from the one position ahead of previous
		// level
		for (int i = nextPosIdx; i < output.length; i++) {
			output[i] = input[nextInputIdx];
			combinationByPermutationStrategyByFixingInput(input, nextInputIdx + 1, output, i + 1);
			// remove the input tried at previous level, before applying the next input
			output[i] = Character.MIN_VALUE;

		}

	}

}
