package l150.arraystring;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class EpochToReadable {
	public static void main(String[] args) {
		long epochSeconds = 0; // Unix epoch
		Instant epochInstant = Instant.ofEpochSecond(epochSeconds);

		// epochInstant.

		ZonedDateTime dateTime = epochInstant.atZone(ZoneId.of("UTC"));
		System.out.println("Epoch Instant in UTC: " + dateTime);

		ZonedDateTime istTime = epochInstant.atZone(ZoneId.of("Asia/Kolkata"));
		System.out.println("Epoch Instant in IST: " + istTime);
	}
}
