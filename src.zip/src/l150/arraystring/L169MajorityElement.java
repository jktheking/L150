package l150.arraystring;

/***
 * Given an array nums of size n, return the majority element.
 *
 * The majority element is the element that appears more than ⌊n / 2⌋ times. You
 * may assume that the majority element always exists in the array.
 *
 *
 *
 * Example 1:
 *
 * Input: nums = [3,2,3] Output: 3 Example 2:
 *
 * Input: nums = [2,2,1,1,1,2,2] Output: 2
 *
 *
 *
 * @See Misra Gries algorithm
 */
public class L169MajorityElement {

	public static void main(String[] args) {

	}

	private static int majorityElementPractice(int[] nums) {
		
		int majorityElement = nums[0];
		int vote  = 1;
		
		for(int i=1; i< nums.length; i++) {
			
			//once votes cancels out; re-initialize the variables
			if(vote == 0) {
				majorityElement = nums[i];
				vote = 1;
			}else if(nums[i] == majorityElement) {
				vote++;
			}else {
				vote--;
			}
		}

		

		return majorityElement;
	}

	/**
	 * Boyer Moore Majority Voting algorithm
	 *
	 * Since n%2 will have values [0,1]; so there can be only 1 majority candidate
	 */
	private static int majorityElement(int[] nums) {

		// single element in itself is majority element as 1%2 = 1
		int majorityCandidate = nums[0];
		int majorityVote = 1;

		for (int i = 1; i < nums.length; i++) {

			// if majorityVote becomes 0, then assign the next element as majorityCandidate.
			// this statement should be the first, so that when majorityVote becomes ZERO,
			// we can assign next element as the majorityCandidate, before validating with
			// the next element.
			if (majorityVote == 0)
				majorityCandidate = nums[i];

			if (nums[i] == majorityCandidate) {
				majorityVote++;
			} else {
				majorityVote--;
			}

		}

		return majorityCandidate;

	}

}
