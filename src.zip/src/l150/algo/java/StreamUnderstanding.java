package l150.algo.java;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamUnderstanding {

	public static void main(String[] args) {

		List<Integer> numbers = Arrays.asList(1, 2, 1, 3, 3, 2, 4);
		numbers.stream().filter(i -> i % 2 == 0).distinct().sorted(Collections.reverseOrder());

		Map<Integer, String> map = new HashMap<>();
		int key = 7;

		map.computeIfAbsent(key, k -> "" + k);
		map.computeIfPresent(key, (k, ov) -> null);

		map.merge(key, "jk", (ov, nv) -> ov.concat(nv));

		String str = "A a b a c d c a";

		str.chars().mapToObj(ch -> (char) ch).filter(ch -> !Character.isWhitespace(ch))
				.collect(Collectors.groupingBy(Character::toLowerCase, Collectors.counting()));

		int[][] intervals = null;
		Arrays.sort(intervals, (a, b) -> Integer.compare(a[0], b[0]));
	}

}
