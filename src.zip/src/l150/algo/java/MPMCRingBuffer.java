package l150.algo.java;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReferenceArray;

/**
 * 
 * Multiple Producers, Multiple Consumers (MPMC)
 * 
 * https://chatgpt.com/c/679f07df-50f0-800a-9b59-c4ed807a7824
 * 
 * 
 * compare Disruptor with Aeron
 * 
 */
public class MPMCRingBuffer<T> {
	private final AtomicReferenceArray<T> buffer;
	private final int capacity;

	private final AtomicLong head = new AtomicLong(0); // Consumer index
	private final AtomicLong tail = new AtomicLong(0); // Producer index

	public MPMCRingBuffer(int size) {
		this.capacity = size;
		this.buffer = new AtomicReferenceArray<>(size);
	}

	/** Adds an item to the ring buffer (Multiple Producers) */
	public boolean offer(T item) {
		while (true) {
			long currentTail = tail.get();
			long nextTail = (currentTail + 1) % capacity;

			// Check if buffer is full
			if (nextTail == head.get() % capacity) {
				return false; // Buffer is full
			}

			// Attempt to claim the slot
			if (tail.compareAndSet(currentTail, currentTail + 1)) {
				buffer.set((int) (currentTail % capacity), item);
				return true;
			}
			// Else, retry (CAS failed due to contention)
		}
	}

	/** Retrieves an item from the ring buffer (Multiple Consumers) */
	public T poll() {
		while (true) {
			long currentHead = head.get();

			// Check if buffer is empty
			if (currentHead == tail.get()) {
				return null; // Buffer is empty
			}

			// Attempt to claim the slot
			if (head.compareAndSet(currentHead, currentHead + 1)) {
				T item = buffer.get((int) (currentHead % capacity));
				buffer.set((int) (currentHead % capacity), null); // Avoid memory leak
				return item;
			}
			// Else, retry (CAS failed due to contention)
		}
	}

	/** Checks if buffer is empty */
	public boolean isEmpty() {
		return head.get() == tail.get();
	}

	/** Checks if buffer is full */
	public boolean isFull() {
		return (tail.get() + 1) % capacity == head.get() % capacity;
	}

	//

	public static void main(String[] args) {
		MPMCRingBuffer<Integer> ringBuffer = new MPMCRingBuffer<>(5); // Capacity 5

		ExecutorService executor = Executors.newFixedThreadPool(4);

		// 2 Producer Threads
		for (int i = 0; i < 2; i++) {
			final int producerId = i;
			executor.execute(() -> {
				for (int j = 1; j <= 10; j++) {
					while (!ringBuffer.offer(j + (producerId * 100))) {
						// Busy-wait if buffer is full
					}
					System.out.println("Producer " + producerId + " produced: " + (j + (producerId * 100)));
					try {
						Thread.sleep(100);
					} catch (InterruptedException ignored) {
					}
				}
			});
		}

		// 2 Consumer Threads
		for (int i = 0; i < 2; i++) {
			final int consumerId = i;
			executor.execute(() -> {
				for (int j = 1; j <= 10; j++) {
					Integer value;
					while ((value = ringBuffer.poll()) == null) {
						// Busy-wait if buffer is empty
					}
					System.out.println("Consumer " + consumerId + " consumed: " + value);
					try {
						Thread.sleep(200);
					} catch (InterruptedException ignored) {
					}
				}
			});
		}

		executor.shutdown();
	}
}
