package l150.algo.java;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.stream.IntStream;

public class ArrayMisc {

	public static void main(String[] args) {

		// arraySort_2d();

		arraySort_3d();

	}

	private static void arraySort_1d() {

		// 1D Array Sorting
		// For a one-dimensional array, Arrays.sort() sorts the elements in ascending
		// order using Dual-Pivot QuickSort for primitives and TimSort for objects.

		int[] arr = { 5, 2, 8, 3, 1 };
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr)); // Output: [1, 2, 3, 5, 8]

		// for reverse sort array need to be of boxed type
		// Arrays.sort(arr, Collections.reverseOrder()); ==> will not work
		arr = IntStream.of(arr) // Convert to stream
				.boxed() // Convert to Integer stream
				.sorted(Collections.reverseOrder()) // Sort in reverse order
				.mapToInt(Integer::intValue) // Convert back to int[]
				.toArray();

		arr = Arrays.stream(arr).boxed() // Convert to Integer stream
				.sorted(Comparator.comparingInt(a -> -a)) // Reverse sort
				.mapToInt(Integer::intValue).toArray();

	}

	private static void arraySort_2d() {
		// For a two-dimensional array, Arrays.sort() does not sort the entire array.
		// rather it sorts rows of matrix with respect to each other on given row index.
		int[][] matrix = { //

				{ 3, 2, 5 }, //
				{ 1, 4, 8 }, //
				{ 2, 9, 6 } //
		};

		// Arrays.sort(matrix, (a, b) -> Integer.compare(a[0], b[0]));

		// sorting 0th col
		Arrays.sort(matrix, Comparator.comparingInt(arr -> arr[0]));

		// rows of matrix is sorted with respect to 0th col.
		// [1, 4, 8]
		// [2, 9, 6]
		// [3, 2, 5]

		// sorting 1st col ; will override the old sort as it change the
		// position of internal array on the basis of 1st col.
		Arrays.sort(matrix, Comparator.comparingInt(arr -> arr[1]));

		for (int[] row : matrix) {
			System.out.println(Arrays.toString(row));
		}

	}

	private static void arraySort_3d() {

		int[][][] arr = { //
				{ //
						{ 5, 3 }, //
						{ 2, 8 }, //
						{ 19, 24 } //

				}, //

				{ //
						{ 1, 4 }, //
						{ 6, 9 }, //
						{ 13, 14 } //

				}, //

				{ //
						{ 3, 2 }, //
						{ 7, 0 }, //
						{ 17, 11 }//

				}//
		};

		// it will change the position of 2d-matrix with respect to each other on the
		// given index, here whole matrix will shift, element of matrix will remain
		// unchanged.
		Arrays.sort(arr, Comparator.comparingInt(a -> a[0][0]));

		for (int[][] subArray : arr) {
			for (int[] row : subArray) {
				System.out.println(Arrays.toString(row));
			}
			System.out.println();
		}

		// if we wish to short each row of matrices, then we need to iterate each row
		// and
		// call sort individually
		for (int[][] arr2d : arr) {
			for (int[] row : arr2d) {
				Arrays.sort(row);
			}
		}

		for (int[][] subArray : arr) {
			for (int[] row : subArray) {
				System.out.println(Arrays.toString(row));
			}
			System.out.println();
		}
	}

}
