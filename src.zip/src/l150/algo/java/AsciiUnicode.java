package l150.algo.java;

import java.util.HashMap;
import java.util.Map;

public class AsciiUnicode {

	public static void main(String[] args) {

		handleCharsOutsideBMP();
	}

	/*
	 * int index = ch - 'base';
	 * 
	 * where 'base' char is the starting char of the series
	 * 
	 * --lower-case letter: base = 'a'
	 * 
	 * -- upper-case letter: base = 'A'
	 * 
	 * -- digits: base = '0'
	 */
	private int generateArrayIndexForAlphabateAndDigit() {

		char ch = 'G';
		char baseLowerCase = 'a';
		char baseUpperCase = 'A';
		char baseDigit = '0';

		int index;
		if (Character.isLowerCase(ch)) {
			index = ch - baseLowerCase; // 0–25
		} else if (Character.isUpperCase(ch)) {

			index = ch - baseUpperCase + 26; // 26–51
		} else if (Character.isDigit(ch)) {
			index = ch - baseDigit + 52; // 52–61
		} else {
			throw new IllegalArgumentException("Only A-Z, a-z, 0-9 allowed");
		}

		return index;
	}

	//
	private int generateArrayIndexForFullASCII(char ch) {

		// Directly cast char to int, This works because ASCII characters are mapped 1:1
		// with values 0–127.
		int index = (int) ch;

		// For frequency
		int[] freq = new int[128];
		freq[index]++;

		return index;

	}

	/**
	 * <pre>
	 * Working with UNICODE-SAFE options
	 * 
	 * In Java, the char type is a 16-bit unsigned data type. 
	 *  It can represent values from 0 to 65,535 (i.e., 2^16 - 1).
	 * 
	 * Java internally uses UTF-16 encoding to represent Unicode characters.
	 * 
	 * UTF-16 means: Some characters (common ones) are stored in one 16-bit unit (i.e., one char)
	 * 
	 * Others (supplementary characters like emojis, certain Chinese/Hindi letters,
	 * etc.) need two 16-bit units i.e two chars — called a surrogate pair
	 * 
	 * BMP (Basic Multilingual Plane)
	 * Characters from U+0000 to U+FFFF (like 'A', 'z', 'अ', '中') Stored in a single char
	 * For all these characters literal can be used :
	 *  char ch = 'A';
	 * System.out.println((int) ch); // 65
	 * 
	 * so, BMP range is Character.MIN_VALUE to Character.MAX_VALUE
	 * 
	 * 
	 * Supplementary characters (outside BMP)
	 * Range: U+10000 to U+10FFFF (e.g., emojis like 😀, 🧠, ❤️)
	 * 
	 * Require two chars (a surrogate pair) to represent one character
	 * 
	 * So, supplementary characters range is  from Character.MIN_SUPPLEMENTARY_CODE_POINT
	 * to 	Character.MAX_CODE_POINT
	 * </pre>
	 */
	private static void handleCharsOutsideBMP() {

		String emoji = "😀"; // U+1F600

		System.out.println(emoji.length()); // 2 chars (surrogate pair)
		System.out.println(emoji.codePointCount(0, emoji.length())); // 1 actual Unicode character
		
		emoji.codePoints().forEach(
				cp -> {
			System.out.println("emoji code point:"+ cp);		
		});
		
	}

	private static void frequencyMapForCharsOutsideBMP() {
		String input = "😀❤️🧠❤️"; // U+1F600

		Map<Integer, Integer> freq = new HashMap<>();

		input.codePoints().forEach(
				cp -> {
			System.out.println(cp);		
		    freq.put(cp, freq.getOrDefault(cp, 0) + 1);
		});
	}

	

}
