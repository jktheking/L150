package l150.algo.java;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class FileChannelChunkReader {
	private static final int CHUNK_SIZE = 10 * 1024 * 1024; // 10 MB chunks

	public static void main(String[] args) {
		Path filePath = Path.of("large_text_file.txt"); // Update with actual file

		try (FileChannel fileChannel = FileChannel.open(filePath, StandardOpenOption.READ)) {
			long fileSize = fileChannel.size();
			for (long position = 0; position < fileSize; position += CHUNK_SIZE) {
				readChunk(fileChannel, position, Math.min(position + CHUNK_SIZE, fileSize));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void readChunk(FileChannel fileChannel, long start, long end) throws IOException {
		fileChannel.position(start);
		ByteBuffer buffer = ByteBuffer.allocate((int) (end - start));
		fileChannel.read(buffer);
		buffer.flip();
		String chunk = new String(buffer.array());

		// Process chunk (split words, count, etc.)
		System.out.println("Read chunk from " + start + " to " + end);
	}
}
