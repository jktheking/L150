package l150.algo.java;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class ComparingTest {

	static class Employee {
		private int id;
		private String name;
		private double salary;

		public Employee(int id, String name, double salary) {
			this.id = id;
			this.name = name;
			this.salary = salary;
		}

		public int getId() {
			return id;
		}

		public String getName() {
			return name;
		}

		public double getSalary() {
			return salary;
		}

		@Override
		public String toString() {
			return "Employee{id=" + id + ", name='" + name + "', salary=" + salary + "}";
		}
	}

	public static void main(String[] args) {

		List<Employee> employees = Arrays.asList(new Employee(101, "Alice", 75000), new Employee(102, "Bob", 50000),
				new Employee(103, "Charlie", 60000));

		employees.sort((Employee e1, Employee e2) -> Double.compare(e1.getSalary(), e2.getSalary()));

		employees.sort(Comparator.comparing(e -> e.getSalary()));
		employees.sort(Comparator.comparing(Employee::getSalary).thenComparing(Employee::getName));
	}

	static class SalaryComparator implements Comparator<Employee> {

		@Override
		public int compare(Employee o1, Employee o2) {

			return Double.compare(o1.getSalary(), o2.getSalary());
		}
	}

}
