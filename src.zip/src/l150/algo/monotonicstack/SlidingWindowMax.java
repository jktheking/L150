package l150.algo.monotonicstack;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

public class SlidingWindowMax {

	public static void main(String[] args) {
		SlidingWindowMaximum solution = new SlidingWindowMaximum();
		int[] nums = { 1, 3, -1, -3, 5, 3, 6, 7 };
		int k = 3;
		System.out.println(Arrays.toString(solution.maxSlidingWindow(nums, k)));
	}

	/**
	 * Idea is to maintain monotonic stack of size sliding window, And always the
	 * solution is available at bottom of stack. So, we can take deque.
	 * 
	 */
	private static class SlidingWindowMaximum {

		public int[] maxSlidingWindow(int[] nums, int k) {
			if (nums == null || nums.length == 0)
				return new int[0];

			Deque<Integer> deque = new ArrayDeque<>();
			int[] result = new int[nums.length - k + 1];
			int resultIndex = 0;

			for (int i = 0; i < nums.length; i++) {
				// Remove indices of elements not in the current window
				while (!deque.isEmpty() && deque.peek() < i - k + 1) {
					deque.poll();
				}

				// Remove indices of smaller elements from the back of the deque
				while (!deque.isEmpty() && nums[deque.peekLast()] < nums[i]) {
					deque.pollLast();
				}

				// Add the current element's index
				deque.offer(i);

				// Add the maximum for the current window to the result
				if (i >= k - 1) {
					result[resultIndex++] = nums[deque.peek()];
				}
			}

			return result;
		}
	}

}
