package l150.algo.monotonicstack;

/**
 * <pre>
 * Monotonic decreasing stack: All the elements are sorted in decreasing order,
 * top of stack contains lowest element.
 * 
 * 
 * Monotonic Decreasing Stack:
 * 
 * Pop elements from the stack  while  currentElement >= stack.peek().
 * Example Next Greater Element (NGE), Previous Greater Element (NGE)
 * 
 * 
 * Monotonic Increasing Stack:
 * 
 * Pop elements from the stack while  currentElement <= stack.peek().
 * Example Next Smaller Element (NGE), Previous Smaller Element (NGE)
 * 
 * 
 * </pre>
 */
public class MonotonicStackTheory {

}
