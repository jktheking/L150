package l150.algo.monotonicstack;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

/**
 * Since we want NGE in right,
 * 
 * We will pick the NGE from the top of the stack, and we want the next greater
 * in right, so we need to traverse the stack from right. If we traverse from
 * left then we cannot store the
 * 
 * 
 * Decreasing monotonic stack will be used.
 * 
 */

public class NextGreaterElement {

	// We will start iterating from right and NGE will be taken from
	// top of the stack. We want solution in right so have to store the
	// solution on stack in right.
	public int[] findNextGreaterElements(int[] nums) {
		int n = nums.length;
		int[] nge = new int[n]; // Array to store the result

		Deque<Integer> monotonicDecreasing = new ArrayDeque<>(); // Monotonic stack

		for (int i = n - 1; i >= 0; i--) {
			// Remove all elements from the stack smaller than or equal to the current
			// element
			while (!monotonicDecreasing.isEmpty() && nums[i] >= monotonicDecreasing.peek()) {
				monotonicDecreasing.pop();
			}

			// If the stack is not empty, the top element is the next greater element
			nge[i] = monotonicDecreasing.isEmpty() ? -1 : monotonicDecreasing.peek();

			// Push the current element onto the stack
			monotonicDecreasing.push(nums[i]);
		}

		return nge;
	}

	public static void main(String[] args) {
		NextGreaterElement solution = new NextGreaterElement();
		int[] nums = { 4, 5, 2, 10, 8 };
		System.out.println("Next Greater Elements: " + Arrays.toString(solution.findNextGreaterElements(nums)));
		// Output: [5, 10, 10, -1, -1]
	}
}
