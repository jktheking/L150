package l150.algo.monotonicstack;

import java.util.NoSuchElementException;
import java.util.Stack;

/**
 * <pre>
 * push(x) O(1) -->Pushes to both stack and maxStack (if needed). 
 * 
 * pop() O(1) Pops from stack and maxStack (if needed). 
 * 
 * peek() O(1) Returns the top of stack.
 * 
 * peekMax() O(1) Returns the top of maxStack. 
 * 
 * popMax() O(N) Finds max in stack, pops it, and restores elements.
 * 
 * 
 * </pre>
 */
class MaxStack {
	private Stack<Integer> stack;
	private Stack<Integer> monotonicIncMaxStack;

	public MaxStack() {
		stack = new Stack<>();
		monotonicIncMaxStack = new Stack<>();
	}

	public void push(int x) {
		stack.push(x);

		// note: monotonic stack with no pop in while, rather push with satisfying
		// condition
		if (monotonicIncMaxStack.isEmpty() || x >= monotonicIncMaxStack.peek()) {
			monotonicIncMaxStack.push(x);
		}
	}

	public int pop() {
		if (stack.isEmpty())
			throw new NoSuchElementException("Stack is empty");
		int val = stack.pop();
		if (val == monotonicIncMaxStack.peek()) {
			monotonicIncMaxStack.pop();
		}
		return val;
	}

	public int peek() {
		if (stack.isEmpty())
			throw new NoSuchElementException("Stack is empty");
		return stack.peek();
	}

	public int peekMax() {
		if (monotonicIncMaxStack.isEmpty())
			throw new NoSuchElementException("Stack is empty");
		return monotonicIncMaxStack.peek();
	}

	public int popMax() {
		if (monotonicIncMaxStack.isEmpty())
			throw new NoSuchElementException("Stack is empty");

		int max = monotonicIncMaxStack.peek();
		Stack<Integer> buffer = new Stack<>();

		// Pop elements until we reach the max
		while (stack.peek() != max) {
			buffer.push(stack.pop());
		}

		// Remove max element from both stacks
		stack.pop();
		monotonicIncMaxStack.pop();

		// Push back the elements
		while (!buffer.isEmpty()) {
			push(buffer.pop()); // Ensures maxStack remains correct
		}

		return max;
	}

	public static void main(String[] args) {
		MaxStack maxStack = new MaxStack();
		maxStack.push(5);
		maxStack.push(1);
		maxStack.push(5);

		System.out.println(maxStack.peekMax()); // 5
		System.out.println(maxStack.popMax()); // 5
		System.out.println(maxStack.peekMax()); // 5
		System.out.println(maxStack.pop()); // 1
		System.out.println(maxStack.peek()); // 5
	}
}
