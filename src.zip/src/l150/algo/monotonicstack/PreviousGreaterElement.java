package l150.algo.monotonicstack;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

public class PreviousGreaterElement {
	public int[] findPreviousGreaterElements(int[] nums) {
		int n = nums.length;
		int[] pge = new int[n]; // Array to store the result
		Deque<Integer> monotonicDecreasing = new ArrayDeque<>(); // Monotonic stack

		for (int i = 0; i < n; i++) {
			// Remove all elements from the stack smaller than or equal to the current
			// element
			while (!monotonicDecreasing.isEmpty() && nums[i] >= monotonicDecreasing.peek()) {
				monotonicDecreasing.pop();
			}

			// If the stack is not empty, the top element is the previous greater element
			pge[i] = monotonicDecreasing.isEmpty() ? -1 : monotonicDecreasing.peek();

			// Push the current element onto the stack
			monotonicDecreasing.push(nums[i]);
		}

		return pge;
	}

	public static void main(String[] args) {
		PreviousGreaterElement solution = new PreviousGreaterElement();
		int[] nums = { 4, 5, 2, 10, 8 };
		System.out.println("Previous Greater Elements: " + Arrays.toString(solution.findPreviousGreaterElements(nums)));
		// Output: [-1, -1, 5, -1, 10]
	}
}
