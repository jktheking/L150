package l150.algo.tree;

public class TreeMain {

	/**
	 * 
	 * 
	 * Given a binary search tree can you update each node of the BST such that the
	 * new value of the node is equal to its original value plus the sum of all the
	 * values that are greater than that node in the tree.
	 * 
	 * <pre>
		5
	   / \
	  3   8
	 / \   \
	2   4   10
	       /
	      9
	      
	    
	Solution:
	      
	    32
	   /  \
	  39   27
	 /  \    \
	41   36   10
	         /
	        19
	 * 
	 * </pre>
	 * 
	 **/
	public static void main(String[] args) {

		BSTNode node9 = new BSTNode(null, null, 9);
		BSTNode node10 = new BSTNode(node9, null, 10);
		BSTNode node2 = new BSTNode(null, null, 2);
		BSTNode node4 = new BSTNode(null, null, 4);
		BSTNode node3 = new BSTNode(node2, node4, 3);
		BSTNode node8 = new BSTNode(null, node10, 8);
		BSTNode root = new BSTNode(node3, node8, 5);

		printInOrder(root);

		System.out.println("\n");

		reverseInOrderWithSumOfAllGreaterNode(root, new int[1]);

		System.out.println("\n");

		printInOrder(root);

	}

	public static void printInOrder(BSTNode node) {
		if (node == null)
			return;
		printInOrder(node.left);
		System.out.println(node.data);
		printInOrder(node.right);

	}

	public static void reverseInOrderWithSumOfAllGreaterNode(BSTNode node, int[] sum) {
		if (node == null)
			return;
		reverseInOrderWithSumOfAllGreaterNode(node.right, sum);
		sum[0] = node.data + sum[0];
		System.out.println(sum[0]);
		node.data = sum[0];
		reverseInOrderWithSumOfAllGreaterNode(node.left, sum);

	}

	public static class BSTNode {

		private final BSTNode left;
		private final BSTNode right;
		private int data;

		public BSTNode(BSTNode left, BSTNode right, int data) {
			super();
			this.left = left;
			this.right = right;
			this.data = data;
		}

	}

}
