package l150.algo.intervals;

import java.util.Arrays;
import java.util.Comparator;

public class L452MinArrowBurstBallooons2 {

	public int findMinArrowShots(int[][] points) {
		if (points.length == 0)
			return 0;

		// Step 1: Sort balloons by start position
		// Arrays.sort(points, (a, b) -> Integer.compare(a[0], b[0]));
		Arrays.sort(points, Comparator.comparingInt(point -> point[0]));

		int arrows = 1; // We need at least one arrow
		int referenceIntervalEnd = points[0][1]; // End of the first balloon as reference

		// Step 2: Iterate through the remaining balloons
		for (int i = 1; i < points.length; i++) {
			int otherIntervalStart = points[i][0];
			int otherIntervalEnd = points[i][1];

			if (otherIntervalStart <= referenceIntervalEnd) { // Overlapping interval
				referenceIntervalEnd = Math.min(referenceIntervalEnd, otherIntervalEnd); // Minimize overlap
			} else { // Non-overlapping, new arrow needed
				arrows++;
				referenceIntervalEnd = otherIntervalEnd; // Update reference to new interval
			}
		}

		return arrows;
	}

	// Main method to test the function
	public static void main(String[] args) {
		L452MinArrowBurstBallooons2 solution = new L452MinArrowBurstBallooons2();
		int[][] points = { { 10, 16 }, { 2, 8 }, { 1, 6 }, { 7, 12 } };
		System.out.println("Minimum Arrows Needed: " + solution.findMinArrowShots(points));

	}

}
