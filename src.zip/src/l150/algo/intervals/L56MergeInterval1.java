package l150.algo.intervals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class L56MergeInterval1 {

	/**
	 * <pre>
	 * When can we say an interval overlaps with referencePoint interval for
	 * the scenario we sort the intervals based on start ?
	 * 
	 * ReferencePoint Interval : it is first interval
	 * 
	 * CASE_1: 
	 * 
	 *    ----
	 *  ----R----
	 *  
	 *  ---------
	 *  ----R----
	 * 
	 * CASE_2
	 * 
	 * ----
	 *   ----R-----
	 *   
	 *   
	 * CASE_3
	 * 
	 *     ---------
	 * -----R----
	 * 
	 * 
	 * Observation: ReferencePoint interval's end is greater-than-equal-to start of the other interval.
	 * 
	 * Overlapping condition: if(interval[start] <= ReferencedPointInterval[end] )
	 * 
	 * non overlapping condition is just reversed
	 *  
	 *  if(interval[end] < ReferencedPointInterval[start] )
	 * 
	 * </pre>
	 */

	public int[][] merge(int[][] intervals) {
		if (intervals.length <= 1)
			return intervals;

		// Step 1: Sort intervals by their start times
		Arrays.sort(intervals, Comparator.comparingInt(interval -> interval[0]));

		List<int[]> merged = new ArrayList<>();

		// Step 2: Merge intervals
		int[] referencePointInterval = intervals[0];
		merged.add(referencePointInterval);

		for (int[] otherInterval : intervals) {

			if (otherInterval[0] <= referencePointInterval[1]) {
				// Overlapping interval
				referencePointInterval[1] = Math.max(referencePointInterval[1], otherInterval[1]);

			} else {
				// No overlap, move to the next interval
				referencePointInterval = otherInterval;
				merged.add(referencePointInterval);
			}
		}

		return merged.toArray(new int[0][0]);
	}

}
