package l150.algo.dp.mcm;

/**
 * Recursive Formulation:
 * 
 * Given: total eggs n and total floor K
 * 
 * Let say F(n, m) represent the maximum number of floors that can be checked
 * with 'n' eggs and 'm' moves.
 * 
 * Since we have K floor so F(n,m) return K
 * 
 * i.e. K == F(n,m)
 * 
 * 
 * Now lets re-formulate the F(m,n) when we perform the experiment from critical
 * floor and there can be two outcome of the experiment:
 * 
 * 1. egg breaks if we drop above the critical floor
 * 
 * 2. egg survives if we drop below the critical floor
 * 
 * Total floor == floor-above-critical-floor + critical-floor +
 * floor-below-critical-floor
 * 
 * - The term F(e - 1, m - 1) represents the number of floors we can check if
 * the egg breaks (i.e., we have one less egg and one less move).
 * 
 * - The term F(e, m - 1) represents the number of floors we can check if the
 * egg does not break (i.e., we still have the same number of eggs but one less
 * move).
 * 
 * - The +1 accounts for the current floor from which we dropped the egg.
 * 
 * 
 * K == F(n-1,m-1) + 1 + F(n,m-1)
 * 
 * 
 * Total Recursion cases:
 * 
 * F(n,m) == 0 ; if moves(trial) become 0
 * 
 * F(n,m) == m ; if egg is 1, we have to use all m moves(trials)
 * 
 * F(n-1,m-1) + F(n,m-1) + 1 == K ; otherwise
 * 
 * 
 * Note: since the value of 'm' cannot be greater than K, so we are use range
 * based optimization as we do in range sort. we can start testing the value of
 * m from 0 and see when it crosses the K for constraint F(n-1,m-1) + F(n,m-1) +
 * 1 == K
 * 
 * 
 * 
 * 
 */
public class EggDroppingApproach2 {

	public static void main(String[] args) {

	}

	private static int superEggDrop(int n, int k) {
		int m = 0;
		// we can start testing the value of m from 0 and see when it crosses the K for
		// constraint F(n-1,m-1) + F(n,m-1) + 1 == K

		while (superEggDropRecursive(n, m) < k) {
			m++;
		}
		return m;
	}

	private static int superEggDropRecursive(int e, int m) {
		if (m == 0) {
			return 0; // No moves left
		}
		if (e == 1) {
			return m; // With one egg, the best we can do is linear search
		}

		return superEggDropRecursive(e - 1, m - 1) + superEggDropRecursive(e, m - 1) + 1;
	}

}
