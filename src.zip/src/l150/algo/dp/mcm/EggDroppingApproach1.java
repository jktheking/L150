package l150.algo.dp.mcm;

import java.util.Arrays;

/**
 * 1. 'trials-needed in an experiment' equivalent 'employee-estimate'
 * 
 * need to start the experiment from each floor, means we need to perform
 * experiment for i=1 to i= k
 *
 * 
 * 2. min(trials-needed for each floor) equivalent min(employee-estimates)
 * 
 * we need to do experiment from each floor then take the min, c.f. we need to
 * take min of all the worst case estimates given by employees.
 * 
 * 
 */
public class EggDroppingApproach1 {

	public static void main(String[] args) {
		int n = 10; // Number of eggs
		int k = 2000; // Number of floors
		System.out.println(eggDrop(n, k));
	}

	// Function to get the minimum number of trials needed in the worst case
	// with n eggs and k floors using recursion
	private static int eggDrop(int n, int k) {

		// Base cases
		if (k == 0 || k == 1) {
			return k;
		}

		if (n == 1) {
			return k;
		}

		int min = Integer.MAX_VALUE;

		// Try dropping an egg from each floor and calculate the minimum number of
		// trials needed
		for (int i = 1; i <= k; i++) {
			// Calculate the number of trials needed for both outcomes
			int b = eggDrop(n - 1, i - 1);
			int s = eggDrop(n, k - i);
			// get the trails for worst case
			int res = Math.max(b, s);

			// Take the minimum of all the maximum trials needed in the worst case
			if (res < min) {
				min = res;
			}

			System.out.println(
					"break:" + b + " survive:" + s + " res: " + res + " min:" + min + " floor:" + i + ",eggs:" + n);
		}

		// Return the minimum number of trials + 1 (for the current drop)
		return min + 1;
	}

	// transform the above function call where
	// replace the n with egg iterator i.e. row and k with floor iterator i.e.
	// column of dp table
	// Time complexity : O(n*k*k)
	private static int eggDropTabulation(int n, int k) {

		int dp[][] = new int[n + 1][k + 1];

		for (int e = 1; e < dp.length; e++) {
			dp[e][1] = 1;

		}

		for (int f = 1; f < dp[0].length; f++) {
			dp[1][f] = f;

		}

		for (int e = 2; e < dp.length; e++) {

			for (int f = 2; f < dp[0].length; f++) {

				int min = Integer.MAX_VALUE;

				for (int i = 1; i <= f; i++) {
					int b = dp[e - 1][i - 1];
					int s = dp[e][f - i];
					int res = Math.max(b, s);
					min = Math.min(min, res);

				}

				dp[e][f] = min + 1;
			}

		}
		for (int i = 0; i < dp.length; i++) {
			System.out.println(Arrays.toString(dp[i]));
		}

		return dp[n][k];

	}

	// Time complexity: O(n*k*logk)
	// binary search on space with maximum number of trials
	private static int eggDropTabulationBinarySearch(int n, int k) {
		int[][] dp = new int[n + 1][k + 1];

		for (int e = 1; e <= n; e++) {
			dp[e][1] = 1;
		}

		for (int f = 1; f <= k; f++) {
			dp[1][f] = f;
		}

		for (int e = 2; e <= n; e++) {
			for (int f = 2; f <= k; f++) {
				int low = 1, high = f;
				int min = Integer.MAX_VALUE;

				while (low <= high) {
					int mid = (low + high) / 2;
					int breakEgg = dp[e - 1][mid - 1];
					int noBreak = dp[e][f - mid];
					int res = Math.max(breakEgg, noBreak) + 1;

					min = Math.min(min, res);

					if (breakEgg > noBreak) {
						high = mid - 1;
					} else {
						low = mid + 1;
					}
				}

				dp[e][f] = min;
			}
		}

		return dp[n][k];
	}

}