package l150.algo.dp.str;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;

/***
 * Given a string s and a dictionary of strings wordDict, return true if s can
 * be segmented into a space-separated sequence of one or more dictionary words.
 *
 * Note that the same word in the dictionary may be reused multiple times in the
 * segmentation.
 *
 *
 *
 * Example 1:
 *
 * Input: s = "leetcode", wordDict = ["leet","code"] Output: true Explanation:
 * Return true because "leetcode" can be segmented as "leet code". Example 2:
 *
 * Input: s = "applepenapple", wordDict = ["apple","pen"] Output: true
 * Explanation: Return true because "applepenapple" can be segmented as "apple
 * pen apple". Note that you are allowed to reuse a dictionary word. Example 3:
 *
 * Input: s = "catsandog", wordDict = ["cats","dog","sand","and","cat"] Output:
 * false
 *
 *
 */

/***
 * <pre>
 * String structure: s =cr
 *
 * Where c is the word from word dictionary.
 *
 *  Word Break function def: WB(s,i,dictionary)
 *
 * for all word found in dictionary starting with c
 *
 * Two cases:
 *
 *   if c is the part of the solution
 *         then  WB(s, i+dictionary_word.length, dictionary) will also return true
 *   else
 *       false
 *
 * Base Case: if input string is empty, then it can be formed always with any dictionary word.
 *
 * </pre>
 *
 */
public class WordBreak5 {

	public static void main(String[] args) {

		String s = "catsanddog";
		List<String> dictionary = List.of("sand", "dog", "and", "cats", "cat");

		System.out.println(wordBreakrecursion(s, dictionary));

	}

	private static boolean wordBreakrecursion(String s, List<String> wordDict) {

		// WB(s, 0, wordDict);

		return wbMemo(s, 0, wordDict, new Boolean[s.length()]);

	}

	private static boolean wb(String inputStr, int i, List<String> dictionary) {

		// when we reached the end of the string, means input string becomes empty
		if (i == inputStr.length()) {
			return true;
		}

		boolean canBreak = false;
		for (String dicWord : dictionary) {
			// here wb will come with true/ false; means two calls are there so, time
			// complexity will be 2^n
			if (inputStr.substring(i).startsWith(dicWord) && wb(inputStr, i + dicWord.length(), dictionary)) {
				// means we have gotten one solution
				canBreak = canBreak || true;
			}

		}

		return canBreak;

	}

	// since i is the variable in WB() function, so we will have inputStr.length
	// unique subproblems
	private static boolean wbMemo(String inputStr, int i, List<String> dictionary, Boolean[] memo) {

		// when we reached the end of the string, means input string becomes empty
		if (i == inputStr.length()) {
			return true;
		}

		if (memo[i] != null) {
			System.out.println("inside if:" + i);
			return memo[i];
		}

		System.out.println("outside if:" + i);

		for (String dicWord : dictionary) {
			// there could be multiple solutions
			// if we have d, dictionary word and has max of m length; then first predicate
			// inputStr.substring(i).startsWith(dicWord) will take in worst case O(d*m)
			// second predicate wbMemo(inputStr, i + dicWord.length(), dictionary, memo);
			// will have
			// 0 to inputstr.length unique problems, so total time complexity will be
			// O(n*d*m)
			if (inputStr.substring(i).startsWith(dicWord) && wbMemo(inputStr, i + dicWord.length(), dictionary, memo)) {
				// means we have gotten one solution
				System.out.println(dicWord);
				memo[i] = true;
				return true;
			}

		}

		memo[i] = false;
		System.out.println(Arrays.toString(memo));

		return false;

	}

	/*
	 * 
	 * This will give TLE for s =
	 * "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab"
	 * 
	 * wordDict =
	 * ["a","aa","aaa","aaaa","aaaaa","aaaaaa","aaaaaaa","aaaaaaaa","aaaaaaaaa",
	 * "aaaaaaaaaa"]
	 */
	private static boolean wbDifferentSolution(String inputStr, List<String> dictionary) {

		Deque<Integer> stack = new ArrayDeque<>();
		stack.push(0);

		while (!stack.isEmpty()) {

			int idx = stack.pop();

			for (String word : dictionary) {
				if (inputStr.substring(idx).startsWith(word)) {
					int nextIdx = idx + word.length();

					if (nextIdx == inputStr.length()) {
						return true;
					}

					stack.push(nextIdx);

				}

			}

		}
		return false;
	}

}
