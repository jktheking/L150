package l150.algo.dp.kadane;

/**
 * https://leetcode.com/problems/maximum-subarray/description/
 *
 * Given an integer array nums, find the subarray with the largest sum, and
 * return its sum.
 *
 * Example 1:
 *
 * Input: nums = [-2,1,-3,4,-1,2,1,-5,4] Output: 6 Explanation: The subarray
 * [4,-1,2,1] has the largest sum 6.
 *
 * Example 2:
 *
 * Input: nums = [1] Output: 1 Explanation: The subarray [1] has the largest sum
 * 1.
 *
 * Example 3:
 *
 * Input: nums = [5,4,-1,7,8] Output: 23 Explanation: The subarray [5,4,-1,7,8]
 * has the largest sum 23.
 *
 */
public class MaximumSumSubArray0 {

	public static void main(String[] args) {

	}

	public int maxSubArrayRecursive(int[] nums) {

		return maxSumSubArrayRecursive(nums, 1, nums[0]);

	}

	/**
	 * <pre>
	 * Since it's the class of subArray(c.f. subset),as all the problem space can be
	 * generated using subset, so we will use 'S = cr' and will try to
	 * include/exclude with all the native cases of the problem.
	 *
	 * Two fundamental choices:
	 * 1. apply currentElement with running contiguousPrefix
	 * 2. start the contiguousPrefix from currentElement itself
	 *
	 * here native cases can be built on c and contiguousPrefixSum
	 *
	 *
	 * 1. both c && contiguousPrefixSum are positive
	 *
	 * 2. both c && contiguousPrefixSum are negative
	 *
	 * 3. either of one is positive/negative
	 *
	 * 4. c is zero
	 *
	 * since for all the above cases we need to perform sum; so we can make the code
	 * case insensitive.
	 *
	 * Note: Here memoization and tabulation depends on contiguousPrefixSum value,
	 * which can be arbitrarily large/small. So, this will not lead to the proper
	 * solution. Thus, we need to come up with some other way.
	 *
	 * </pre>
	 */
	public static int maxSumSubArrayRecursive(int[] nums, int idx, int contiguousPrefixSum) {

		if (idx == nums.length)
			return contiguousPrefixSum;

		// apply currentElement with running contiguousPrefix
		// previous contiguousPrefix is included with current element
		int incSum = maxSumSubArrayRecursive(nums, idx + 1, contiguousPrefixSum + nums[idx]);

		// start the contiguousPrefix from currentElement itself
		// previous contiguousPrefix is excluded from current element
		int excSum = maxSumSubArrayRecursive(nums, idx + 1, nums[idx]);

		return Math.max(contiguousPrefixSum, Math.max(incSum, excSum));
	}

	/**
	 * <pre>
	 * The optimization is on the fact the we are starting new local
	 * contiguousPrefixSum when we don't consider the current-element as part of the
	 * pre-existing contiguousPrefixSum.
	 *
	 * Strategy : Try operation of currentElement 'c' with 'contiguousPrefixSum' and
	 * compare it directly with currentElement, and see which is winner
	 * currentElement alone or 'contiguousPrefixSum + currentElement'.
	 *
	 * localWinner = winner(prefix OP c, c)
	 * globalWinner = winner(localWinner, globalWinner)
	 *
	 * </pre>
	 *
	 */
	public static int maxSubArrayKadane(int[] nums) {

		int localContiguousMaxPrefixSum = nums[0];
		int globalMaxSubArraySum = nums[0];

		for (int i = 1; i < nums.length; i++) {
			// post adding the currentElement to contiguousPrefixSum, if the local
			// contiguousPrefixSum becomes smaller than the currentElement, then need to
			// reset the local contiguousPrefixSum; this is similar to reset that we are
			// doing in recursive version when currentElement is not considered for
			// local contiguousPrefixSum i.e. exclude invocation
			localContiguousMaxPrefixSum = Math.max(localContiguousMaxPrefixSum + nums[i], nums[i]);
			globalMaxSubArraySum = Math.max(globalMaxSubArraySum, localContiguousMaxPrefixSum);
		}

		return globalMaxSubArraySum;
	}

}
