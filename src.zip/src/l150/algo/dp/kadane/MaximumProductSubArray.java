package l150.algo.dp.kadane;

/***
 *
 * Given an integer array nums, find a subarray that has the largest product,
 * and return the product.
 *
 * The test cases are generated so that the answer will fit in a 32-bit integer.
 *
 *
 *
 * Example 1:
 *
 * Input: nums = [2,3,-2,4] Output: 6 Explanation: [2,3] has the largest product
 * 6. Example 2:
 *
 * Input: nums = [-2,0,-1] Output: 0 Explanation: The result cannot be 2,
 * because [-2,-1] is not a subarray.
 *
 *
 *
 */
public class MaximumProductSubArray {

	public static void main(String[] args) {

		int[] nums = new int[] { 0, 10, 10, 10, -10, 10, 10, 10, 0 };

		System.out.println(maxProductRecursive(nums));
	}

	public static int maxProductRecursive(int[] nums) {

		return maxProductRecursive(nums, 1, nums[0]);

	}

	/**
	 * <pre>
	 * Since it's the class of subArray,as all the problem space can be generated
	 * using contiguous subset, so we will use 'S = cr' and will try to
	 * include/exclude with all the native cases of the problem.
	 *
	 * Two fundamental choices:
	 * --------------------------
	 * 1. apply currentElement with running contiguousPrefix
	 * 2. start the contiguousPrefix from currentElement itself
	 *
	 * here native cases can be built on c and contiguousPrefixProduct
	 *
	 * 1. both c && contiguousPrefixProduct are positive
	 *
	 * 2. both c && contiguousPrefixProduct are negative
	 *
	 * 3. either of one is positive/negative
	 *
	 * 4. c is zero
	 *
	 * since for all the of cases we need to perform product; so we can make the
	 * code case insensitive.
	 *
	 * Note: Here memoization and tabulation depends on contiguousPrefixProduct
	 * value, which can be arbitrarily large/small. So, this will not lead to the
	 * proper solution. Thus, we need to come up with some other way.
	 *
	 * </pre>
	 */
	private static int maxProductRecursive(int[] nums, int idx, int contiguousPrefixProduct) {

		if (idx == nums.length) {
			return contiguousPrefixProduct;
		}

		int incProduct = maxProductRecursive(nums, idx + 1, contiguousPrefixProduct * nums[idx]);

		// reset the contiguousPrefixProduct as current element is excluded from the
		// contiguousPrefixProduct so far
		int excProduct = maxProductRecursive(nums, idx + 1, nums[idx]);

		return Math.max(contiguousPrefixProduct, Math.max(incProduct, excProduct));

	}

	private static int maxProductKadane(int[] nums) {

		int localContiguousMaxPrefixProduct = nums[0];
		int localContiguousMinPrefixProduct = nums[0];
		int globalMaxSubArrayProduct = nums[0];

		for (int i = 1; i < nums.length; i++) {
			// since, current element is -ve, and it changes the max to min post
			// multiplication, so swap the min with max
			if (nums[i] < 0) {
				int temp = localContiguousMaxPrefixProduct;
				localContiguousMaxPrefixProduct = localContiguousMinPrefixProduct;
				localContiguousMinPrefixProduct = temp;
			}

			localContiguousMaxPrefixProduct = Math.max(localContiguousMaxPrefixProduct * nums[i], nums[i]);
			localContiguousMinPrefixProduct = Math.min(localContiguousMinPrefixProduct * nums[i], nums[i]);

			globalMaxSubArrayProduct = Math.max(localContiguousMaxPrefixProduct, globalMaxSubArrayProduct);
		}
		return globalMaxSubArrayProduct;

	}

}
