package l150.algo.dp.kadane;

public class KadaneApplication {

	// Maximum Sum Circular array
	// https://leetcode.com/problems/maximum-sum-circular-subarray/

	/**
	 * Concept:
	 *
	 * 1. In a circular array, the maximum subarray sum can either be the maximum
	 * subarray sum in the non-circular array (i.e., a subarray that does not wrap
	 * around), or it can be the total sum of the array minus the minimum subarray
	 * sum (i.e., a subarray that does wrap around).
	 *
	 * 2. If section-x represents the maxSubarraySum, then if we combine the
	 * remaining parts of the array together, they represent the minSubarraySum.
	 * This is because each element in the array must either be part of the
	 * maxSubarraySum or not. If it is part of the maxSubarraySum, then section-x
	 * includes that element.
	 *
	 * 3. Therefore, totalSum = maxSubarraySum + minSubArraySum. Rearranging this,
	 * we get maxSubarraySum = totalSum - minSubArraySum when considering the
	 * circular nature of the array.
	 *
	 * 4. To find the maximum sum of a circular subarray, we compare the maximum
	 * subarray sum in the non-circular array with the total sum of the array minus
	 * the minimum subarray sum. The result is the maximum of these two values.
	 */
	public static int maxSubarraySumCircular(int[] nums) {

		/*
		 * 1. Find the Maximum Subarray Sum Using Kadane’s Algorithm If the subarray
		 * does not wrap around, the answer is simply the Maximum Subarray Sum found
		 * using Kadane’s Algorithm.
		 * 
		 * 2. Find the Minimum Subarray Sum Using Kadane’s Algorithm If the subarray
		 * wraps around, then the maximum sum subarray is found by removing the minimum
		 * sum subarray from the total sum of the array.
		 * 
		 * 3. Handle the Special Case If all elements are negative, the "circular sum"
		 * approach will give 0, which is incorrect. In this case, the answer should be
		 * the maximum single element.
		 * 
		 * 
		 * 
		 */

		int totalSum = 0;
		int maxSum = Integer.MIN_VALUE, minSum = Integer.MAX_VALUE;
		int currentMax = 0, currentMin = 0;

		for (int num : nums) {
			totalSum += num;

			// Kadane's Algorithm for Maximum Sum Subarray
			currentMax = Math.max(currentMax + num, num);
			maxSum = Math.max(maxSum, currentMax);

			// Kadane's Algorithm for Minimum Sum Subarray
			currentMin = Math.min(currentMin + num, num);
			minSum = Math.min(minSum, currentMin);
		}

		// If all elements are negative, return maxSum
		if (maxSum < 0)
			return maxSum;

		// Return the maximum of maxSum and circularMaxSum
		return Math.max(maxSum, totalSum - minSum);

	}

	// https://leetcode.com/problems/maximum-alternating-subarray-sum/description/
	// https://www.geeksforgeeks.org/maximum-sum-alternating-subarray/
	public static int maxiumSumAlternatingSubArray(int[] nums) {
		return 0;
	}

	// https://leetcode.com/problems/maximum-alternating-subsequence-sum/description/
	public static int maxiumSumAlternatingSubSequence(int[] nums) {
		return 0;
	}

	/**
	 * Further Memoization, tabulation can be done very easily.
	 *
	 */
	public static int maxiumSumAlternatingSubSequenceRec(int[] nums, int idx, boolean isPositive) {
		// when array is empty maxiumSumAlternatingSubSequence will be zero
		if (nums.length == idx) {
			return 0;
		}

		int curr = isPositive ? nums[idx] : -nums[idx];
		int incSum = curr + maxiumSumAlternatingSubSequenceRec(nums, idx + 1, !isPositive);
		int excSum = maxiumSumAlternatingSubSequenceRec(nums, idx + 1, isPositive);

		return Math.max(incSum, excSum);

	}

	// further this method can be optimized on space, we can replace dp table with
	// requisite variables
	public static long maxiumSumAlternatingSubSequenceTab(int[] nums) {
		// on i we will keep nums element, and on j will represent true, false
		// dp[i][0] represents solution for true state, i.e. max of inc, exc when number
		// is considered +ve
		// dp[i][1] represents solution for false state i.e. max of inc, exc when number
		// is considered -ve

		long[][] dp = new long[nums.length + 1][2];

		for (int i = 1; i < dp.length; i++) {

			// for positive state; i.e. isPositive is true
			long positiveInc = nums[i - 1] + dp[i - 1][1];
			long positiveExc = dp[i - 1][0];
			dp[i][0] = Math.max(positiveInc, positiveExc);

			// for negative state, i.e. isPositive is false
			long negativeInc = -nums[i - 1] + dp[i - 1][0];
			long negativeExc = dp[i - 1][1];
			dp[i][1] = Math.max(negativeInc, negativeExc);
		}

		return Math.max(dp[dp.length - 1][0], dp[dp.length - 1][1]);

	}

}
