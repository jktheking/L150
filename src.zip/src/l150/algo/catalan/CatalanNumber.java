package l150.algo.catalan;

/**
 * 
 * Cn= (2n)!/(n+1)!n! ​
 * 
 * Cn = C0Cn-1 + C1Cn-2 + .. + Cn-1C0
 *
 * C0 = 1, C1 = 1, C2 = 2, C3 = 5
 *
 * Applications of Catalan Numbers:
 * 
 * Balanced Parentheses – Number of valid expressions with 𝑛 n pairs of
 * parentheses.
 * 
 * Binary Search Trees (BSTs) – Number of BSTs with 𝑛 n distinct keys.
 * 
 * Polygon Triangulation – Ways to divide an 𝑛 + 2 n+2-sided polygon into
 * triangles.
 * 
 * Full Binary Trees – Number of full binary trees with 𝑛 n internal nodes.
 * 
 * Stack Permutations – Valid ways to push/pop a sequence into a stack.
 * 
 */
public class CatalanNumber {

	// 2^n
	public int catalanRecursive(int n) {
		if (n <= 1)
			return 1; // Base case

		int res = 0;
		for (int i = 0; i < n; i++) {
			res += catalanRecursive(i) * catalanRecursive(n - i - 1);
		}
		return res;
	}

	/**
	 * recursion to DP mapping:
	 * 
	 * method parameter n represent levels: catalanRecursive(n), so outer for loop
	 * will be on 'n'. Now, inner for loop for (int i = 0; i < n; i++) is dependent
	 * on level n i.e. "i<n"
	 * 
	 */
	// n^2
	public int catalanDP(int n) {
		int[] dp = new int[n + 1];
		dp[0] = dp[1] = 1;

		for (int level = 2; level <= n; level++) {
			for (int i = 0; i < level; i++) {
				dp[level] += dp[i] * dp[level - i - 1];
			}
		}
		return dp[n];
	}

	// Order Ci+1 = Ci * (2*(2i +1))i+2
	public int catalanBinomial(int n) {
		long res = 1;
		for (int i = 0; i < n; i++) {
			res = res * (2 * (2 * i + 1)) / (i + 2);
		}
		return (int) res;
	}

}
