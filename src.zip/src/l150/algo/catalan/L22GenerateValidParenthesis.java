package l150.algo.catalan;

import java.util.ArrayList;
import java.util.List;

//https://leetcode.com/problems/generate-parentheses/

//https://www.youtube.com/watch?v=s9fokUqJ76A
//https://www.youtube.com/watch?v=n-8R95-5MXw

/**
 * Recursively generates all valid combinations of balanced parentheses.
 * 
 * ## Parameters to consider for recursion tree generation:
 * 
 * - **Input State** : [remaining_open, remaining_close] - **Output Metadata** :
 * [consumed_open, consumed_close]
 * 
 * ## Available Choices: At each step, we have two options: 1. **OPEN_OPTION** →
 * Add an opening parenthesis `'('`, decreasing `remaining_open` 2.
 * **CLOSE_OPTION** → Add a closing parenthesis `')'`, decreasing
 * `remaining_close`
 * 
 * ## Condition for CLOSE_OPTION: - A closing parenthesis `')'` can only be
 * placed **after** an opening `'('` has been placed. - This ensures that at any
 * point: `consumed_close ≤ consumed_open` - In other words, `remaining_close`
 * should never be greater than `remaining_open`, as that would lead to invalid
 * sequences.
 * 
 * ## Base Case: - When both `remaining_open == 0` and `remaining_close == 0`,
 * we have formed a valid sequence. - Store the generated string in the result
 * set.
 * 
 * ## Time Complexity: - worst case: O(2^(2n))
 * 
 * It's important to note that while the upper bound of generating all possible
 * sequences of n pairs of parentheses is O(2^(2n)), the backtracking approach
 * efficiently prunes invalid sequences, leading to the reduced time complexity
 * of O(4^n / √n) ==> n-th Catalan number.
 * 
 */
public class L22GenerateValidParenthesis {

	public static List<String> generateParentheses(int n) {
		List<String> result = new ArrayList<>();
		generateParentheses(result, "", 0, 0, n);
		return result;
	}

	static void generateParentheses(List<String> ans, String str, int open, int close, int max) {

		if (str.length() == 2 * max) {
			ans.add(str);
			return;
		}

		// for opening
		if (open < max) {
			generateParentheses(ans, str + "(", open + 1, close, max);
		}

		// for closing
		if (close < open) {
			generateParentheses(ans, str + ")", open, close + 1, max);
		}

	}

	public static List<String> generateParentheses1(int n) {
		List<String> result = new ArrayList<>();
		backtrack(result, new StringBuilder(), 0, 0, n);
		return result;
	}

	private static void backtrack(List<String> result, StringBuilder current, int open, int close, int max) {
		if (current.length() == max * 2) {
			result.add(current.toString());
			return;
		}

		if (open < max) {
			current.append('(');
			backtrack(result, current, open + 1, close, max);
			current.deleteCharAt(current.length() - 1);
		}

		if (close < open) {
			current.append(')');
			backtrack(result, current, open, close + 1, max);
			current.deleteCharAt(current.length() - 1);
		}
	}

}
