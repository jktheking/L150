package l150.algo.graph;

/**
 * Total degree of undirected graph: 2 * Edge. Since an edge can connect at max
 * two nodes, so total degree cannot be more than twice the edge count.
 * 
 ***/
public class Theory {

}
