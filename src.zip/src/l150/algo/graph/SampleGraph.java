package l150.algo.graph;

import java.util.ArrayList;
import java.util.List;

public class SampleGraph {

	public static List<Edge>[] GRAPH_CONNECTED_COMPONENT = prepareConnectedComponentInput();

	public static List<Edge>[] prepareConnectedComponentInput() {
		@SuppressWarnings("unchecked")
		List<Edge>[] input = new ArrayList[7];
		input[0] = List.of(new Edge(0, 1, 10));
		input[1] = List.of(new Edge(1, 0, 10));
		input[2] = List.of(new Edge(2, 3, 10));
		input[3] = List.of(new Edge(3, 2, 10));
		input[4] = List.of(new Edge(4, 5, 10), new Edge(4, 6, 10));
		input[5] = List.of(new Edge(5, 4, 10), new Edge(5, 6, 10));
		input[6] = List.of(new Edge(6, 5, 10), new Edge(6, 4, 10));
		return input;
	}

}
