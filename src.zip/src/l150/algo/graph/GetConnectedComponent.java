package l150.algo.graph;

import java.util.ArrayList;
import java.util.List;

public class GetConnectedComponent {

	public static void main(String[] args) {

		List<Edge>[] graph = SampleGraph.GRAPH_CONNECTED_COMPONENT;

		boolean visited[] = new boolean[graph.length];
		List<List<Integer>> comps = new ArrayList<>();

		for (int i = 0; i < graph.length; i++) {

			List<Integer> comp = new ArrayList<>();
			generateConnectedComponent(graph, i, comp, visited);
			comps.add(comp);

		}

	}

	private static void generateConnectedComponent(List<Edge>[] graph, int src, List<Integer> comp, boolean visited[]) {

		// mark the node as visited and add the node in connected list
		visited[src] = true;
		comp.add(src);

		for (Edge edge : graph[src]) {
			if (!visited[edge.getNbr()]) {
				generateConnectedComponent(graph, edge.getNbr(), comp, visited);
			}

		}
	}

}
