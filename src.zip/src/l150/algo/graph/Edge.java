package l150.algo.graph;

public class Edge {

	private final int src;
	private final int nbr;
	private final int weight;

	public Edge(int src, int nbr, int weight) {
		super();
		this.src = src;
		this.nbr = nbr;
		this.weight = weight;
	}

	public Edge(int src, int nbr) {
		this(src, nbr, 0);
	}

	public int getSrc() {
		return src;
	}

	public int getNbr() {
		return nbr;
	}

	public int getWeight() {
		return weight;
	}

}
