package l150.algo.graph.dfs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class RecursionSimulation1 {

	private static class Recursion {

		private static class Node {
			private int value;
			private List<Node> children;
		}

		/**
		 * Note: word PRE-RECURSION AREA, IN-RECURSION AREA and POST-RECURSION AREA is
		 * for children of the current parent. Means parent will see PRE, IN and POST
		 * AREA among child siblings.
		 * 
		 * Eg. PRE_CHILD1, PRE_CHILD2 so on.
		 * 
		 * @see generational_tour_representation_1.pdf
		 * 
		 */
		void rec(Node node) {
			if (node == null)
				return;

			// 1. PRE-RECURSION AREA of rec(n)
			// Code executed before any recursive calls for children.
			// This is the "first visit" to the parameter rec(n).
			System.out.println("Entering node: " + node.value);

			// 2. IN-VOCATION OF RECURSION
			for (Node child : node.children) {
				// recursion invocation inside the for loop: so we will have child branches.
				rec(child);
				/**
				 * 
				 * (Optional) IN-ORDER AREA of rec(n): Code executed between recursive calls.
				 * Once the child of rec(n) returns, before exiting the for loop it invokes the
				 * next-child-sibling-recursive call, suspending the rec(n) instructions on the
				 * control of the for-loop.
				 * 
				 * So this is the area-between the two child-sibling-recursive calls.
				 * 
				 * 
				 * Example: lets say rec(x) has 3 children: rec_1(null), rec_2(null),
				 * rec_3(null) means all have null as child. So, rec_1(null) will return
				 * immediately because of base case and goes for IN-ORDER AREA-of-rec(x) lying
				 * between rec_1(null) and rec_2(null), and cause invocation of rec_2(null)
				 * which returns and goes to IN-ORDER AREA-of-rec(x) lying between rec_2(null)
				 * and rec_3(null) and cause invocation of rec_3(null) which returns
				 * immediately. And again goes to IN-ORDER AREA-of-rec(x) which lies after
				 * rec_3(null). Now for loop exits and cause execution of POST-AREA-of-rec(x)
				 * and eventually rec(x) returns.
				 * 
				 * This IN-ORDER AREA is optional not executed for null child.
				 **/

			}

			// 3. POST-RECURSION AREA of rec(n)
			// Code executed after all recursive calls for its children have completed.
			// This is the "last visit" to a node before returning to its parent.
			System.out.println("Exiting node: " + node.value);

			/**
			 * BACKTRACKING:
			 * 
			 * This is also the location of backtracking, means un-marking the visited data
			 * structure of previous dfs-stack, which is going to be re-used during
			 * exploration of other_remaining_options in next sibling dfs-stack.
			 * 
			 * @see permuteByFixingPosition
			 * 
			 */
		}

		private static void permuteByFixingPosition(char[] input, boolean[] visitedInput, char[] output, int posIdx) {

			if (posIdx == output.length) {
				System.out.println(Arrays.toString(output));
				return;
			}

			// applying input as options
			for (int i = 0; i < input.length; i++) {
				// visited helps applying remaining input as options on next level
				if (!visitedInput[i]) {
					output[posIdx] = input[i];

					// we are using the i-th input option, so on next level we cannot use this i-th
					// input as option.
					visitedInput[i] = true;
					permuteByFixingPosition(input, visitedInput, output, posIdx + 1);
					// this part represents return of the recursion branch
					output[posIdx] = Character.MIN_VALUE;
					visitedInput[i] = false;

				}

			}

		}

	}

	/**
	 * <pre>
	 * Refer: generational_tour_represenation_1.pdf
	 * 
	 * Note: the sibling child-recursion branches are represented as child edges
	 * connecting to the parent node in graph representation.
	 * 
	 * start-point of any "execution-area" is represented by "stack.top", and
	 * end-point is represented by "stack.pop".
	 * 
	 * PRE-AREA can be represented by activity before push of the given
	 * 'execution-area' and POST-AREA can be represented by activity after pop of
	 * the given 'execution-area'
	 * 
	 * In general we push start-point of all the siblings "child-execution-area"
	 * present at the given "parent-execution-area", all together (optionally in reverse-order
	 * to follow the recursion-oder). Now, in next iteration of while loop, we will
	 * encounter first child.
	 * 
	 * Sometime, we need to do some task in IN-ORDER area or when we simulate
	 * recursive IN-ORDER area, we use "childIndex" as separate state and children
	 * are pushed one by one in the stack on next iteration of the while loop.
	 * 
	 * 
	 * Question:
	 * When to pop the "parent-execution-area": before pushing-in any of it's children or after
	 * popping out all the children DFS-stack ?
	 * 
	 * CASE_A: popping "parent-execution-area" before pushing-in any of it's children:
	 * - If we don't need to represent the IN-ORDER area.
	 * 
	 * CASE_B: popping "parent-execution-area" after it's children DFS-stack. We
	 * keep the parent-execution-area in the stack and don't pop it until the last
	 * child DFS-stack is traversed and popped.
	 * 
	 * -If we want to simulate the recursion stack pop order.
	 * -If we want to simulate the IN-ORDER area or want to do something in IN-ORDER
	 * area.
	 * 
	 * </pre>
	 * 
	 */
	private static class TreeTraversalSimulation {

		private static class TreeNode {
			int val;
			List<TreeNode> children; // For general trees

			public TreeNode(int val) {
				this.val = val;
				this.children = new ArrayList<>();
			}

			public void addChild(TreeNode child) {
				this.children.add(child);
			}

			@Override
			public String toString() {
				return String.valueOf(val);
			}
		}

		private static class StackFrame {
			TreeNode node;
			int childIndex; // To keep track of which child we are processing

			public StackFrame(TreeNode node, int childIndex) {
				this.node = node;
				this.childIndex = childIndex;
			}
		}

		// Simulates PRE, IN, and POST order using a stack for a general tree
		// Here we are using childIndex for state handling as well
		// clildIndex == 0 represents PRE;
		// childIndex > 0 && childIndex < node.children.size() represents IN, from here
		// we invoke PRE on next child.
		// childIndex >= node.children.size() represents POST
		public void simulateEulerTourTraversal(TreeNode root) {
			if (root == null) {
				return;
			}

			Stack<StackFrame> stack = new Stack<>();
			stack.push(new StackFrame(root, 0)); // Start with the root, ready to process its 0th child

			System.out.println("--- Euler Tour Simulation (PRE, IN, POST) ---");

			while (!stack.isEmpty()) {
				StackFrame currentFrame = stack.peek(); // Look at the top of the stack without removing

				// PRE-order visit: When we first encounter the node
				if (currentFrame.childIndex == 0) {
					System.out.println("PRE-order visit: " + currentFrame.node.val);
				}

				// Check if there are more children to visit
				if (currentFrame.childIndex < currentFrame.node.children.size()) {
					// IN-order visit (conceptual): Between visiting children
					// This is where we "return" from a child and are about to go to the next.
					// For a general tree, IN-order is harder to define precisely as a single point
					// unless you tie it to the specific child being processed.
					// Here, we'll conceptually place it *before* pushing the next child.

					// we can provide the children in reverse order of list, so that the first one
					// will be on top of the stack
					TreeNode nextChild = currentFrame.node.children.get(currentFrame.childIndex);
					System.out.println("  (Conceptual IN-order for " + currentFrame.node.val + " before visiting child "
							+ nextChild.val + ")");

					currentFrame.childIndex++; // Increment child index for the current node's frame
					stack.push(new StackFrame(nextChild, 0)); // Push the child onto the stack, ready to process its 0th
					// child
				} else {
					// All children have been visited (or there were no children)
					// POST-order visit: After all children have been processed
					stack.pop(); // Remove the current node's frame from the stack
					System.out.println("POST-order visit: " + currentFrame.node.val);
				}
			}
		}

		// Main method to run the example
		public static void main(String[] args) {
			// Create a sample tree:
			// 1
			// /|\
			// 2 3 4
			// / \
			// 5 6
			// /
			// 7

			TreeNode node1 = new TreeNode(1);
			TreeNode node2 = new TreeNode(2);
			TreeNode node3 = new TreeNode(3);
			TreeNode node4 = new TreeNode(4);
			TreeNode node5 = new TreeNode(5);
			TreeNode node6 = new TreeNode(6);
			TreeNode node7 = new TreeNode(7);

			node1.addChild(node2);
			node1.addChild(node3);
			node1.addChild(node4);

			node2.addChild(node5);
			node2.addChild(node6);

			node5.addChild(node7);

			TreeTraversalSimulation simulator = new TreeTraversalSimulation();
			simulator.simulateEulerTourTraversal(node1);
		}

	}

	private static class TreeTraversalSimulationWithEnum {

		// Represents a node in the tree
		class TreeNode {
			int val;
			List<TreeNode> children; // For general trees

			public TreeNode(int val) {
				this.val = val;
				this.children = new ArrayList<>();
			}

			public void addChild(TreeNode child) {
				this.children.add(child);
			}

			@Override
			public String toString() {
				return String.valueOf(val);
			}
		}

		// Enum to represent the state of processing for a node
		enum VisitState {
			PRE, // First visit to the node (before any children)
			IN, // Returning from a child, or preparing to visit next child (conceptual for
			// general trees)
			POST // All children processed, ready to leave the node's subtree
		}

		// Represents the state of a node on our custom stack
		private static class StackFrame {
			TreeNode node;
			int childIndex; // To keep track of which child we are processing
			VisitState state; // To explicitly track the current visit state

			public StackFrame(TreeNode node, int childIndex, VisitState state) {
				this.node = node;
				this.childIndex = childIndex;
				this.state = state;
			}
		}

		// Simulates PRE, IN, and POST order using a stack for a general tree
		public void simulateEulerTourTraversal(TreeNode root) {
			if (root == null) {
				return;
			}

			Stack<StackFrame> stack = new Stack<>();
			// Start with the root, in PRE state, ready to process its 0th child
			stack.push(new StackFrame(root, 0, VisitState.PRE));

			System.out.println("--- Euler Tour Simulation (PRE, IN, POST) with Enum ---");

			while (!stack.isEmpty()) {
				StackFrame currentFrame = stack.peek(); // Look at the top of the stack without removing

				switch (currentFrame.state) {
				case PRE:
					System.out.println("PRE-order visit: " + currentFrame.node.val);
					// Move to the IN state for this node, as we are about to process its children
					currentFrame.state = VisitState.IN;
					break;

				case IN:
					// Check if there are more children to visit
					if (currentFrame.childIndex < currentFrame.node.children.size()) {
						TreeNode nextChild = currentFrame.node.children.get(currentFrame.childIndex);
						System.out.println("  (Conceptual IN-order for " + currentFrame.node.val
								+ " before visiting child " + nextChild.val + ")");

						currentFrame.childIndex++; // Increment child index for the current node's frame
						// Push the child onto the stack, starting its own PRE state
						stack.push(new StackFrame(nextChild, 0, VisitState.PRE));
					} else {
						// All children have been visited (or there were no children)
						// Move to the POST state for this node
						currentFrame.state = VisitState.POST;
					}
					break;

				case POST:
					// All children processed, ready to leave this node's subtree
					System.out.println("POST-order visit: " + currentFrame.node.val);
					stack.pop(); // Remove the current node's frame from the stack
					break;
				}
			}
		}

	}

	private static class DFSStackSimulation {

		// Enum to represent the three states of DFS traversal
		enum DFSState {
			PRE, // Entering a node (before processing children)
			IN, // Processing children (between recursive calls)
			POST // Exiting a node (after all children processed)
		}

		// Represents a node in our traversal with its current state
		static class StackFrame {
			int node;
			DFSState state;
			int childIndex; // which child we're currently processing

			private StackFrame(int node, DFSState state, int childIndex) {
				this.node = node;
				this.state = state;
				this.childIndex = childIndex;
			}
		}

		private List<List<Integer>> adj; // adjacency list
		private boolean[] visited;
		private List<String> eulerTour; // tracks the complete traversal path
		private List<Integer> preOrder, inOrder, postOrder;

		public DFSStackSimulation(int n) {
			adj = new ArrayList<>();
			for (int i = 0; i < n; i++) {
				adj.add(new ArrayList<>());
			}
			visited = new boolean[n];
			eulerTour = new ArrayList<>();
			preOrder = new ArrayList<>();
			inOrder = new ArrayList<>();
			postOrder = new ArrayList<>();
		}

		public void addEdge(int u, int v) {
			adj.get(u).add(v);
			adj.get(v).add(u); // for undirected graph
		}

		public void dfsWithStack(int start) {
			Stack<StackFrame> stack = new Stack<>();
			stack.push(new StackFrame(start, DFSState.PRE, 0)); // start with PRE state

			System.out.println("=== DFS Traversal Simulation ===");

			while (!stack.isEmpty()) {

				// Note we are not popping out the StackFrame
				StackFrame current = stack.peek();
				int node = current.node;
				DFSState state = current.state;
				int childIdx = current.childIndex;

				switch (state) {
				case PRE: // PRE area
					System.out.println("PRE: Entering node " + node);
					eulerTour.add("Enter-" + node);
					preOrder.add(node);
					visited[node] = true;

					// Move to IN state
					current.state = DFSState.IN;
					break;

				case IN: // IN area
					// Process children one by one
					List<Integer> children = adj.get(node);

					if (childIdx < children.size()) {
						int child = children.get(childIdx);
						current.childIndex++; // prepare for next child

						if (!visited[child]) {
							System.out.println("IN: Processing child " + child + " of node " + node);
							eulerTour.add("Traverse-" + node + "-to-" + child);

							// Push child onto stack
							stack.push(new StackFrame(child, DFSState.PRE, 0));
						} else {
							System.out.println("IN: Skipping already visited child " + child + " of node " + node);
						}
					} else {
						// All children processed, move to POST state
						System.out.println("IN: All children of node " + node + " processed");
						inOrder.add(node);
						current.state = DFSState.POST;
					}
					break;

				case POST: // POST area
					System.out.println("POST: Exiting node " + node);
					eulerTour.add("Exit-" + node);
					postOrder.add(node);

					// Remove current frame from stack
					stack.pop();
					break;
				}
			}
		}

		public void printResults() {
			System.out.println("\n=== Results ===");
			System.out.println("Pre-order:  " + preOrder);
			System.out.println("In-order:   " + inOrder);
			System.out.println("Post-order: " + postOrder);

			System.out.println("\n=== Euler Tour ===");
			for (int i = 0; i < eulerTour.size(); i++) {
				System.out.println((i + 1) + ". " + eulerTour.get(i));
			}
		}

		public static void main(String[] args) {
			// Create a sample tree
			// 0
			// / \
			// 1 2
			// / / \
			// 3 4 5

			DFSStackSimulation dfs = new DFSStackSimulation(6);
			dfs.addEdge(0, 1);
			dfs.addEdge(0, 2);
			dfs.addEdge(1, 3);
			dfs.addEdge(2, 4);
			dfs.addEdge(2, 5);

			System.out.println("Tree structure:");
			System.out.println("       0");
			System.out.println("      / \\");
			System.out.println("     1   2");
			System.out.println("    /   / \\");
			System.out.println("   3   4   5");
			System.out.println();

			dfs.dfsWithStack(0);
			dfs.printResults();

			System.out.println("\n=== Comparison with Recursive DFS ===");
			DFSStackSimulation recursiveExample = new DFSStackSimulation(6);
			recursiveExample.addEdge(0, 1);
			recursiveExample.addEdge(0, 2);
			recursiveExample.addEdge(1, 3);
			recursiveExample.addEdge(2, 4);
			recursiveExample.addEdge(2, 5);

			recursiveExample.dfsRecursive(0);
			System.out.println("Recursive Pre-order:  " + recursiveExample.preOrder);
			System.out.println("Recursive Post-order: " + recursiveExample.postOrder);
		}

		// Recursive DFS for comparison
		public void dfsRecursive(int node) {
			visited[node] = true;
			preOrder.add(node);
			// represents PRE area, anything before next recursion invocation with child

			for (int child : adj.get(node)) {
				if (!visited[child]) {
					dfsRecursive(child);
					// IN area
					inOrder.add(node);
				}
			}

			// POST area after for-loop
			postOrder.add(node);
		}

	}

}
