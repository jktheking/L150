package l150.algo.graph.dfs;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


/**
 * <pre>
 * 
 * Question: What is DFS_PATH/ANCESTOR_CHAIN/DFS_BRANCH ?
 *  
 *  If at a particular node we have multiple options to apply, each sibling-option-path represents
 *  a DFS_PATH/ANCESTOR_CHAIN/DFS_BRANCH.
 *  
 * Note :Children of the given node represents available options. We apply backtracking(means unmark)
 * to explore other options.
 *  
 * 
 * Edge Types in Directed Graphs: there are four types of edges during DFS traversal: 
 * 
 * 1. Tree Edges: Represents edges to unvisited nodes (part of DFS tree) 
 * 
 * 2. Back Edges: Edges to ancestors in CURRENT DFS_PATH → THESE CREATE CYCLES 
 *   A->B->C->D->A
 * 
 * 3. Forward Edges: Edges to descendants (already processed) 
 * A->B->C->D
 *     B->D is direct edge
 * 
 * 4. Cross Edges: Edges to nodes in different DFS branches
 * 
 * A->B->C->D->E
 * 
 * F->G->H->C
 *  
 *  Here H->C represents cross edge, as A and F are  start of two sibling branch.
 *  
 *  
 *  In the graph exploration we keep global Visited-Set used across all the DFS branches to avoid duplicate
 *  visitation. 
 *  
 *  How to detect cycle ?
 * 
 *  If in any of the DFS path we encounter the same node more than once means there is cycle
 *  A->B->C->D->A . 
 *  But here we cannot use global Visited-Set to figure out cycle, as it contains
 *  all the nodes till now we have seen in any of the DFS path. 
 *  
 *  We need to track nodes per DFS-PATH in a separate storage and then rest the same before next DFS-PATH
 *  exploration.
 * 
 * </pre>
 */
public class DirectedGraphCycleDetectionDfsPath3 {

	
	

		// Graph representation using adjacency list
		static class Graph {
			private int V; // number of vertices
			private List<List<Integer>> adj; // adjacency list

			public Graph(int V) {
				this.V = V;
				adj = new ArrayList<>();
				for (int i = 0; i < V; i++) {
					adj.add(new ArrayList<>());
				}
			}

			public void addEdge(int u, int v) {
				adj.get(u).add(v);
			}

			public List<Integer> getNeighbors(int v) {
				return adj.get(v);
			}

			public int getVertices() {
				return V;
			}
		}

	

	/**
	 * <pre>
	 * Detect cycle in directed graph using recursion stack - RECURSIVE VERSION
	 * 
	 * Key Idea:
	 * - visited[]: Tracks all nodes that have been visited at least once
	 * - recStack[]: Tracks nodes currently in the recursion path (current DFS branch)
	 * 
	 * Cycle Detection Logic:
	 * - If we encounter a neighbor that's in recStack[], it's a back edge → CYCLE!
	 * - If we encounter a neighbor that's visited but NOT in recStack[], it's a cross/forward edge → NO CYCLE
	 * 
	 * </pre>
	 */
	public static boolean hasCycleRecursive(Graph graph) {
		int V = graph.getVertices();
		boolean[] visited = new boolean[V]; // Global visited tracking
		boolean[] recStack = new boolean[V]; // Current recursion path tracking

		// Check all components of the graph
		for (int i = 0; i < V; i++) {
			if (!visited[i]) {
				if (dfsRecursive(graph, i, visited, recStack)) {
					return true;
				}
			}
		}
		return false;
	}

	private static boolean dfsRecursive(Graph graph, int current, boolean[] visited, boolean[] recStack) {
		// Mark current node as visited and add to recursion stack
		visited[current] = true;
		recStack[current] = true;

		System.out.println("Visiting: " + current + " (added to recursion stack)");

		// Explore all neighbors
		for (int neighbor : graph.getNeighbors(current)) {
			System.out.println("  Checking neighbor: " + neighbor);

			// If neighbor is in current recursion stack → BACK EDGE → CYCLE!
			if (recStack[neighbor]) {
				System.out.println("  *** CYCLE DETECTED: Back edge from " + current + " to " + neighbor + " ***");
				return true;
			}

			// If neighbor is not visited, explore it recursively
			if (!visited[neighbor]) {
				System.out.println("  Neighbor " + neighbor + " not visited, exploring...");
				
				if (dfsRecursive(graph, neighbor, visited, recStack)) {
					return true;
				}
			
			} else {
				System.out.println(
						"  Neighbor " + neighbor + " already visited but not in rec stack (cross/forward edge)");
			}
		}

		// Remove current node from recursion stack before backtracking
		recStack[current] = false;
		System.out.println("Finished: " + current + " (removed from recursion stack)");

		return false;
	}
	
	
	
	
	
	
	// ===================== ITERATIVE IMPLEMENTATION WITH ENUM =====================
	/**
	 * Detect cycle in directed graph using recursion stack - ITERATIVE VERSION
	 * 
	 * Challenge: Simulating recursion stack behavior iteratively
	 * Solution: Use explicit stacks to track:
	 * 1. Current node being processed
	 * 2. Whether we're entering or leaving the node (using enum)
	 * 3. Which neighbors we've processed so far
	 */

	// Enum to represent the phase of node processing
	enum ProcessingPhase {
	    PRE,   // Pre-order: First time visiting the node
	    POST   // Post-order: Done processing node and its descendants
	}

	// Class to represent a stack frame in our iterative DFS
	static class StackFrame {
	    int node;
	    ProcessingPhase phase;
	    
	    public StackFrame(int node, ProcessingPhase phase) {
	        this.node = node;
	        this.phase = phase;
	    }
	    
	    @Override
	    public String toString() {
	        return String.format("Node: %d, Phase: %s", node, phase);
	    }
	}

	public static boolean hasCycleIterative(Graph graph) {
	    int V = graph.getVertices();
	    boolean[] visited = new boolean[V];
	    boolean[] recStack = new boolean[V];
	    
	    // Check all components of the graph
	    for (int i = 0; i < V; i++) {
	        if (!visited[i]) {
	            if (dfsIterative(graph, i, visited, recStack)) {
	                return true;
	            }
	        }
	    }
	    return false;
	}

	private static boolean dfsIterative(Graph graph, int start, boolean[] visited, boolean[] recStack) {
	    // Stack to simulate recursion calls using our StackFrame class
	    Stack<StackFrame> stack = new Stack<>();
	    
	    // Start with the initial node in PRE phase
	    stack.push(new StackFrame(start, ProcessingPhase.PRE));
	    
	    while (!stack.isEmpty()) {
	        StackFrame current = stack.peek();
	        int node = current.node;
	        ProcessingPhase phase = current.phase;
	        
	        switch (phase) {
	            case PRE:
	                // PRE PHASE: First time processing this node
	                if (visited[node]) {
	                    stack.pop(); // Already processed, skip
	                    continue;
	                }
	                
	                // Mark as visited and add to recursion stack
	                visited[node] = true;
	                recStack[node] = true;
	                System.out.println("Visiting: " + node + " (added to recursion stack)");
	                
	                // Change to POST phase for when we return to this node
	                current.phase = ProcessingPhase.POST;
	                
	                // Add all neighbors to stack (in reverse order to maintain order)
	                List<Integer> neighbors = graph.getNeighbors(node);
	                for (int i = neighbors.size() - 1; i >= 0; i--) {
	                    int neighbor = neighbors.get(i);
	                    System.out.println("  Checking neighbor: " + neighbor);
	                    
	                    // If neighbor is in current recursion stack → CYCLE!
	                    if (recStack[neighbor]) {
	                        System.out.println("  *** CYCLE DETECTED: Back edge from " + 
	                                         node + " to " + neighbor + " ***");
	                        return true;
	                    }
	                    
	                    // If neighbor is not visited, add to stack for exploration
	                    if (!visited[neighbor]) {
	                        System.out.println("  Neighbor " + neighbor + 
	                                         " not visited, will explore...");
	                        stack.push(new StackFrame(neighbor, ProcessingPhase.PRE));
	                    } else {
	                        System.out.println("  Neighbor " + neighbor + 
	                                         " already visited but not in rec stack (cross/forward edge)");
	                    }
	                }
	                break;
	                
	            case POST:
	                // POST PHASE: Done processing this node and all its descendants
	                // Remove from recursion stack
	                recStack[node] = false;
	                System.out.println("Finished: " + node + " (removed from recursion stack)");
	                
	                // Remove from stack
	                stack.pop();
	                break;
	        }
	    }
	    
	    return false;
	}

}
