package l150.algo.graph.dfs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * 
 * In an undirected graph with or without multiple components, if the
 * total-number-of-edges ≥ total-number-of-vertices, then the graph must contain
 * at least one cycle.
 * 
 * 
 * When a already visited neighbor that is not the parent is found, it indicates
 * a cycle. We need to keep track of visited nodes and parent to avoid false
 * positives due to bidirectional edges.
 * 
 * 
 * 
 */
public class UndirectedGraphCycleDetection3 {

	public static class CycleDetectionDFS {

		public static boolean hasCycle(Map<Integer, List<Integer>> graph) {

			Set<Integer> visited = new HashSet<>();

			// start DFS from each component
			for (int node : graph.keySet()) {
				if (!visited.contains(node)) {
					if (dfs(graph, node, -1, visited)) {
						return true;
					}
				}
			}
			return false;
		}

		private static boolean dfs(Map<Integer, List<Integer>> graph, int current, int parent, Set<Integer> visited) {
			visited.add(current);

			for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {

				if (!visited.contains(neighbor)) {
					if (dfs(graph, neighbor, current, visited)) {
						return true;
					}
				} else if (neighbor != parent) {
					// If neighbor is visited and not parent, cycle found
					return true;
				}
			}

			return false;
		}

	}

	public static class CycleDetectionBFS {

		public static boolean hasCycle(Map<Integer, List<Integer>> graph) {
			Set<Integer> visited = new HashSet<>();

			for (int start : graph.keySet()) {
				if (!visited.contains(start)) {
					if (bfs(graph, start, visited)) {
						return true;
					}
				}
			}
			return false;
		}

		private static boolean bfs(Map<Integer, List<Integer>> graph, int start, Set<Integer> visited) {
			Queue<int[]> queue = new LinkedList<>();
			queue.offer(new int[] { start, -1 });
			visited.add(start);

			while (!queue.isEmpty()) {
				int[] pair = queue.poll();
				int node = pair[0], parent = pair[1];

				for (int neighbor : graph.getOrDefault(node, Collections.emptyList())) {
					if (!visited.contains(neighbor)) {
						visited.add(neighbor);
						queue.offer(new int[] { neighbor, node });
					} else if (neighbor != parent) {
						// If already visited and not parent => cycle
						return true;
					}
				}
			}

			return false;
		}
	}

	public class CyclePathDFS1 {

		private static List<Integer> cyclePath = new ArrayList<>();
		private static Map<Integer, Integer> parent = new HashMap<>();
		private static Set<Integer> visited = new HashSet<>();

		public static List<Integer> detectCycle(Map<Integer, List<Integer>> graph) {
			cyclePath.clear();
			visited.clear();
			parent.clear();

			for (int node : graph.keySet()) {
				if (!visited.contains(node)) {
					if (dfs(graph, node, -1)) {
						return cyclePath;
					}
				}
			}
			return Collections.emptyList(); // no cycle
		}

		private static boolean dfs(Map<Integer, List<Integer>> graph, int current, int par) {
			visited.add(current);
			parent.put(current, par);

			for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {
				if (!visited.contains(neighbor)) {
					if (dfs(graph, neighbor, current)) {
						return true;
					}
				} else if (neighbor != par) {
					//neighbor is in visited but not a parent mean, a back edge found i.e. cycle.
					CylecPathConstructionForUndirectedGraph.buildCyclePathUsingDfsStyleParentWalk(current, par, parent,
							cyclePath);
					return true;
				}
			}

			return false;
		}

	}

	public static class CyclePathDFS2 {
		private Map<Integer, List<Integer>> graph;
		private Set<Integer> visited;
		private Map<Integer, Integer> parent;
		private List<List<Integer>> cycles;

		public CyclePathDFS2(Map<Integer, List<Integer>> graph) {
			this.graph = graph;
			this.visited = new HashSet<>();
			this.parent = new HashMap<>();
			this.cycles = new ArrayList<>();
		}

		public List<List<Integer>> findCycles() {
			for (int node : graph.keySet()) {
				if (!visited.contains(node)) {
					parent.put(node, -1);
					dfs(node);
				}
			}
			return cycles;
		}

		private void dfs(int node) {
			visited.add(node);

			for (int neighbor : graph.getOrDefault(node, List.of())) {
				if (!visited.contains(neighbor)) {
					parent.put(neighbor, node);
					dfs(neighbor);
				} else if (neighbor != parent.get(node)) {
					//neighbor is in visited but not a parent mean, a back edge found i.e. cycle.
					List<Integer> cycle = CylecPathConstructionForUndirectedGraph.buildCyclePathUsingLCA(node, neighbor,
							parent);
					if (!isDuplicate(cycle)) {
						cycles.add(cycle);
					}
				}
			}
		}

		private boolean isDuplicate(List<Integer> cycle) {
			Set<Integer> set = new HashSet<>(cycle);
			for (List<Integer> existing : cycles) {
				if (new HashSet<>(existing).equals(set))
					return true;
			}
			return false;
		}
	}

	public class BFSCycleDetector {

		private Map<Integer, List<Integer>> graph;
		
		private List<List<Integer>> cycles;
		private Set<Integer> visited;
		private Map<Integer, Integer> parent;

		public BFSCycleDetector(Map<Integer, List<Integer>> graph) {
			this.graph = graph;
			this.cycles = new ArrayList<>();
			this.visited = new HashSet<>();
			this.parent = new HashMap<>();
		}

		public List<List<Integer>> findCycles() {
			for (int start : graph.keySet()) {
				if (!visited.contains(start)) {
					bfs(start);
				}
			}
			return cycles;
		}
		private void bfs(int start) {
			Queue<Integer> queue = new LinkedList<>();
			queue.offer(start);
			visited.add(start);
			parent.put(start, -1);

			while (!queue.isEmpty()) {
				int node = queue.poll();

				for (int neighbor : graph.getOrDefault(node, List.of())) {
					if (!visited.contains(neighbor)) {
						visited.add(neighbor);
						parent.put(neighbor, node);
						queue.offer(neighbor);
					} else if (parent.get(node) != neighbor) {
						//neighbor is in visited but not a parent mean, a back edge found i.e. cycle.
						List<Integer> cycle = CylecPathConstructionForUndirectedGraph.buildCyclePathUsingLCA(node,
								neighbor, parent);
						if (!isDuplicate(cycle)) {
							cycles.add(cycle);
						}
					}
				}
			}
		}

		private boolean isDuplicate(List<Integer> cycle) {
			Set<Integer> set = new HashSet<>(cycle);
			for (List<Integer> existing : cycles) {
				if (new HashSet<>(existing).equals(set))
					return true;
			}
			return false;
		}
	}

	public static class CylecPathConstructionForUndirectedGraph {

		/**
		 * This will only work with DFS and will not work with BFS consistently
		 * 
		 */
		public static void buildCyclePathUsingDfsStyleParentWalk(int current, int target, Map<Integer, Integer> parent,
				List<Integer> cyclePath) {
			cyclePath.clear();
			cyclePath.add(target); // Start node of cycle
			while (current != target) {
				cyclePath.add(current);
				current = parent.get(current);
			}
			cyclePath.add(target); // Close the loop
			Collections.reverse(cyclePath);

		}

		/**
		 * <pre>
		 * This method reconstructs the cycle path in an undirected graph once a back
		 * edge is detected between two already visited nodes: u and v.
		 * 
		 * It walks up both nodes using the parent map (which is built by DFS or BFS),
		 * till the start node from where traversal started
		 * 
		 * It finds the Lowest Common Ancestor (LCA) of u and v, i.e., the node where
		 * both paths meet.
		 * 
		 * It then combines the two paths into a single cycle, making sure to not
		 * duplicate the LCA.
		 * 
		 * 
		 * 🧠 Core Concepts parent map: 
		 * -------------------------------
		 * Stores how we reached each node (parent[child] = parentNode)
		 * A cycle is detected when we visit a node v from u, and v is already visited
		 * (but not u’s parent).
		 * The LCA is the first node common to both paths from u and v back to the root
		 * (or start of traversal).
		 * 
		 *          1 - 2 - 3 - 4
						|       |
						5-------6
		 *				
		 *  Cycle detection using DFS:
		 *  Parent Map in DFS:
		 *  2 → 1  
			3 → 2  
			4 → 3  
			6 → 4  
			5 → 6			
		 * Now we visit 5, and from there we see 2 is already visited and not its parent.
		 * So, 5 - 2 represents back edge where;
		 *     u = 5
		 *     v = 2   
		 *  In DFS u represents start node of cycle and v represents LCA.
		 *  DFS cycle order [5,6,4,3,2,5]
		 * 
		 *     
		 *  Cycle detection using BFS:  
		 *   visited [1,2,3,5,4,6]
		 *  Parent Map in BFS:
		 *    2 -> 1
		 *    3 -> 2
		 *    5 -> 2
		 *    4 -> 3
		 *    6 -> 4
		 *   Now we visit 6, and from there we see 5 is already visited and not its parent.
		 * So, 6 - 5 represents back edge where;  
		 *    u = 6
		 *    v = 5
		 *     In BFS u represents start node of cycle. 
		 *    BFS cycle order [6,4,3,2,5,6]
		 * 
		 * </pre>
		 * 
		 */
		public static List<Integer> buildCyclePathUsingLCA(int u, int v, Map<Integer, Integer> parent) {
			List<Integer> pathU = new ArrayList<>();
			List<Integer> pathV = new ArrayList<>();
			Set<Integer> visitedU = new HashSet<>();

			// Walk u to root, track all nodes
			// pathU in DFS = [5, 6, 4, 3, 2, 1]
			// pathU in BFS = [6, 4, 3, 2, 1]
			while (u != -1) {
				pathU.add(u);
				visitedU.add(u);
				u = parent.getOrDefault(u, -1);
			}

			int lca = -1;

			// Walk v to root, find the first node also visited in u's path → that's the LCA
			// pathV in DFS = [2]
			// pathV in BFS = [5, 2]
			while (v != -1) {
				pathV.add(v);
				if (visitedU.contains(v)) {
					lca = v; // lca = 2 ✅
					break;
				}
				v = parent.getOrDefault(v, -1);
			}

			List<Integer> cycle = new ArrayList<>();

			// Add path from u to LCA
			for (int node : pathU) {
				cycle.add(node);
				if (node == lca)
					break;
			}

			// Add path from LCA to V (excluding LCA itself to avoid duplication)
			Collections.reverse(pathV);
			for (int node : pathV) {
				if (node != lca)
					cycle.add(node);
			}

			// Close the cycle by connecting last node back to start
			cycle.add(cycle.get(0));

			return cycle;
		}

	}

}
