package l150.algo.graph.dfs;

import java.util.Stack;


/**
 * 
 * <pre>
 * | Scenario                            | DFS Suitability            |
 * | ----------------------------------- | -------------------------- |
 * | You only need to **traverse**       | ✅ Good                    |
 * | You want **deep exploration first** | ✅ Good                    |
 * | Need **component labeling**         | ✅ Good                    |
 * | Need **shortest path**              | ❌ Use BFS                  |
 * | Want to **avoid recursion**         | ❌ Use iterative DFS or BFS |

 * 
 * Common Use Cases for Grid DFS
 * 
 * 1. Number of Islands (LeetCode 200)
 * 2. Flood Fill (LeetCode 733)
 * 3. Connected Components in a Grid
 * 4. Surrounded Regions (LeetCode 130)
 * 
 * 5. Walls and Gates (LeetCode 286)
 * Problem: Fill each empty room with distance to nearest gate.
 * DFS Role: Can be used (though BFS is better here) to propagate distance.
 * 
 * 6. Word Search (LeetCode 79)
 * Problem: Find a given word in a grid by moving to adjacent characters.
 * DFS Role: Try all paths recursively from matching starting characters.
 * 
 * 7. Maze Problems / Backtracking
 * Problem: Find if a path exists from source to destination.
 * DFS Role: Explore all possible paths (use visited matrix or backtracking).
 * 
 * 8. Image Segmentation / Blob Detection
 * Problem: Identify regions of the same value (e.g., 1's in a binary image).
 * DFS Role: Visit all connected "on" pixels and mark as part of the same blob.
 * 
 * 9. Fire Spread / Zombie Invasion (similar to Rotten Oranges)
 * Problem: Simulate how fire/zombies spread across a grid.
 * DFS Role: Though BFS is more suitable for shortest time, DFS works for simulation.
 * 
 * 10. Custom Region Expansion (Game of Life-like)
 * Problem: Expand zones with certain rules.
 * DFS Role: Traverse affected regions and apply updates.
 * 
 * 
 * 
 * 
 * 
 * </pre>
 * 
 * 
 * 
 * */
public class GridDFS6 {

	public static class RecursiveGridDFS {

		// 8 directions: up, down, left, right, and diagonals
		private static final int[][] directions = { { -1, 0 }, // up
				{ 1, 0 }, // down
				{ 0, -1 }, // left
				{ 0, 1 }, // right
				{ -1, -1 }, // top-left
				{ -1, 1 }, // top-right
				{ 1, -1 }, // bottom-left
				{ 1, 1 } // bottom-right
		};

		// start DFS for all given disconnected components
		public void startDFS(int[][] grid) {
			int rows = grid.length;
			int cols = grid[0].length;
			boolean[][] visited = new boolean[rows][cols];

			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					if (!visited[i][j] && grid[i][j] == 1) {
						dfs(grid, visited, i, j);
						// E.g., increase island/component count
					}
				}
			}
		}

		public void dfs(int[][] grid, boolean[][] visited, int row, int col) {
			int rows = grid.length;
			int cols = grid[0].length;

			// Base case: out of bounds or already visited or invalid cell
			if (row < 0 || col < 0 || row >= rows || col >= cols || visited[row][col] || grid[row][col] == 0) {
				return;
			}

			// Mark the current cell as visited
			visited[row][col] = true;

			// Visit all 8 neighbors
			for (int[] dir : directions) {
				int newRow = row + dir[0];
				int newCol = col + dir[1];
				dfs(grid, visited, newRow, newCol);
			}
		}

	}

	public static class IterativeGridDFS {

		// Directions: up, down, left, right
		private static final int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };

		// start DFS for all given disconnected components
		public void startDFS(int[][] grid) {
			int rows = grid.length;
			int cols = grid[0].length;

			boolean[][] visited = new boolean[rows][cols];

			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					if (!visited[i][j] && grid[i][j] == 1) {
						dfsIterative(grid, visited, i, j);
						// e.g., increment connected component count here
					}
				}
			}
		}

		public void dfsIterative(int[][] grid, boolean[][] visited, int startRow, int startCol) {
			int rows = grid.length;
			int cols = grid[0].length;

			Stack<int[]> stack = new Stack<>();
			stack.push(new int[] { startRow, startCol });

			while (!stack.isEmpty()) {

				int[] cell = stack.pop();
				int row = cell[0], col = cell[1];

				// Skip if out of bounds, already visited, or invalid
				if (row < 0 || col < 0 || row >= rows || col >= cols || visited[row][col] || grid[row][col] == 0) {
					continue;
				}

				// Mark cell as visited
				visited[row][col] = true;

				// Push neighbors to the stack
				for (int[] dir : directions) {
					int newRow = row + dir[0];
					int newCol = col + dir[1];
					stack.push(new int[] { newRow, newCol });
				}
			}
		}

	}

	
	/**
	 * 
	 * Here instead of visited[][] grid we are using backtracking
	 * 
	 * */
	public static class GridDFSBacktracking {

		private static final int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 }, { -1, -1 }, { -1, 1 },
				{ 1, -1 }, { 1, 1 } };

		public void dfs(int[][] grid, int row, int col) {
			int rows = grid.length;
			int cols = grid[0].length;

			// Base case: out of bounds or invalid cell
			if (row < 0 || col < 0 || row >= rows || col >= cols || grid[row][col] != 1) {
				return;
			}

			// Mark as visited using backtracking (in-place change)
			grid[row][col] = -1;

			for (int[] dir : directions) {
				dfs(grid, row + dir[0], col + dir[1]);
			}

			/*
			 * Optional: If you need to restore the grid after DFS, add grid[row][col] = 1;
			 * at the end — that’s backtracking.
			 */

			// grid[row][col] = 1; // Uncomment if the grid needs to be reused
		}

		public void startDFS(int[][] grid) {
			int rows = grid.length;
			int cols = grid[0].length;

			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					if (grid[i][j] == 1) {
						dfs(grid, i, j);
						// Do something (e.g., count components)
					}
				}
			}
		}
	}

}
