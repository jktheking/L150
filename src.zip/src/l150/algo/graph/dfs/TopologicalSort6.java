package l150.algo.graph.dfs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;

/**
 * <pre>
 * Topological Sort of a Directed Acyclic Graph (DAG) is a linear ordering of
 * vertices such that for every directed edge u → v, vertex u comes before v in
 * the ordering.
 * 
 * It only works for Directed Acyclic Graphs (DAGs). There must not be any
 * cycles.
 * 
 * Use cases:
 * Build Systems: Before compiling a file, compile all the files it depends on.
 * Course Scheduling: To take a course, all prerequisite courses must be
 * completed first.
 * 
 * Example:
 * 
 * 0 → 1 , 0 → 2 , 1 → 3 , 2 → 3
 * 
 * Observation: at 0 two child branch 1,2 and both 1 and 2 goes to 3.
 * 
 * Valid Topological Orders:
 * 0 1 2 3
 * 0 2 1 3
 * 
 * Note: Topological order: follows the DFS-path but we need to process the current node post it's dependencies
 * 
 * Situation: If two components intersect each other at a node, here on 2.
 * 0->1->2->3->4
 * 7->6->2
 *
 ** Valid Topological Orders:
 *0,1,7,6  [2,3,4]
 *7,6,0,1  [2,3,4]
 * 
 * So, we see that all the nodes before intersection point 2 from these two components 
 * must come before it. So, if we follow the pre-order DFS path-formation, we would get
 * nodes before intersection-node of other component post DFS path of first component.
 * like: 0,1,2,3,4, 7,6 so, pre-order DFS path-formation fails to provide the correct topological order,
 * as we need global DFS-path ordering. 
 * 
 * post-oder DFS path-formation make sure that all the outgoing-edges i.e. dependencies are
 * marked before the current node. Means intersection-nodes will always be marked post its children
 * across all the components.
 * 
 * Why Push the Node in Post-Area?
 * Key Rule of Topological Sort: 
 * You must process a node only after all its dependencies (outgoing edges) are processed.
 * 
 * What Post-Area Achieves:
 * When we push a node in the post-area (i.e., after visiting all its neighbors), we guarantee:
 * - All nodes that this node depends on are already pushed into the stack.
 * - So when we pop the stack, we get the node after its dependencies, which is exactly what we want.
 * 
 * BFS based Topological Sort : See Kahn’s Algorithm 
 * 
 * Kahn’s Algorithm (BFS-based)
 * - Count in-degrees (how many incoming edges per node).
 *- Start with nodes having 0 in-degree.
 *- Remove those and update in-degrees of neighbors.
 *- Continue until all nodes are processed.
 * 
 * </pre>
 * 
 */
public class TopologicalSort6 {

	static class TopologicalSortOnGrpahWithoutCycle {

		public List<Integer> topologicalSort(Map<Integer, List<Integer>> graph) {
			Set<Integer> visited = new HashSet<>();
			Stack<Integer> stack = new Stack<>();

			// start DFS from each component
			for (Integer node : graph.keySet()) {
				if (!visited.contains(node)) {
					dfs(node, graph, visited, stack);
				}
			}

			// Stack contains nodes in reverse order of completion
			List<Integer> result = new ArrayList<>();
			while (!stack.isEmpty()) {
				result.add(stack.pop());
			}
			return result;
		}

		private void dfs(int node, Map<Integer, List<Integer>> graph, Set<Integer> visited, Stack<Integer> stack) {
			visited.add(node);
			for (int neighbor : graph.getOrDefault(node, Collections.emptyList())) {
				if (!visited.contains(neighbor)) {
					dfs(neighbor, graph, visited, stack);
				}
			}
			// Push after visiting all neighbors
			stack.push(node);
		}

	}

	static class TopologicalSortOnGrpahWithCycleDetection {

		static class Graph {

			/**
			 * Graph representation using adjacency list
			 */
			private Map<Integer, List<Integer>> adjacencyList;

			private int vertices;

			public int getVertices() {
				return vertices;
			}

			public void setVertices(int vertices) {
				this.vertices = vertices;
			}

			public Graph(int vertices) {
				this.vertices = vertices;
				this.adjacencyList = new HashMap<>();

				// Initialize adjacency list for all vertices
				for (int i = 0; i < vertices; i++) {
					adjacencyList.put(i, new ArrayList<>());

				}
			}

			/**
			 * Add a directed edge from source to destination
			 */
			public void addEdge(int src, int dest) {
				adjacencyList.get(src).add(dest);
			}

			public Map<Integer, List<Integer>> getAdjacencyList() {
				return adjacencyList;
			}

		}

		/**
		 * RECURSIVE APPROACH Performs topological sort using recursive DFS
		 * 
		 * Time Complexity: O(V + E) where V = vertices, E = edges Space Complexity:
		 * O(V) for recursion stack and data structures
		 * 
		 * @return List of vertices in topological order, or null if cycle detected
		 */
		public List<Integer> topologicalSortRecursive(Graph g) {

			int v = g.getVertices();
			// Stack to store the topological order (vertices with no incoming edges first)
			Stack<Integer> stack = new Stack<>();

			// Track visited vertices to avoid revisiting
			boolean[] visited = new boolean[v];

			// Track vertices currently in recursion stack to detect cycles
			boolean[] recursionStack = new boolean[v];

			// Perform DFS from all unvisited vertices
			for (int i = 0; i < v; i++) {
				if (!visited[i]) {
					// If cycle detected, return null
					if (dfsRecursive(g, i, visited, recursionStack, stack)) {
						System.out.println("Cycle detected! Topological sort not possible.");
						return null;
					}
				}
			}

			// Convert stack to list (stack contains vertices in reverse topological order)
			List<Integer> result = new ArrayList<>();
			while (!stack.isEmpty()) {
				result.add(stack.pop());
			}

			return result;
		}

		/**
		 * Recursive DFS helper function
		 * 
		 * @param current          Current vertex being processed
		 * @param visited          Array to track visited vertices
		 * @param recursionStack   Array to track vertices in current recursion path
		 * @param topoStorageStack Stack to store vertices in reverse topological order
		 * @return true if cycle detected, false otherwise
		 */
		private boolean dfsRecursive(Graph graph, int current, boolean[] visited, boolean[] recursionStack,
				Stack<Integer> topoStorageStack) {
			// Mark current vertex as visited and add to recursion stack
			visited[current] = true;
			recursionStack[current] = true;

			// Visit all adjacent vertices
			for (int neighbor : graph.getAdjacencyList().get(current)) {
				// If neighbor is in recursion stack, we found a back edge (cycle)
				if (recursionStack[neighbor]) {
					return true; // Cycle detected
				}

				// If neighbor not visited, recursively visit it
				if (!visited[neighbor] && dfsRecursive(graph, neighbor, visited, recursionStack, topoStorageStack)) {
					return true; // Cycle detected in deeper recursion
				}
			}

			// Remove vertex from recursion stack (backtrack)
			recursionStack[current] = false;

			// Add vertex to stack after processing all its neighbors
			// This ensures vertices are added in reverse order of their finish times
			topoStorageStack.push(current);

			return false; // No cycle detected
		}

	}

	static class IterativeDFSTopologicalSortWithCycleDetection {

		// Enum to represent the phase of node processing
		enum ProcessingPhase {
			PRE, // Pre-order: First time visiting the node
			POST // Post-order: Done processing node and its descendants
		}

		// Stack frame for iterative DFS
		static class StackFrame {
			int node;
			ProcessingPhase phase;

			public StackFrame(int node, ProcessingPhase phase) {
				this.node = node;
				this.phase = phase;
			}

			@Override
			public String toString() {
				return String.format("Node: %d, Phase: %s", node, phase);
			}
		}

		public static List<Integer> checkAndDoTopologicalSort(Map<Integer, List<Integer>> graph) {
			// Build complete set of nodes (including sink-only nodes)
			Set<Integer> allNodes = new HashSet<>();
			for (Map.Entry<Integer, List<Integer>> entry : graph.entrySet()) {
				allNodes.add(entry.getKey()); // source node
				allNodes.addAll(entry.getValue()); // destination nodes
			}

			Set<Integer> visited = new HashSet<>();
			Set<Integer> recStack = new HashSet<>();
			Stack<Integer> postOrderTopoStack = new Stack<>();

			for (int node : allNodes) {
				if (!visited.contains(node)) {
					if (!dfsIterative(graph, node, visited, recStack, postOrderTopoStack)) {
						throw new RuntimeException("Cycle detected. Topological sort not possible.");
					}
				}
			}

			List<Integer> result = new ArrayList<>();
			while (!postOrderTopoStack.isEmpty()) {
				result.add(postOrderTopoStack.pop());
			}

			return result;
		}

		private static boolean dfsIterative(Map<Integer, List<Integer>> graph, int start, Set<Integer> visited,
				Set<Integer> recStack, Stack<Integer> postOrderTopoStack) {

			Stack<StackFrame> stack = new Stack<>();
			stack.push(new StackFrame(start, ProcessingPhase.PRE));

			while (!stack.isEmpty()) {
				StackFrame current = stack.peek();
				int node = current.node;
				ProcessingPhase phase = current.phase;

				switch (phase) {
				case PRE:
					if (visited.contains(node)) {
						stack.pop();
						continue;
					}

					visited.add(node);
					recStack.add(node);
					System.out.println("Visiting: " + node + " (added to recursion stack)");

					current.phase = ProcessingPhase.POST;

					List<Integer> neighbors = graph.getOrDefault(node, Collections.emptyList());
					for (int i = neighbors.size() - 1; i >= 0; i--) {
						int neighbor = neighbors.get(i);
						System.out.println("  Checking neighbor: " + neighbor);

						if (recStack.contains(neighbor)) {
							System.out.println(
									"  *** CYCLE DETECTED: Back edge from " + node + " to " + neighbor + " ***");
							return false;
						}

						if (!visited.contains(neighbor)) {
							System.out.println("  Neighbor " + neighbor + " not visited, will explore...");
							stack.push(new StackFrame(neighbor, ProcessingPhase.PRE));
						} else {
							System.out.println("  Neighbor " + neighbor
									+ " already visited but not in rec stack (cross/forward edge)");
						}
					}
					break;

				case POST:
					recStack.remove(node);
					System.out.println("Finished: " + node + " (removed from recursion stack)");
					stack.pop();
					postOrderTopoStack.push(node); // Record post-order
					break;
				}
			}

			return true;
		}
	}

	/**
	 * 
	 * Key Concepts Behind Kahn’s Algorithm (BFS Approach)
	 * 
	 * - We compute the in-degree (number of incoming edges) for each node.
	 * 
	 * - Nodes with in-degree = 0 can be placed in the topological ordering.
	 * 
	 * - As we "remove" a node from the graph (process it), we decrease the
	 * in-degree of its neighbors.
	 * 
	 * - When a neighbor's in-degree becomes 0, we add it to the processing queue.
	 * 
	 * - If after processing all nodes, the number of processed nodes < total nodes,
	 * a cycle exists.
	 * 
	 * 
	 */
	static class TopologicalSortBFS {

		public static List<Integer> kahnsTopologicalSort(Map<Integer, List<Integer>> graph) {
			// Step 1: Build the complete set of nodes (including those with only incoming
			// edges)
			Set<Integer> allNodes = new HashSet<>();
			for (Map.Entry<Integer, List<Integer>> entry : graph.entrySet()) {
				allNodes.add(entry.getKey()); // source node
				allNodes.addAll(entry.getValue()); // destination nodes
			}

			// Step 2: Initialize in-degree map for all nodes
			Map<Integer, Integer> inDegree = new HashMap<>();
			for (int node : allNodes) {
				inDegree.put(node, 0);
			}

			// Step 3: Compute in-degrees
			for (List<Integer> neighbors : graph.values()) {
				for (int neighbor : neighbors) {
					inDegree.put(neighbor, inDegree.get(neighbor) + 1);
				}
			}

			// Step 4: Initialize queue with nodes having in-degree 0
			Queue<Integer> queue = new LinkedList<>();
			for (int node : allNodes) {
				if (inDegree.get(node) == 0) {
					queue.offer(node);
				}
			}

			// Step 5: Process nodes in BFS order
			List<Integer> topoOrder = new ArrayList<>();
			while (!queue.isEmpty()) {
				int current = queue.poll();
				topoOrder.add(current);

				for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {
					// Decrease in-degree of neighbor
					inDegree.put(neighbor, inDegree.get(neighbor) - 1);

					// If in-degree becomes 0, add to queue
					if (inDegree.get(neighbor) == 0) {
						queue.offer(neighbor);
					}
				}
			}

			// Step 6: Cycle detection – if all nodes are not processed
			if (topoOrder.size() != allNodes.size()) {
				throw new RuntimeException("Cycle detected. Topological sort not possible.");
			}

			return topoOrder;
		}

		public static void main(String[] args) {
			Map<Integer, List<Integer>> graph = new HashMap<>();
			graph.put(5, Arrays.asList(2, 0));
			graph.put(4, Arrays.asList(0, 1));
			graph.put(2, Arrays.asList(3));
			graph.put(3, Arrays.asList(1));

			try {
				List<Integer> topoOrder = kahnsTopologicalSort(graph);
				System.out.println("Topological Sort (BFS/Kahn's Algorithm): " + topoOrder);
			} catch (RuntimeException e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}

}
