package l150.algo.graph.dfs;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class IterativeDFSMarkingOnPushOrPop2 {

	/**
	 * Note:As we know recursion branches can be represented as graph edges, more
	 * precisely DFS-graph edges. In recursion DFS stack we don't have the cycle.
	 * But in graph, we may have cycles, or in un-directed graph edge is two way
	 * parent to child, and child to parent. So, while traversing the whole graph we
	 * need to track the visited node. In recursion marking and un-marking is
	 * required for backtracking.
	 * 
	 * 
	 * 
	 * 
	 * UseCases of MarkOnPush:
	 * 
	 * Early Termination Scenarios: When you want to stop as soon as a node is
	 * "discovered" Path-finding where you care about discovery, not processing.
	 * 
	 * Memory Optimization: Prevents duplicate entries in the stack In dense graphs,
	 * this can save significant memory
	 * 
	 * Consistent with BFS Pattern: BFS always marks on enqueue. Makes the code
	 * pattern consistent between DFS and BFS.
	 * 
	 * Trade-off: You lose the ability to do certain backtracking algorithms where
	 * you need to "unmark" nodes, but for standard graph traversal, mark-on-push is
	 * often more efficient.
	 * 
	 * 
	 * 
	 * 
	 */
	public static class MarkOnPushTraversal {
		private Set<Integer> visited = new HashSet<>();

		public void dfs(Map<Integer, List<Integer>> graph, int startNode) {
			Stack<Integer> stack = new Stack<>();
			visited.add(startNode); // Mark immediately or MARK ON PUSH
			stack.push(startNode);

			while (!stack.isEmpty()) {
				// stack.top represents "execution-area", but since we
				// don't want to do anything specific apart from visit,
				// so we are popping the parent and pushing all its children for further
				// processing.
				int node = stack.pop();
				System.out.println("Visiting: " + node);

				// shift all the edges to next generation i.e. placing for execution of child
				// generation
				for (int neighbor : graph.getOrDefault(node, List.of())) {
					if (!visited.contains(neighbor)) {
						visited.add(neighbor); // MARK ON PUSH
						stack.push(neighbor);
					}
				}
			}
		}
	}

	/**
	 * <pre>
	 * Mark-on-Pop Strategy: Pros and Cons PROS:
	 * 
	 * Closer to Recursive DFS Semantics: Mirrors exactly what recursive DFS does
	 * Node is "visited" only when actually being processed
	 * 
	 * Better for Path Reconstruction: Parent relationships reflect the actual
	 * traversal path Useful for finding actual DFS paths, not just reachability
	 * 
	 * 
	 * Backtracking Algorithms: Can easily implement algorithms that need to
	 * "unvisit" nodes Useful for puzzles, maze solving, N-Queens, etc.
	 * 
	 * 
	 * State Management: Clear separation between "discovered" and "processed" Node
	 * states: unvisited → in-stack → processed
	 * 
	 * 
	 * 
	 * CONS:
	 * 
	 * Memory Inefficient: Allows duplicate entries in stack. Stack can grow much
	 * larger in dense graphs
	 * 
	 * Eg. 1->2, 1->3, 1->4 , 2->3
	 * 
	 *  stack:  [1] => [4,3,2] 'stack.top ==2'  => 'pop 2' [4,3,3] ;3 got duplicated in stack
	 *                
	 *  visited: [1] => [1,2]                    => [1,2,3]
	 * 
	 * Performance Overhead: Extra continue checks for already-visited nodes More
	 * stack operations
	 * 
	 * Confusing Semantics: Same node can be in stack multiple times Harder to
	 * reason about stack contents
	 * 
	 * USE CASES for Mark-on-Pop:
	 * 
	 * 1. Path Finding with Actual Path
	 * 
	 * 2. Backtracking Problems (N-Queens, Sudoku solver)
	 * 
	 * 3. Topological Sort (need to track processing order)
	 * 
	 * 4. Strongly Connected Components (Tarjan's algorithm)
	 * 
	 * 5. When you need to distinguish between "discovered" and "processed"
	 * 
	 * 
	 * </pre>
	 * 
	 */
	public static class MarkOnPopTraversal {
		private Set<Integer> visited = new HashSet<>();

		public void dfs(Map<Integer, List<Integer>> graph, int startNode) {

			Stack<Integer> stack = new Stack<>();
			stack.push(startNode);

			while (!stack.isEmpty()) {
				int node = stack.pop();

				// Skip processing of duplicate entries present in stack, because lazy mark allows
				// duplicate entries in 'stack'
				if (visited.contains(node)) {
					continue;
				}

				/** MARK ON POP: Mark only when actually processing */
				visited.add(node);
				System.out.println("Visiting: " + node);

				// Push neighbors without marking them
				// shift all the edges to next generation i.e. placing for execution of child
				// generation
				for (int neighbor : graph.getOrDefault(node, List.of())) {
					if (!visited.contains(neighbor)) {
						stack.push(neighbor); // No marking here!
					}
				}
			}
		}
	}

	public static class DFSRecursive {

		// Recursive DFS for comparison
		public void dfsRecursive(int node) {
			// this method space represents execution-area for input 'node', i.e. processing
			// area of current-stack-frame.
			// Stack.top() or Stack.pop() in iterative version mark the start location of
			// current-stack-frame.

			visited[node] = true;
			preOrder.add(node);
			// represents PRE area, any instruction before next recursion invocation with
			// child

			for (int child : adj.get(node)) {
				if (!visited[child]) {
					dfsRecursive(child);
					// IN area
					inOrder.add(node);
				}
			}

			// POST area after for-loop
			postOrder.add(node);
		}

		private List<List<Integer>> adj;
		private boolean[] visited;
		private List<Integer> preOrder, inOrder, postOrder;

		public DFSRecursive(List<List<Integer>> adj, boolean[] visited, List<Integer> preOrder, List<Integer> inOrder,
				List<Integer> postOrder) {
			super();
			this.adj = adj;
			this.visited = visited;
			this.preOrder = preOrder;
			this.inOrder = inOrder;
			this.postOrder = postOrder;
		}

	}
}
