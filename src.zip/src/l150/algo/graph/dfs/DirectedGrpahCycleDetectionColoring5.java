package l150.algo.graph.dfs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

/**
 * Detect cycle in directed graph using DFS recursion
 * Uses three colors: WHITE (unvisited), GRAY (in recursion stack), BLACK (completed)
 * Cycle exists if we encounter a GRAY node during DFS
 */
public class DirectedGrpahCycleDetectionColoring5 {
	
	
		
	static final class GraphRepresenationOnMap {
	    // Colors
	    private static final int WHITE = 0;
	    private static final int GRAY = 1;
	    private static final int BLACK = 2;

	    public static boolean hasCycle(Map<Integer, List<Integer>> graph) {
	        Map<Integer, Integer> color = new HashMap<>();

	        // Initialize all nodes to WHITE
	        for (Integer node : graph.keySet()) {
	            color.put(node, WHITE);
	        }

	        // Perform DFS from every node
	        for (Integer node : graph.keySet()) {
	            if (color.get(node) == WHITE) {
	                if (dfs(node, graph, color)) {
	                    return true; // Cycle detected
	                }
	            }
	        }
	        return false; // No cycle
	    }

	    private static boolean dfs(Integer node, Map<Integer, List<Integer>> graph, Map<Integer, Integer> color) {
	        
	    	color.put(node, GRAY); // Mark current node as being visited

	        for (Integer neighbor : graph.getOrDefault(node, List.of())) {
	        	
	            int neighborColor = color.get(neighbor);

	            if (neighborColor == GRAY) {
	                // Found a back edge — cycle detected
	                return true;
	            }

	            if (neighborColor == WHITE) {
	                if (dfs(neighbor, graph, color)) {
	                    return true;
	                }
	            }
	        }

	        color.put(node, BLACK); // Fully processed
	        return false;
	    }

	    // Example usage
	    public static void main(String[] args) {
	      

	        Map<Integer, List<Integer>> graph = new HashMap<>();
	        graph.put(0, Arrays.asList(1));
	        graph.put(1, Arrays.asList(2));
	        graph.put(2, Arrays.asList(0)); // Cycle: 0 → 1 → 2 → 0

	        boolean hasCycle = hasCycle(graph);
	        System.out.println("Cycle Detected: " + hasCycle);
	    }
	}
	
	
	
	
	
	
	

	// Graph representation using adjacency list
	static class Graph {
		private int V; // number of vertices
		private List<List<Integer>> adj; // adjacency list

		public Graph(int V) {
			this.V = V;
			adj = new ArrayList<>();
			for (int i = 0; i < V; i++) {
				adj.add(new ArrayList<>());
			}
		}

		public void addEdge(int u, int v) {
			adj.get(u).add(v);
		}

		public List<Integer> getNeighbors(int v) {
			return adj.get(v);
		}

		public int getVertices() {
			return V;
		}
	}
	
	
	private static final int WHITE = 0;
    private static final int GRAY = 1;
    private static final int BLACK = 2;
	
    public static boolean hasCycleDirectedRecursive(Graph graph) {
    	
    	//color array initialized with WHITE
        int[] color = new int[graph.getVertices()]; // 0=WHITE, 1=GRAY, 2=BLACK
        
        //dfs from all the components
        for (int i = 0; i < graph.getVertices(); i++) {
            if (color[i] == WHITE) {
                if (dfsDirectedRecursive(graph, i, color)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private static boolean dfsDirectedRecursive(Graph graph, int current, int[] color) {
        
    	color[current] = GRAY; // Mark as GRAY (in recursion stack)
        
        for (int neighbor : graph.getNeighbors(current)) {
        	
            if (color[neighbor] == GRAY) { // GRAY - back edge found, cycle detected
                return true;
            }
            
            if (color[neighbor] == WHITE && dfsDirectedRecursive(graph, neighbor, color)) {
                return true;
            }
        }
        
        color[current] = BLACK; // Mark as BLACK (completed)
        return false;
    }
    
    /**
     * Detect cycle in directed graph using DFS iteration
     * Simulates the recursion stack behavior using explicit stacks
     */
    public static boolean hasCycleDirectedIterative(Graph graph) {
        int[] color = new int[graph.getVertices()]; // 0=WHITE, 1=GRAY, 2=BLACK
        
        for (int i = 0; i < graph.getVertices(); i++) {
            if (color[i] == 0) {
                if (dfsDirectedIterative(graph, i, color)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    
    
    
    private static boolean dfsDirectedIterative(Graph graph, int start, int[] color) {
        Stack<Integer> stack = new Stack<>();
        Stack<Boolean> visitedChildren = new Stack<>(); // Track if we've processed children
        
        stack.push(start);
        visitedChildren.push(false);
        
        while (!stack.isEmpty()) {
            int node = stack.peek();
            boolean hasVisitedChildren = visitedChildren.peek();
            
            if (!hasVisitedChildren) {
                // First time visiting this node
                if (color[node] == 1) { // GRAY - cycle detected
                    return true;
                }
                
                if (color[node] == 2) { // BLACK - already processed
                    stack.pop();
                    visitedChildren.pop();
                    continue;
                }
                
                color[node] = 1; // Mark as GRAY
                visitedChildren.pop();
                visitedChildren.push(true); // Mark that we're processing children
                
                // Add all unvisited neighbors to stack
                for (int neighbor : graph.getNeighbors(node)) {
                    if (color[neighbor] != 2) { // Not BLACK
                        stack.push(neighbor);
                        visitedChildren.push(false);
                    }
                }
            } else {
                // We've processed all children, mark as BLACK and backtrack
                color[node] = 2;
                stack.pop();
                visitedChildren.pop();
            }
        }
        return false;
    }

}
