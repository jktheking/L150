package l150.algo.graph.bfs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;

/**
 * <pre>
 * Start from a given cell.
 * 
 * Explore neighboring cells level by level using a queue.
 * 
 * Mark visited cells to avoid cycles.
 * 
 * It's commonly used to find the shortest path from source to destination in an
 * unweighted grid.
 * 
 * Use Cases :
 * 
 * 1. Shortest path in maze
 * 
 * 2. Word Ladder (BFS over word transformations)
 * 
 * 3. Rotting Oranges
 * 
 * 4. Flood Fill
 * 
 * 5. Number of Islands (usually DFS but BFS also works)
 * 
 * 
 * </pre>
 */
public class BFSOnGrid2 {
	

	/**
	 * Problem Setup: Shortest Path in a Maze You're given a 2D grid/maze, where:
	 * 
	 * 0 represents an open cell (you can walk there)
	 * 
	 * 1 represents a wall (you cannot walk through)
	 * 
	 * You start at (startRow, startCol)
	 * 
	 * You want to reach (endRow, endCol)
	 * 
	 * Move in 4 directions: up, down, left, right
	 * 
	 * 
	 * Variations You Might Face:
	 * 
	 * Return the actual path, not just length.
	 * 
	 * Weighted paths → use Dijkstra.
	 * 
	 * 8 directions (diagonals).
	 * 
	 * Multiple starting points (multi-source BFS).
	 * 
	 * Walls can be broken k times → need BFS with state.
	 * 
	 * Teleportation portals → treat portal links as edges.
	 * 
	 */

	static class MazeSolverShortestPath {

		static class Cell {
			int row, col, dist;

			Cell(int row, int col, int dist) {
				this.row = row;
				this.col = col;
				this.dist = dist;
			}
		}

		public int shortestPath(int[][] maze, int startRow, int startCol, int endRow, int endCol) {
			int rows = maze.length;
			int cols = maze[0].length;

			if (maze[startRow][startCol] == 1 || maze[endRow][endCol] == 1)
				return -1;

			boolean[][] visited = new boolean[rows][cols];
			Queue<Cell> queue = new LinkedList<>();

			int[][] directions = { { -1, 0 }, // up
					{ 1, 0 }, // down
					{ 0, -1 }, // left
					{ 0, 1 } // right
			};

			queue.offer(new Cell(startRow, startCol, 0));
			visited[startRow][startCol] = true;

			while (!queue.isEmpty()) {
				Cell current = queue.poll();

				if (current.row == endRow && current.col == endCol) {
					return current.dist;
				}

				for (int[] dir : directions) {
					int newRow = current.row + dir[0];
					int newCol = current.col + dir[1];

					if (isValid(newRow, newCol, rows, cols) && maze[newRow][newCol] == 0 && !visited[newRow][newCol]) {
						queue.offer(new Cell(newRow, newCol, current.dist + 1));
						visited[newRow][newCol] = true;
					}
				}
			}

			return -1; // No path found
		}

		private boolean isValid(int row, int col, int rows, int cols) {
			return row >= 0 && col >= 0 && row < rows && col < cols;
		}

		public static void main(String[] args) {
			MazeSolverShortestPath solver = new MazeSolverShortestPath();

			int[][] maze = { { 0, 1, 0, 0, 0 }, { 0, 1, 0, 1, 0 }, { 0, 0, 0, 1, 0 }, { 1, 1, 0, 0, 0 } };

			int shortest = solver.shortestPath(maze, 0, 0, 3, 4);
			System.out.println("Shortest Path: " + shortest); // Output: 10
		}
	}

	/**
	 * 0 = walkable cell
	 * 
	 * 1 = wall
	 * 
	 * P = portal (represented with characters or unique IDs)
	 * 
	 * Portals connect instantaneously
	 * 
	 * Let say we have 'A' on [(1,2), (3,4)] means stepping on either (1,2) or (3,4)
	 * can teleport you to the other.
	 * 
	 */
	static class ShortestPathWithPortal {

		public int shortestPathWithPortals(char[][] maze, int startRow, int startCol, int endRow, int endCol) {
			int rows = maze.length;
			int cols = maze[0].length;

			boolean[][] visited = new boolean[rows][cols];
			Queue<int[]> queue = new LinkedList<>();
			queue.offer(new int[] { startRow, startCol, 0 });
			visited[startRow][startCol] = true;

			// Directions: up, down, left, right
			int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };

			// Map portal letter → all positions
			Map<Character, List<int[]>> portals = new HashMap<>();
			for (int r = 0; r < rows; r++) {
				for (int c = 0; c < cols; c++) {
					char ch = maze[r][c];
					if (Character.isLetter(ch)) {
						portals.computeIfAbsent(ch, k -> new ArrayList<>()).add(new int[] { r, c });
					}
				}
			}

			while (!queue.isEmpty()) {
				int[] current = queue.poll();
				int row = current[0], col = current[1], dist = current[2];

				if (row == endRow && col == endCol)
					return dist;

				// Normal movement
				for (int[] dir : directions) {
					int newRow = row + dir[0];
					int newCol = col + dir[1];

					if (isValid(newRow, newCol, rows, cols) && maze[newRow][newCol] != '1'
							&& !visited[newRow][newCol]) {
						visited[newRow][newCol] = true;
						queue.offer(new int[] { newRow, newCol, dist + 1 });
					}
				}

				// Teleportation
				char ch = maze[row][col];
				if (Character.isLetter(ch)) {
					for (int[] portalDest : portals.get(ch)) {
						int r2 = portalDest[0], c2 = portalDest[1];
						if (!visited[r2][c2]) {
							visited[r2][c2] = true;
							queue.offer(new int[] { r2, c2, dist + 1 });
						}
					}
					// Optional: remove portal entries after using to avoid redundant teleporting
					portals.remove(ch);
				}
			}

			return -1;
		}

		private boolean isValid(int row, int col, int rows, int cols) {
			return row >= 0 && col >= 0 && row < rows && col < cols;
		}

	}

	/**
	 * <pre>
	 * Instead of starting BFS from one source, you start from multiple sources
	 * simultaneously.
	 * 
	 * Just like a fire starting from multiple locations and spreading outward in
	 * waves — all sources expand in parallel.
	 * 
	 * Multi-source BFS is useful when:
	 * 
	 * You want to compute the minimum distance from any of several sources to every
	 * other cell.
	 * 
	 * You want to simulate wave propagation from multiple starting points.
	 * 
	 * Common problems: Rotten Oranges (Leetcode 994)
	 * 
	 * Minimum time to fill grid with water/fire
	 * 
	 * Distance to nearest 0 (Leetcode 542)
	 * 
	 * Zombie in Matrix (zombies spread from multiple cells)
	 * 
	 * 
	 * 
	 * Key Idea :
	 * 
	 * You initialize the BFS queue with all starting points, and perform BFS as
	 * usual.
	 * 
	 * Since BFS is level-by-level, it ensures minimum distance is computed for all
	 * reachable nodes.
	 * 
	 * 
	 * Why Multi-Source BFS Works ?
	 * 
	 * BFS guarantees shortest path in unweighted graphs. If you were to run BFS
	 * from each source individually, you’d waste time. Instead, start them all
	 * together, so:
	 * 
	 * - First arrival at a cell is the shortest. 
	 * - No need to reprocess once visited.
	 * 
	 * </pre>
	 */
	static class MultiSourceBFS {
		
		

	}

}
