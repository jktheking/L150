package l150.algo.graph.bfs;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public class BFSOnGraph1 {

	public static void main(String[] args) {

	}

	/**
	 * <pre>
	 * we mark a node as visited when enqueuing — not when dequeuing — to ensure
	 * correctness and efficiency.
	 * 
	 *  Why mark as visited on enqueuing? 
	 *  
	 *  1. Avoid Duplicate Enqueueing If we delay marking until dequeueing, the same node
	 * might get enqueued multiple times (from multiple parents), which:
	 *  - Wastes memory and time.
	 *  - Can cause incorrect results if you're tracking levels or distances.
	 * 
	 * </pre>
	 */
	public static void bfs(Map<Integer, List<Integer>> graph, int start) {
		Set<Integer> visited = new HashSet<>();
		Queue<Integer> queue = new LinkedList<>();

		queue.offer(start);
		visited.add(start);

		while (!queue.isEmpty()) {
			int current = queue.poll();
			System.out.print(current + " ");

			for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {
				if (!visited.contains(neighbor)) {
					visited.add(neighbor);
					queue.offer(neighbor);
				}
			}
		}
	}

	/**
	 * DFS for graph with multiple components
	 */
	public static class DisconnectedGraphBFS {

		public static void bfsDisconnected(Map<Integer, List<Integer>> graph) {
			Set<Integer> visited = new HashSet<>();

			for (int node : graph.keySet()) {
				if (!visited.contains(node)) {
					bfsComponent(graph, node, visited);
				}
			}
		}

		private static void bfsComponent(Map<Integer, List<Integer>> graph, int start, Set<Integer> visited) {
			Queue<Integer> queue = new LinkedList<>();
			queue.offer(start);
			visited.add(start);

			System.out.print("Component starting from " + start + ": ");

			while (!queue.isEmpty()) {
				int current = queue.poll();
				System.out.print(current + " ");

				for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {
					if (!visited.contains(neighbor)) {
						visited.add(neighbor);
						queue.offer(neighbor);
					}
				}
			}

			System.out.println();
		}
	}

}
