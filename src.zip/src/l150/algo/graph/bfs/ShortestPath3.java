package l150.algo.graph.bfs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

public class ShortestPath3 {

	/**
	 * Why BFS Gives the Shortest Path in an Unweighted Graph ?
	 * 
	 * In an unweighted graph, all 'edges' have the same "cost" (say, 1). So, the
	 * first time you reach a node during BFS, it's guaranteed to be via the
	 * shortest possible path — because BFS explores all nodes at distance d before
	 * moving to distance d+1.
	 * 
	 * The Core Idea of BFS:
	 * 
	 * BFS explores the graph layer by layer. It starts at a source vertex and
	 * visits all of its immediate neighbors. Then, for each of those neighbors, it
	 * visits their unvisited neighbors, and so on. This level-by-level exploration
	 * guarantees that the first time you reach a destination vertex, it will be
	 * through the shortest possible path in terms of the number of edges.
	 * 
	 * Imagine it like ripples in a pond. The source is where the stone drops, the
	 * first ripple is all the direct neighbors, the second ripple is all their
	 * neighbors, and so on.
	 */
	public static class ShortestPathUnweightedGraph {

		public static List<Integer> shortestPath(Map<Integer, List<Integer>> graph, int src, int dest) {
			// Stores parent of each visited node to reconstruct the path
			Map<Integer, Integer> parent = new HashMap<>();

			// To track visited nodes and avoid cycles
			Set<Integer> visited = new HashSet<>();

			// Standard BFS queue
			Queue<Integer> queue = new LinkedList<>();

			// Initialize BFS with the source node
			visited.add(src);
			queue.offer(src);

			parent.put(src, -1); // Source has no parent

			while (!queue.isEmpty()) {
				int current = queue.poll();

				// Stop early if destination is reached
				if (current == dest)
					break;

				// Explore all unvisited neighbors
				for (int neighbor : graph.getOrDefault(current, Collections.emptyList())) {
					if (!visited.contains(neighbor)) {

						visited.add(neighbor);
						parent.put(neighbor, current); // Track how we reached the neighbor
						queue.offer(neighbor);
					}
				}
			}

			// Reconstruct path from destination to source using the parent map
			List<Integer> path = new ArrayList<>();
			if (!parent.containsKey(dest)) {
				return path; // No path found
			}

			// Traverse backward from destination to source
			for (int at = dest; at != -1; at = parent.get(at)) {
				path.add(at);
			}

			// Reverse to get the path from source to destination
			Collections.reverse(path);
			return path;
		}

		/**
		 * Helper function to build an undirected graph from a list of edges.
		 *
		 * @param edges 2D array representing edges [u, v]
		 * @return Graph as a Map<Integer, List<Integer>>
		 */
		public static Map<Integer, List<Integer>> buildGraph(int[][] edges) {
			Map<Integer, List<Integer>> graph = new HashMap<>();

			for (int[] edge : edges) {
				int u = edge[0], v = edge[1];
				// Add edge u → v
				graph.computeIfAbsent(u, k -> new ArrayList<>()).add(v);
				// Add edge v → u (since the graph is undirected)
				graph.computeIfAbsent(v, k -> new ArrayList<>()).add(u);
			}

			return graph;
		}

		public static void main(String[] args) {
			// Define edges of the graph
			int[][] edges = { { 0, 1 }, { 0, 2 }, { 1, 3 }, { 2, 4 }, { 3, 5 }, { 4, 5 } };

			// Define source and destination
			int src = 0, dest = 5;

			// Build the graph from edges
			Map<Integer, List<Integer>> graph = buildGraph(edges);

			// Get the shortest path using BFS
			List<Integer> path = shortestPath(graph, src, dest);

			// Print the result
			if (path.isEmpty()) {
				System.out.println("No path found from " + src + " to " + dest);
			} else {
				System.out.println("Shortest path from " + src + " to " + dest + ": " + path);
			}
		}
	}

	/**
	 * 
	 * Java implementation to find the shortest path from a source vertex to all
	 * other vertices in an un-directed, unweighted graph.
	 * 
	 */

	public static class ShortestPathFromSourceToAllOtherVertices {

		// Adjacency Map: Maps a vertex to a list of its neighbors
		private final Map<Integer, List<Integer>> adj = new HashMap<>();

		// Add an edge to the undirected graph
		public void addEdge(int u, int v) {
			// Ensure both vertices exist in the map
			adj.computeIfAbsent(u, k -> new ArrayList<>()).add(v);
			adj.computeIfAbsent(v, k -> new ArrayList<>()).add(u); // For an undirected graph
		}

		// Finds the shortest path from a source vertex to all other reachable vertices
		public void shortestPath(int src) {

			// distance map, contains distance of each vertex from source, key is vertex and
			// value is distance.
			Map<Integer, Integer> dist = new HashMap<>();
			Queue<Integer> queue = new LinkedList<>();

			// Initialize distance for source
			dist.put(src, 0);
			queue.add(src);

			System.out.println("Shortest paths from source vertex " + src + ":");

			while (!queue.isEmpty()) {
				int u = queue.poll();
				System.out.println("Vertex " + u + " is at distance " + dist.get(u));

				// Get neighbors of u (handle cases where u might not have any neighbors in the
				// map)
				List<Integer> neighbors = adj.getOrDefault(u, Collections.emptyList());

				for (int v : neighbors) {
					// If the vertex has not been visited yet (distance not set)
					if (!dist.containsKey(v)) {
						dist.put(v, dist.get(u) + 1);
						queue.add(v);
					}
				}
			}

			// Optional: Print distances for all vertices that were reachable
			System.out.println("\nAll reachable vertices and their distances:");
			dist.forEach((vertex, distance) -> System.out.println("Vertex " + vertex + ": " + distance));
		}
	}

	/**
	 * <pre>
	 * The Core Idea of Dijkstra's Algorithm:
	 * 
	 * Dijkstra's algorithm is a greedy algorithm that finds the shortest path from
	 * a source vertex to all other vertices in a weighted graph (with non-negative
	 * edge weights). It maintains a set of visited vertices for which the shortest
	 * path is known.
	 * 
	 * 
	 * Why Min-Heap on a BFS-like approach (Dijkstra's) is a Greedy Approach:
	 * 
	 * Dijkstra's algorithm is essentially a "smarter" BFS. Instead of treating all
	 * neighbors equally, it prioritizes the neighbor that is "closest" in terms of
	 * total path weight from the source. This is where the min-heap (implemented as
	 * a PriorityQueue in Java) becomes crucial.
	 * 
	 * Here's the greedy logic:
	 * 
	 * Initialization:
	 * 
	 * Create a dist map to store the shortest distance from the source to every
	 * other vertex. Initialize all distances to infinity, except for the source
	 * vertex, which is 0. Create a min-heap and add the source vertex to it with a
	 * priority of 0 (its distance). 
	 * 
	 * The Greedy Choice:
	 * 
	 * While the min-heap is not empty, greedily extract the vertex with the minimum
	 * distance from the heap. Let's call this vertex u. This is the core of the
	 * greedy approach: we are always picking the vertex that is currently closest
	 * to the source. Mark u as visited. 
	 * 
	 * Relaxation:
	 * ============
	 * For each neighbor v of u, check if we can find a shorter path to v through u.
	 * The new potential distance to v is dist[u] + weight(u, v).
	 * If this new distance is shorter than the current dist[v], update dist[v] and 
	 * add/update v in the min-heap with its new, shorter distance.
	 * 
	 * 
	 * </pre>
	 */
	public static class ShortestPathForNonNegativeWeightedGraph {

		// Edge class to represent a directed edge with weight
		static class Edge {
			int destination;
			int weight;

			Edge(int destination, int weight) {
				this.destination = destination;
				this.weight = weight;
			}
		}

		public static Map<Integer, Integer> dijkstra(Map<Integer, List<Edge>> graph, int src) {
			
			// Step 1: Initialize all distances to infinity
			Map<Integer, Integer> dist = new HashMap<>();
			for (int node : graph.keySet()) {
				dist.put(node, Integer.MAX_VALUE);
			}
			dist.put(src, 0); // Distance to source is 0

			// Min-heap priority queue to always expand the closest unvisited node
			//arr[0] keeps node, and arr[1] keeps distance
			PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
			pq.offer(new int[] { src, 0 });
			

			while (!pq.isEmpty()) {
				int[] current = pq.poll();
				int u = current[0];
				int currentDist = current[1];

				// Skip stale entry if we’ve already found a better path
				//this is similar to visited check
				if (currentDist > dist.get(u))
					continue;

				// Explore neighbors
				for (Edge edge : graph.getOrDefault(u, List.of())) {
					int v = edge.destination;
					int weight = edge.weight;

					// Relaxation: check if new path to v is shorter via u
					int newDistV = dist.get(u) + weight;
					
					if (newDistV < dist.get(v)) {
						dist.put(v, newDistV);
						pq.offer(new int[] { v, newDistV });
					}
				}
			}

			return dist;
		}

		public static void main(String[] args) {
			// Define the graph
			Map<Integer, List<Edge>> graph = new HashMap<>();

			graph.put(0, Arrays.asList(new Edge(1, 4), new Edge(2, 1)));
			graph.put(1, Arrays.asList(new Edge(3, 1)));
			graph.put(2, Arrays.asList(new Edge(1, 2), new Edge(3, 5)));
			graph.put(3, new ArrayList<>()); // No outgoing edges from node 3

			// Run Dijkstra from source node 0
			Map<Integer, Integer> distances = dijkstra(graph, 0);

			// Print shortest distances
			System.out.println("Shortest distances from node 0:");
			for (int node : distances.keySet()) {
				System.out.println("To node " + node + " -> Distance: " + distances.get(node));
			}
		}

	}
}
