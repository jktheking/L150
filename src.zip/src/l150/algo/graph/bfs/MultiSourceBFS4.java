package l150.algo.graph.bfs;

import java.util.LinkedList;
import java.util.Queue;

/**
 * <pre>
 * Instead of starting BFS from one source, you start from multiple sources
 * simultaneously.
 * 
 * Just like a fire starting from multiple locations and spreading outward in
 * waves — all sources expand in parallel.
 * 
 * Multi-source BFS is useful when:
 * 
 * You want to compute the minimum distance from any of several sources to every
 * other cell.
 * 
 * You want to simulate wave propagation from multiple starting points.
 * 
 * 
 * =======================================================
 * Common problems: 
 * 
 * Rotten Oranges (Leetcode 994)
 * 
 * Minimum time to fill grid with water/fire
 * 
 * Distance to nearest 0 (Leetcode 542)
 * 
 * Zombie in Matrix (zombies spread from multiple cells)
 * 
 * =========================================================
 * 
 * Key Idea :
 * 
 * We initialize the BFS queue with all starting points(or source nodes), and perform BFS. Just
 * we need to make sure that we will go to next level (d + 1) for each starting node
 * simultaneously. 
 * 
 * Simultaneous Level Transition for each starting node be done in two ways:
 * 
 * 1. Since we have initialized the queue with all the source nodes, so if we iterate the 
 * queue till queue.size(), which will provide us all the starting nodes. Now we can migrate to next 
 * level for each source node simultaneously by using queue.offer()
 * 
 * OR 
 * 
 * 2. We will not track the source nodes using queue.size() rather  
 * add next level-information as data to queue while initializing the queue.
 * 
 * 
 * 
 * Why Multi-Source BFS Works ?
 * 
 * BFS guarantees shortest path in unweighted graphs. If you were to run BFS
 * from each source individually, you’d waste time. Instead, start them all
 * together, so:
 * 
 * - First arrival at a cell is the shortest. 
 * - No need to re-process once visited.
 * 
 * </pre>
 */
public class MultiSourceBFS4 {

	public static class RottenOranges {

		/**
		 * 
		 * Simultaneous Level transition for each starting node using: queue.size()
		 * 
		 * 1. Since we have initialized the queue with all the starting nodes, so if we
		 * iterate the queue till queue.size(), which will provide me all starting nodes
		 * and then migrate to next level for each starting node by using queue.offer()
		 * 
		 */
		public int orangesRottingV1(int[][] grid) {
			int rows = grid.length, cols = grid[0].length;
			Queue<int[]> queue = new LinkedList<>();
			int fresh = 0;

			// Step 1: Add all initial rotten oranges to queue, which servers as starting
			// node for simultaneous BFS
			for (int r = 0; r < rows; r++) {
				for (int c = 0; c < cols; c++) {
					if (grid[r][c] == 2) {
						queue.offer(new int[] { r, c });
					} else if (grid[r][c] == 1) {
						fresh++;
					}
				}
			}

			// If no fresh orange, return 0
			if (fresh == 0)
				return 0;

			int minutes = 0;
			int[][] directions = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } };

			// Step 2: Multi-Source BFS
			while (!queue.isEmpty()) {

				boolean rotted = false;

				// initially queue.size() provides all the starting nodes from where we need to
				// do simultaneous BFS. Now for each starting node we will go to next level s+1
				// simultaneously by adding them back to queue.
				int size = queue.size();
				for (int i = 0; i < size; i++) {
					int[] orange = queue.poll();
					int row = orange[0], col = orange[1];

					for (int[] dir : directions) {
						int newRow = row + dir[0], newCol = col + dir[1];
						if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols && grid[newRow][newCol] == 1) {

							grid[newRow][newCol] = 2;
							fresh--;
							queue.offer(new int[] { newRow, newCol });
							rotted = true;
						}
					}
				}

				// this is the location post each simultaneous BFS
				if (rotted) {
					minutes++;
				}
			}

			// post BFS ends there should not be any fresh orange.
			return fresh == 0 ? minutes : -1;
		}

		/**
		 * 
		 * Simultaneous Level transition for each starting node using:
		 *
		 * 
		 * 2. We will not track the source nodes using queue.size() rather add next
		 * level-information as data to queue while initializing the queue.
		 * 
		 */
		public int orangesRottingV2(int[][] grid) {
			int rows = grid.length, cols = grid[0].length;
			Queue<int[]> queue = new LinkedList<>();
			int freshCount = 0;

			// Step 1: Initialize BFS with all rotten oranges
			for (int r = 0; r < rows; r++) {
				for (int c = 0; c < cols; c++) {
					if (grid[r][c] == 2) {
						queue.offer(new int[] { r, c, 0 }); // {row, col, minute}
					} else if (grid[r][c] == 1) {
						freshCount++;
					}
				}
			}

			// Step 2: BFS to rot adjacent fresh oranges
			int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };
			int minutes = 0;

			while (!queue.isEmpty()) {
				int[] curr = queue.poll();
				int row = curr[0], col = curr[1], time = curr[2];
				minutes = Math.max(minutes, time);

				for (int[] dir : directions) {
					int newRow = row + dir[0];
					int newCol = col + dir[1];

					if (isValid(newRow, newCol, rows, cols) && grid[newRow][newCol] == 1) {
						grid[newRow][newCol] = 2; // rot it
						freshCount--;

						// next level info is added as queue data, this works as queue follows FIFO
						// so we always get previous-level-node first from each-source before
						// getting next-level-node of the respective source.
						queue.offer(new int[] { newRow, newCol, time + 1 });
					}
				}
			}

			// Step 3: Check if all fresh oranges rotted
			return freshCount == 0 ? minutes : -1;
		}

		private boolean isValid(int r, int c, int rows, int cols) {
			return r >= 0 && c >= 0 && r < rows && c < cols;
		}

	}

	/**
	 * <pre>
	 * Let’s write a BFS that calculates minimum distance to the nearest 1 in a binary matrix
	 * 
	 * Input:
	 * 
	 * int[][] grid = {
	 * 
	    {0, 0, 1},
	    {0, 0, 0},
	    {1, 0, 0}
	
	  };
	
	 * 
	 * output:
	 * 
	 * [
	     [2, 1, 0],
	     [1, 2, 1],
	     [0, 1, 2]
	   ]
	 * 
	 * </pre>
	 */
	static class MinDistanceToNearestOne {

		public int[][] multiSourceBFS(int[][] grid) {

			int rows = grid.length;
			int cols = grid[0].length;

			int[][] dist = new int[rows][cols];
			boolean[][] visited = new boolean[rows][cols];
			Queue<int[]> queue = new LinkedList<>();

			// Add all sources (cells with 1) to the queue
			for (int r = 0; r < rows; r++) {
				for (int c = 0; c < cols; c++) {
					if (grid[r][c] == 1) {
						queue.offer(new int[] { r, c, 0 }); // row, col, distance
						visited[r][c] = true;
					}
				}
			}

			int[][] directions = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };

			// BFS from all sources
			while (!queue.isEmpty()) {

				int[] cell = queue.poll();
				int row = cell[0], col = cell[1], d = cell[2];
				dist[row][col] = d;

				for (int[] dir : directions) {
					int newRow = row + dir[0];
					int newCol = col + dir[1];

					if (isValid(newRow, newCol, rows, cols) && !visited[newRow][newCol] && grid[newRow][newCol] == 0) {
						visited[newRow][newCol] = true;
						// here level information is added to queue itself
						queue.offer(new int[] { newRow, newCol, d + 1 });
					}
				}

			}

			return dist;
		}

		private boolean isValid(int r, int c, int rows, int cols) {
			return r >= 0 && c >= 0 && r < rows && c < cols;
		}

	}

}
