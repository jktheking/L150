package l150.java.lowleveldesign.atm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

public interface ATMEvent {
}

class CardInserted implements ATMEvent {
}

class CardEjected implements ATMEvent {
}

class PinEntered implements ATMEvent {
	public final String pin;

	public PinEntered(String pin) {
		this.pin = pin;
	}
}

class CashWithdrawRequested implements ATMEvent {
	public final int amount;

	public CashWithdrawRequested(int amount) {
		this.amount = amount;
	}
}

 enum ATMState {
    IDLE,
    HAS_CARD,
    AUTHENTICATED,
    OUT_OF_SERVICE
}
 
 


  class ATM {
     private ATMState state;
     private int balance;

     private final Map<Class<? extends ATMEvent>, BiConsumer<ATM, ATMEvent>> eventHandlers = new HashMap<>();

     public ATM(int initialBalance) {
         this.balance = initialBalance;
         this.state = (initialBalance > 0) ? ATMState.IDLE : ATMState.OUT_OF_SERVICE;
         registerEventHandlers();
     }

     private void registerEventHandlers() {
         on(CardInserted.class, (atm, event) -> {
             if (atm.state == ATMState.IDLE) {
                 System.out.println("Card inserted.");
                 atm.state = ATMState.HAS_CARD;
             } else {
                 System.out.println("Card already inserted or ATM unavailable.");
             }
         });

         on(CardEjected.class, (atm, event) -> {
             if (atm.state == ATMState.HAS_CARD || atm.state == ATMState.AUTHENTICATED) {
                 System.out.println("Card ejected.");
                 atm.state = ATMState.IDLE;
             } else {
                 System.out.println("No card to eject.");
             }
         });

         on(PinEntered.class, (atm, event) -> {
             if (atm.state == ATMState.HAS_CARD) {
                 PinEntered pinEvent = (PinEntered) event;
                 if ("1234".equals(pinEvent.pin)) {
                     System.out.println("PIN correct.");
                     atm.state = ATMState.AUTHENTICATED;
                 } else {
                     System.out.println("Incorrect PIN. Ejecting card.");
                     atm.state = ATMState.IDLE;
                 }
             } else {
                 System.out.println("Insert card first.");
             }
         });

         on(CashWithdrawRequested.class, (atm, event) -> {
             if (atm.state == ATMState.AUTHENTICATED) {
                 int amount = ((CashWithdrawRequested) event).amount;
                 if (atm.balance >= amount) {
                     atm.balance -= amount;
                     System.out.println("Dispensed ₹" + amount + ". Remaining balance: ₹" + atm.balance);
                     if (atm.balance == 0) {
                         atm.state = ATMState.OUT_OF_SERVICE;
                         System.out.println("ATM out of service.");
                     } else {
                         atm.state = ATMState.IDLE;
                         System.out.println("Card ejected.");
                     }
                 } else {
                     System.out.println("Insufficient funds. Card ejected.");
                     atm.state = ATMState.IDLE;
                 }
             } else {
                 System.out.println("Not authenticated. Cannot withdraw.");
             }
         });
     }

     private <T extends ATMEvent> void on(Class<T> eventClass, BiConsumer<ATM, T> handler) {
    	 //this will throw error
    	// eventHandlers.put(eventClass, handler);
    	 
    	 //so bridge method
         eventHandlers.put(eventClass, (atm, event) -> handler.accept(atm, eventClass.cast(event)));
     }
     
     
     
     public void emit(ATMEvent event) {
         BiConsumer<ATM, ATMEvent> handler = eventHandlers.get(event.getClass());
         if (handler != null) {
             handler.accept(this, event);
         } else {
             System.out.println("No handler for event: " + event.getClass().getSimpleName());
         }
     }

     public void printState() {
         System.out.println("ATM State: " + state + ", Balance: ₹" + balance);
     }
 }
  
  
  
  
 
   class EventDispatcher1<A, E> {

      private final Map<Class<? extends E>, List<BiConsumer<A, E>>> handlers = new HashMap<>();

      public <T extends E> void registerHandler(Class<T> eventType, BiConsumer<A, T> handler) {
    	  
          BiConsumer<A, E> safeHandler = (aggregate, event) -> {
              handler.accept(aggregate, eventType.cast(event)); // Type-safe cast
          };
          handlers
              .computeIfAbsent(eventType, k -> new ArrayList<>())
              .add(safeHandler);
      }

      public void dispatch(A aggregate, E event) {
          Class<?> eventClass = event.getClass();
          List<BiConsumer<A, E>> registered = handlers.get(eventClass);
          if (registered != null) {
              for (BiConsumer<A, E> handler : registered) {
                  handler.accept(aggregate, event);
              }
          }
      }
  }

   
   
  
    class EventDispatcher1A<A, E> {

       private final Map<Class<? extends E>, List<BiConsumer<A, E>>> handlers = new HashMap<>();

       public <T extends E> void registerHandler(Class<T> eventType, BiConsumer<A, T> handler) {
           BiConsumer<A, E> safeHandler = new SafeHandler<>(eventType, handler);
           handlers
               .computeIfAbsent(eventType, k -> new ArrayList<>())
               .add(safeHandler);
       }

       public void dispatch(A aggregate, E event) {
           Class<?> eventClass = event.getClass();
           List<BiConsumer<A, E>> registered = handlers.get(eventClass);
           if (registered != null) {
               for (BiConsumer<A, E> handler : registered) {
                   handler.accept(aggregate, event);
               }
           }
       }

       /**
        * Inner class to safely cast E to the expected subtype T before invoking the handler.
        */
       private static class SafeHandler<A, E, T extends E> implements BiConsumer<A, E> {
           private final Class<T> eventType;
           private final BiConsumer<A, T> actualHandler;

           public SafeHandler(Class<T> eventType, BiConsumer<A, T> actualHandler) {
               this.eventType = eventType;
               this.actualHandler = actualHandler;
           }

           @Override
           public void accept(A aggregate, E event) {
               // Safe cast guaranteed by the Class<T> check
               actualHandler.accept(aggregate, eventType.cast(event));
           }
       }
   }

  
  
   class EventDispatcher2<A, E> {
	    private final Map<Class<? extends E>, List<BiConsumer<A, ? extends E>>> handlers = new HashMap<>();

	    public <T extends E> void registerHandler(Class<T> eventType, BiConsumer<A, T> handler) {
	        handlers
	            .computeIfAbsent(eventType, k -> new ArrayList<>())
	            .add((BiConsumer<A, ? extends E>) handler); // Safe cast
	    }

	    public void dispatch(A aggregate, E event) {
	        List<BiConsumer<A, ? extends E>> eventHandlers = handlers.get(event.getClass());

	        if (eventHandlers != null) {
	            for (BiConsumer<A, ? extends E> handler : eventHandlers) {
	                @SuppressWarnings("unchecked")
	                BiConsumer<A, E> safeHandler = (BiConsumer<A, E>) handler;
	                safeHandler.accept(aggregate, event);
	            }
	        } else {
	            System.out.println("No handler found for event: " + event.getClass().getSimpleName());
	        }
	    }
	}

   
class GenericATM{
	
	private ATMState state;
    private int balance;
	
	
	private final EventDispatcher2<GenericATM, ATMEvent> dispatcher = new EventDispatcher2<>();

	 public GenericATM(int initialBalance) {
         this.balance = initialBalance;
         this.state = (initialBalance > 0) ? ATMState.IDLE : ATMState.OUT_OF_SERVICE;
         registerEventHandlers();
     }
	
	
	private void registerEventHandlers() {
	    dispatcher.registerHandler(CardInserted.class, (atm, event) -> {
	        if (atm.state == ATMState.IDLE) {
	            System.out.println("Card inserted.");
	            atm.state = ATMState.HAS_CARD;
	        } else {
	            System.out.println("Card already inserted or ATM unavailable.");
	        }
	    });

	    dispatcher.registerHandler(CardEjected.class, (atm, event) -> {
	        if (atm.state == ATMState.HAS_CARD || atm.state == ATMState.AUTHENTICATED) {
	            System.out.println("Card ejected.");
	            atm.state = ATMState.IDLE;
	        } else {
	            System.out.println("No card to eject.");
	        }
	    });

	    dispatcher.registerHandler(PinEntered.class, (atm, event) -> {
	        if (atm.state == ATMState.HAS_CARD) {
	            if ("1234".equals(event.pin)) {
	                System.out.println("PIN correct.");
	                atm.state = ATMState.AUTHENTICATED;
	            } else {
	                System.out.println("Incorrect PIN. Ejecting card.");
	                atm.state = ATMState.IDLE;
	            }
	        } else {
	            System.out.println("Insert card first.");
	        }
	    });

	    dispatcher.registerHandler(CashWithdrawRequested.class, (atm, event) -> {
	        if (atm.state == ATMState.AUTHENTICATED) {
	            int amount = event.amount;
	            if (atm.balance >= amount) {
	                atm.balance -= amount;
	                System.out.println("Dispensed ₹" + amount + ". Remaining balance: ₹" + atm.balance);
	                if (atm.balance == 0) {
	                    atm.state = ATMState.OUT_OF_SERVICE;
	                    System.out.println("ATM out of service.");
	                } else {
	                    atm.state = ATMState.IDLE;
	                    System.out.println("Card ejected.");
	                }
	            } else {
	                System.out.println("Insufficient funds. Card ejected.");
	                atm.state = ATMState.IDLE;
	            }
	        } else {
	            System.out.println("Not authenticated. Cannot withdraw.");
	        }
	    });
	}
	
	public void emit(ATMEvent event) {
	    dispatcher.dispatch(this, event);
	}
	
	
	
}
