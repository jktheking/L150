package l150.java.lowleveldesign;

public interface CustomMap<K, V> {

	V put(K key, V val);

	V get(K key);

	boolean containsKey(K key);

	boolean isEmpty();

	V remove(K key);

}
