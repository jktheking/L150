package l150.java.lowleveldesign;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class CustomConcurrentHashMap<K, V> {
	private final int numberOfSegments;
	private final Map<K, V>[] segments;
	private final ReentrantReadWriteLock[] locks;

	public CustomConcurrentHashMap(int numberOfSegments) {
		if (numberOfSegments <= 0) {
			throw new IllegalArgumentException("Number of segments must be positive");
		}
		this.numberOfSegments = numberOfSegments;
		this.segments = new Map[numberOfSegments];

		this.locks = new ReentrantReadWriteLock[numberOfSegments];

		for (int i = 0; i < numberOfSegments; i++) {
			segments[i] = new HashMap<>();
			locks[i] = new ReentrantReadWriteLock();
		}
	}

	private int getSegmentIndex(K key) {
		return Math.abs(key.hashCode() % numberOfSegments);
	}

	public V put(K key, V value) {
		int segmentIndex = getSegmentIndex(key);
		locks[segmentIndex].writeLock().lock();
		try {
			return segments[segmentIndex].put(key, value);
		} finally {
			locks[segmentIndex].writeLock().unlock();
		}
	}

	public V get(K key) {
		int segmentIndex = getSegmentIndex(key);
		locks[segmentIndex].readLock().lock();
		try {
			return segments[segmentIndex].get(key);
		} finally {
			locks[segmentIndex].readLock().unlock();
		}
	}

	public boolean containsKey(K key) {
		int segmentIndex = getSegmentIndex(key);
		locks[segmentIndex].readLock().lock();
		try {
			return segments[segmentIndex].containsKey(key);
		} finally {
			locks[segmentIndex].readLock().unlock();
		}
	}

	public V remove(K key) {
		int segmentIndex = getSegmentIndex(key);
		locks[segmentIndex].writeLock().lock();
		try {
			return segments[segmentIndex].remove(key);
		} finally {
			locks[segmentIndex].writeLock().unlock();
		}
	}
}
