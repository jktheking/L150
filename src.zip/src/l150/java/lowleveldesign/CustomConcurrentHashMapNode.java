package l150.java.lowleveldesign;

import java.util.concurrent.locks.ReentrantLock;

public class CustomConcurrentHashMapNode<K, V> {
	private static final int DEFAULT_CAPACITY = 16;
	private static final float LOAD_FACTOR = 0.75f;

	private volatile Node<K, V>[] table;
	private volatile int size = 0; // Tracks the number of elements
	private final ReentrantLock resizeLock = new ReentrantLock();

	static class Node<K, V> {
		final K key;
		V value;
		final int hash;
		volatile Node<K, V> next;
		final ReentrantLock lock = new ReentrantLock();

		Node(K key, V value, int hash, Node<K, V> next) {
			this.key = key;
			this.value = value;
			this.hash = hash;
			this.next = next;
		}
	}

	public CustomConcurrentHashMapNode() {
		this.table = (Node<K, V>[]) new Node[DEFAULT_CAPACITY];
	}

	// Method to calculate the hash
	private int calculateHash(Object key) {
		int h;
		return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
	}

	// Method to get the index from the hash
	private int getIndex(int hash, int length) {
		return (length - 1) & hash;
	}

	public V put(K key, V value) {
		int hash = calculateHash(key);
		Node<K, V>[] tab = table;
		int index = getIndex(hash, tab.length);

		Node<K, V> newNode = new Node<>(key, value, hash, null);
		Node<K, V> head = tab[index];

		if (head == null) {
			synchronized (tab) {
				if (tab[index] == null) {
					tab[index] = newNode;
					incrementSize();
					resizeIfNeeded();
					return null;
				}
			}
		}

		Node<K, V> current = head;
		Node<K, V> prev = null;
		while (current != null) {
			current.lock.lock();
			try {
				if (current.hash == hash && current.key.equals(key)) {
					V oldValue = current.value;
					current.value = value;
					return oldValue;
				}
				prev = current;
				current = current.next;
			} finally {
				prev.lock.unlock();
			}
		}

		prev.lock.lock();
		try {
			prev.next = newNode;
			incrementSize();
			resizeIfNeeded();
		} finally {
			prev.lock.unlock();
		}
		return null;
	}

	public V get(K key) {
		int hash = calculateHash(key);
		Node<K, V>[] tab = table;
		int index = getIndex(hash, tab.length);
		Node<K, V> current = tab[index];

		while (current != null) {
			current.lock.lock();
			try {
				if (current.hash == hash && current.key.equals(key)) {
					return current.value;
				}
				current = current.next;
			} finally {
				current.lock.unlock();
			}
		}
		return null;
	}

	public V remove(K key) {
		int hash = calculateHash(key);
		Node<K, V>[] tab = table;
		int index = getIndex(hash, tab.length);
		Node<K, V> current = tab[index];
		Node<K, V> prev = null;

		while (current != null) {
			current.lock.lock();
			try {
				if (current.hash == hash && current.key.equals(key)) {
					V oldValue = current.value;
					if (prev == null) {
						tab[index] = current.next;
					} else {
						prev.next = current.next;
					}
					decrementSize();
					return oldValue;
				}
				prev = current;
				current = current.next;
			} finally {
				current.lock.unlock();
			}
		}
		return null;
	}

	// Synchronized method to increment the size and ensure atomicity
	private synchronized void incrementSize() {
		size++;
	}

	// Synchronized method to decrement the size and ensure atomicity
	private synchronized void decrementSize() {
		size--;
	}

	// Method to check if resizing is needed and perform the resize
	private void resizeIfNeeded() {
		if (size >= LOAD_FACTOR * table.length) {
			resize();
		}
	}

	// Method to resize the table
	private void resize() {
		resizeLock.lock();
		try {
			Node<K, V>[] oldTable = table;
			Node<K, V>[] newTable = (Node<K, V>[]) new Node[oldTable.length * 2];

			for (Node<K, V> head : oldTable) {
				while (head != null) {
					Node<K, V> next = head.next;

					int newIndex = getIndex(head.hash, newTable.length);
					head.next = newTable[newIndex];
					newTable[newIndex] = head;

					head = next;
				}
			}
			table = newTable;
		} finally {
			resizeLock.unlock();
		}
	}
}
