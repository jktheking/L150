package l150.java.lowleveldesign;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class SegmentedConcurrentHashMap<K, V> implements CustomMap<K, V> {

	private final int segmentCount;
	private final ReentrantReadWriteLock[] segLocks;
	private final Map<K, V>[] table;

	@SuppressWarnings("unchecked")
	public SegmentedConcurrentHashMap(int segmentCount) {
		super();
		this.segmentCount = segmentCount;
		this.segLocks = new ReentrantReadWriteLock[segmentCount];
		this.table = new Map[segmentCount];
		initLockAndTable(segmentCount);
	}

	private void initLockAndTable(int segmentCount) {
		for (int i = 0; i < segmentCount; i++) {
			segLocks[i] = new ReentrantReadWriteLock();
			table[i] = new HashMap<>();
		}
	}

	private int getSegmentIndex(K key) {
		return Math.abs(key.hashCode() % segmentCount);
	}

	@Override
	public V put(K key, V val) {

		segLocks[getSegmentIndex(key)].writeLock().lock();
		try {
			return table[getSegmentIndex(key)].put(key, val);
		} finally {
			segLocks[getSegmentIndex(key)].writeLock().unlock();
		}
	}

	@Override
	public V get(K key) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean containsKey(K key) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public V remove(K key) {
		// TODO Auto-generated method stub
		return null;
	}

}
