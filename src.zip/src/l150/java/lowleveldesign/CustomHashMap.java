package l150.java.lowleveldesign;

import java.util.ArrayList;
import java.util.List;

public class CustomHashMap<K, V> {
	private static final int DEFAULT_CAPACITY = 16;
	private static final double LOAD_FACTOR = 0.75;

	private int size;
	private int capacity;
	private List<Entry<K, V>>[] buckets;

	public CustomHashMap() {
		this(DEFAULT_CAPACITY);
	}

	public CustomHashMap(int capacity) {
		this.capacity = capacity;

		this.buckets = new List[capacity];
	}

	public void put(K key, V value) {
		if (key == null)
			return; // Disallow null keys (for simplicity)

		if (size >= capacity * LOAD_FACTOR) {
			resize();
		}

		int index = getIndex(key);
		List<Entry<K, V>> bucket = buckets[index];
		if (bucket == null) {
			bucket = new ArrayList<>();
			buckets[index] = bucket;
		}

		for (Entry<K, V> entry : bucket) {
			if (entry.key.equals(key)) {
				entry.value = value;
				return;
			}
		}

		bucket.add(new Entry<>(key, value));
		size++;
	}

	public V get(K key) {
		if (key == null)
			return null; // Disallow null keys (for simplicity)

		int index = getIndex(key);
		List<Entry<K, V>> bucket = buckets[index];
		if (bucket != null) {
			for (Entry<K, V> entry : bucket) {
				if (entry.key.equals(key)) {
					return entry.value;
				}
			}
		}
		return null;
	}

	public boolean containsKey(K key) {
		return get(key) != null;
	}

	public int size() {
		return size;
	}

	private int getIndex(K key) {
		return Math.abs(key.hashCode() % capacity);
	}

	private void resize() {
		int newCapacity = capacity * 2;
		List<Entry<K, V>>[] newBuckets = new List[newCapacity];

		for (List<Entry<K, V>> bucket : buckets) {
			if (bucket != null) {
				for (Entry<K, V> entry : bucket) {
					int index = Math.abs(entry.key.hashCode() % newCapacity);
					if (newBuckets[index] == null) {
						newBuckets[index] = new ArrayList<>();
					}
					newBuckets[index].add(entry);
				}
			}
		}

		capacity = newCapacity;
		buckets = newBuckets;
	}

	private static class Entry<K, V> {
		K key;
		V value;

		Entry(K key, V value) {
			this.key = key;
			this.value = value;
		}
	}
}
