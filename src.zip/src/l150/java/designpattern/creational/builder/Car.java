package l150.java.designpattern.creational.builder;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Objects;
import java.util.function.Function;

public abstract class Car {

	private final String chasisNo;
	private final String engineNo;

	abstract static class Builder<T extends Builder<T>> {

		private String chasisNo;
		private final String engineNo;

		Builder(String engineNo) {
			this.engineNo = engineNo;
		}

		Builder<T> chasisNo(String chasisNo) {
			this.chasisNo = chasisNo;
			return self();
		}

		abstract Car build();

		protected abstract T self();

	}

	public static <T, U extends Comparable<? super U>> Comparator<T> comparing(
			Function<? super T, ? extends U> keyExtractor) {
		Objects.requireNonNull(keyExtractor);
		return (Comparator<T> & Serializable) (c1, c2) -> keyExtractor.apply(c1).compareTo(keyExtractor.apply(c2));
	}

//	private Car(Builder<?> builder) {
//
//	}

}
