package l150.java.designpattern.creational.builder;

public class SportsCar extends Car {

}
