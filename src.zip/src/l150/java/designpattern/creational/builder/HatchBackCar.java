package l150.java.designpattern.creational.builder;

public class HatchBackCar extends Car {

}
