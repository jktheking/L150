package l150.java.designpattern.creational.builder;

public class Main {

	private static Integer instanceInt = new Integer(9);

	public static void main(String[] args) throws InterruptedException {

		Pizza pizza = new NyPizza.Builder(NyPizza.Size.SMALL).addTopping(Pizza.Topping.SAUSAGE)
				.addTopping(Pizza.Topping.ONION).build();

		Pizza calzone = new Calzone.Builder().addTopping(Pizza.Topping.HAM).sauceInside().build();

	}

}
