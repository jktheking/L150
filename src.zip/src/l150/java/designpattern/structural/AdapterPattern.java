package l150.java.designpattern.structural;

/**
 * <pre>
 * Adapter is a structural design pattern that allows objects with incompatible
 * interfaces to collaborate. The object, that joins these unrelated interfaces,
 * is called an Adapter.
 * 
 * Problem Statement:
 *  -------------------- 
 * You are developing a software system
 * that primarily uses JSON for data processing and communication. However, one
 * of the key components or services in the system returns data in XML format.
 * Refactoring the entire component to support JSON natively would be costly and
 * time-consuming. Additionally, changing the existing system interface that
 * expects JSON is not feasible.
 *
 *To integrate the XML-based service with the existing JSON-based system, you
 * need a solution that can convert the XML data to JSON without modifying the
 * core functionality of either the XML service or the JSON interface.
 * 
 * 
 * Participants of Adapter Design Pattern:
 * ---------------------------------------
 * Target (JsonConverter): It defines the application-specific interface that Client uses directly.
 * 
 * Adapter (XmlToJsonAdpater): It adapts the interface Adaptee to the Target interface. It’s middle man.
 * 
 * Adaptee (XmlProcessor): It defines an existing incompatible interface that needs adapting before using in application.
 * 
 * Client: It is your application that works with Target interface.
 * 
 *  1.Question: What is getting encapsulated out ?
 *    Answer: The translation logic which sits inside adapter object.
 * 
 *  2. Question: What is getting decoupled ? 
 *   Answer: The client code is decoupled from Adaptee via adapter.
 * 
 * </pre>
 * 
 * 
 */
public class AdapterPattern {

	// Target interface
	public interface JSONConverter {
		String convertToJSON(String xmlData);
	}

	public class XMLProcessor {
		public String getXMLData() {
			// Simulate an XML structure (in reality, this would be more complex)
			return "<person><name>John</name><age>30</age></person>";
		}
	}

	public class XMLToJSONAdapter implements JSONConverter {
		private final XMLProcessor xmlProcessor;

		public XMLToJSONAdapter(XMLProcessor xmlProcessor) {
			this.xmlProcessor = xmlProcessor;
		}

		@Override
		public String convertToJSON(String xmlData) {
			// Convert XML to JSON using an external library, such as org.json
			return "";
		}
	}

	public class Client {
		public void main(String[] args) {
			// Adaptee (existing XML processor)
			XMLProcessor xmlProcessor = new XMLProcessor();
			// Get XML data from XMLProcessor
			String xmlData = xmlProcessor.getXMLData();

			// Adapter
			JSONConverter jsonConverter = new XMLToJSONAdapter(xmlProcessor);

			// Convert XML to JSON via the adapter
			String jsonData = jsonConverter.convertToJSON(xmlData);

			System.out.println("Converted JSON: " + jsonData);
		}
	}

}
