package l150.java.designpattern.structural;

/**
 * <pre>
 * 
 * link: https://refactoring.guru/design-patterns/bridge
 * link:https://howtodoinjava.com/design-patterns/structural/bridge-design-pattern/
 * 
 * 
 * Problem Statement:
 * -------------------
 * Consider a scenario where you need to represent different Shapes and Colors. 
 * If you use inheritance to combine these two hierarchies, you might end up with classes like:
 * 
 *static abstract class Shape {}
 *static class RedSquare extends Shape {}
 *static class RedTriangle extends Shape {}
 *static class BlueSquare extends Shape {}
 *static class BlueTriangle extends Shape {}
 * 
 * As the number of shapes and colors increases, the number of combinations grows exponentially. 
 * This results in a large, unmanageable class hierarchy, which is neither scalable nor maintainable.
 * 
 * 
 * Solution:
 *------------
 * The bridge pattern is an application of the old advice, “prefer composition over inheritance“.
 * 
 * The bridge design pattern is used to decouple a class-hierarchy into two
 * parts – abstraction class-hierarchy and its implementation class-hierarchy;
 * so that both can evolve in the future without affecting each other.
 * 
 * The GoF book introduces the terms Abstraction and Implementation as part of
 * the Bridge definition. Note that we’re not talking about interfaces or
 * abstract classes from the programming languages. These aren’t the same
 * things.
 * 
 * Abstraction (also called interface, c.f GUI) is a high-level control layer
 * for some entity. This layer isn’t supposed to do any real work on its own. It
 * should delegate the work to the implementation layer (also called platform,
 * c.f. OS kernel API)
 * 
 * 1. Question: What is getting decoupled ?
 * 
 * Answer: 'Implementation' is decoupled from 'Abstraction'
 * 
 * 2.Question: What is getting encapsulated out ?
 * 
 * Answer: Implementation is getting encapsulated out of Abstraction.
 * 
 * 3.Question: What is bridge ?
 *    Answer : 'HAS-A' acts as bridge between 'Abstraction' and 'Implementation'
 *   
 * 
 * Example:  
 * c.f  Shape-Hierarchy  with 'Abstraction'
 * c.f  Color-Hierarchy  with 'Implementation'
 * 
 * c.f Shape(Color c){} HAS-A bridge
 * 
 * 
 * </pre>
 */
public class BridgePattern {

	public static void main(String[] args) {

		String os = "linux";
		FileDownloaderAbstraction downloader = null;

		switch (os) {
		case "windows":
			downloader = new FileDownloaderAbstractionImpl(new WindowsFileDownloadImplementor());
			break;

		case "linux":
			downloader = new FileDownloaderAbstractionImpl(new LinuxFileDownloadImplementor());
			break;

		default:
			System.out.println("OS not supported !!");
		}

		Object fileContent = downloader.download("some path");
		downloader.store(fileContent);

	}

	public interface FileDownloaderAbstraction {

		public Object download(String path);

		public boolean store(Object object);
	}

	public interface FileDownloadImplementor {

		public Object downloadFile(String path);

		public boolean storeFile(Object object);
	}

	// Abstraction_1
	public static class FileDownloaderAbstractionImpl implements FileDownloaderAbstraction {

		private FileDownloadImplementor provider = null;

		public FileDownloaderAbstractionImpl(FileDownloadImplementor provider) {
			super();
			this.provider = provider;
		}

		@Override
		public Object download(String path) {
			return provider.downloadFile(path);
		}

		@Override
		public boolean store(Object object) {
			return provider.storeFile(object);
		}
	}

	// Abstraction_2
	public static class AheadOfTimeFileDownloaderAbstractionImpl implements FileDownloaderAbstraction {

		private FileDownloadImplementor provider = null;

		public AheadOfTimeFileDownloaderAbstractionImpl(FileDownloadImplementor provider) {
			super();
			this.provider = provider;
		}

		@Override
		public Object download(String path) {
			return provider.downloadFile(path);
		}

		@Override
		public boolean store(Object object) {
			return provider.storeFile(object);
		}

		public void aheadOfTime() {
			System.out.println("AOH Functionality");
		}
	}

	// Implementation_1
	public static class LinuxFileDownloadImplementor implements FileDownloadImplementor {

		@Override
		public Object downloadFile(String path) {
			return new Object();
		}

		@Override
		public boolean storeFile(Object object) {
			System.out.println("File downloaded successfully in LINUX !!");
			return true;
		}
	}

	// Implementation_2
	public static class WindowsFileDownloadImplementor implements FileDownloadImplementor {
		@Override
		public Object downloadFile(String path) {
			return new Object();
		}

		@Override
		public boolean storeFile(Object object) {
			System.out.println("File downloaded successfully in WINDOWS !!");
			return true;
		}
	}

}
