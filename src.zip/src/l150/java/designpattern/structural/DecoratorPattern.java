package l150.java.designpattern.structural;

/**
 * <pre>
 * - We use inheritance or composition to extend the behavior of an object but
 * this is done at compile time and its applicable to all the instances of the
 * class. We can’t add any new functionality of remove any existing behavior at
 * runtime - this is when Decorator pattern comes into picture.
 * 
 * - In object-oriented programming, the decorator pattern is a design pattern
 * that allows behavior to be added to an individual object, dynamically,
 * without affecting the behavior of other instances of the same class.
 * 
 * -The decorator pattern is often useful for adhering to the Single
 * Responsibility Principle, as it allows functionality to be divided between
 * classes with unique areas of concern as well as to the Open-Closed Principle,
 * by allowing the functionality of a class to be extended without being
 * modified.
 * 
 * - Decorator use can be more efficient than subclassing, because an object's
 * behavior can be augmented without defining an entirely new object.
 * 
 * Decorator pattern players:
 * 
 * 1. component : The entity which is getting enhanced at runtime
 * 2. decorator : Features of component which is encapsulated out.
 * 
 * What is getting decoupled ?
 * Varying features of component are getting encapsulated out as reusable decorators.
 *
 * 
 * Since we want to add or remove functionality at runtime, of a Component
 * without modifying the original component, means we have to define the
 * Decorator which takes original component as input(HAS-A), it's better to
 * define abstract decorator so that multiple flavor of decorator can be piped
 * together to get the new features at runtime.
 * 
 * Note: piping happens because decorator implements component interface.
 * 
 * </pre>
 */
public class DecoratorPattern {

	public static void main(String[] args) {
		// Create a decorated Window with horizontal and vertical scrollbars
		Window decoratedWindow = new HorizontalScrollBarDecorator(new VerticalScrollBarDecorator(new SimpleWindow()));

		// Print the Window's description
		System.out.println(decoratedWindow.getDescription());
	}

	// The Component interface
	public interface Window {
		void draw(); // Draws the Window

		String getDescription(); // Returns a description of the Window
	}

	// Implementation of the Component, whose instances will be used to augment at
	// runtime by decorator
	static class SimpleWindow implements Window {
		@Override
		public void draw() {
			// Draw window
		}

		@Override
		public String getDescription() {
			return "simple window";
		}
	}

	// abstract decorator class - note that it implements component Window, and
	// have window as HAS-A for piping.
	static abstract class WindowDecorator implements Window {
		private final Window windowToBeDecorated; // the Window being decorated

		public WindowDecorator(Window windowToBeDecorated) {
			this.windowToBeDecorated = windowToBeDecorated;
		}

		@Override
		public void draw() {
			windowToBeDecorated.draw(); // Delegation
		}

		@Override
		public String getDescription() {
			return windowToBeDecorated.getDescription(); // Delegation
		}
	}

	// The second concrete decorator which adds horizontal scrollbar functionality
	static class HorizontalScrollBarDecorator extends WindowDecorator {
		public HorizontalScrollBarDecorator(Window windowToBeDecorated) {
			super(windowToBeDecorated);
		}

		@Override
		public void draw() {
			super.draw();
			drawHorizontalScrollBar();

		}

		private void drawHorizontalScrollBar() {
			// Draw the horizontal scrollbar
		}

		@Override
		public String getDescription() {
			return super.getDescription() + ", including horizontal scrollbars";
		}
	}

	// The first concrete decorator which adds vertical scrollbar functionality
	// at runtime to constructor parameter 'windowToBeDecorated'
	static class VerticalScrollBarDecorator extends WindowDecorator {
		public VerticalScrollBarDecorator(Window windowToBeDecorated) {
			super(windowToBeDecorated);
		}

		@Override
		public void draw() {
			super.draw();
			drawVerticalScrollBar();
		}

		private void drawVerticalScrollBar() {
			// Draw the vertical scrollbar
		}

		@Override
		public String getDescription() {
			return super.getDescription() + ", including vertical scrollbars";
		}
	}

}
