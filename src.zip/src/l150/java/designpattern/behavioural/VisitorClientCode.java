package l150.java.designpattern.behavioural;

/**
 * 
 * In essence, the visitor allows adding new virtual functions to a family of
 * classes, without modifying the classes. Instead, a visitor class is created
 * that implements all of the appropriate specializations of the virtual
 * function.
 * 
 * The visitor takes the instance reference as input, and implements the goal
 * through double dispatch.
 * 
 * ==> If we use inheritance structure, then we need to completely override the
 * functionality in all the sub-classes, and none of the implementation shares
 * the common code.
 * 
 * ==> When we have very stable object structure that we don't want to change
 * for any reason.
 * 
 * When new operations are needed frequently and the object structure consists
 * of many unrelated things.
 * 
 * 
 * Interface:
 * 
 * Visitor{ // all unrelated functionalities on object structure }
 * 
 * cf: visitor with narad-muni
 * 
 * 
 */
public class VisitorClientCode {
	public static void main(String[] args) {
		CarElement wheel = new Wheel();
		/** first dispatch; a gate for visitor to enter into the house */
		wheel.accept(new CarElementVisitorImpl());
	}
}

//Visitor interface contains overloaded methods
interface CarElementVisitor {
	default void visit(Body body) {}

	default void  visit(Car car) {}

	default void visit(Engine engine) {}

	default void visit(Wheel wheel) {}
}

class CarElementVisitorImpl implements CarElementVisitor {

}

interface CarElement {
	// Here we are inserting behaviour from outside in existing object structure.
	// a gate for visitor to enter into the house
	void accept(CarElementVisitor visitor);
}

class Wheel implements CarElement {
	@Override
	public void accept(CarElementVisitor visitor) {
		// secod dispatch; allowing visitor to see the house
		// calls overloaded method
		visitor.visit(this);
	}
}

class Body implements CarElement {
	@Override
	public void accept(CarElementVisitor visitor) {
		// secod dispatch; allowing visitor to see the house
		// calls overloaded method
		visitor.visit(this);
	}
}

class Car implements CarElement {
	@Override
	public void accept(CarElementVisitor visitor) {
		// secod dispatch; allowing visitor to see the house
		// calls overloaded method
		visitor.visit(this);
	}
}

class Engine implements CarElement {
	@Override
	public void accept(CarElementVisitor visitor) {
		// secod dispatch; allowing visitor to see the house
		// calls overloaded method
		visitor.visit(this);
	}
}
