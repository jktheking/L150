package l150.java.concurrent.synchronizers;

public class CountDownLatchDemo {

	public static void main(String[] args) {

	}

}
