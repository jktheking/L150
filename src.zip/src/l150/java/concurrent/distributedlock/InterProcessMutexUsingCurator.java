package l150.java.concurrent.distributedlock;

import java.util.concurrent.TimeUnit;

public class InterProcessMutexUsingCurator {

	public static void main(String[] args) {
		// Create and start a CuratorFramework client
		CuratorFramework client = CuratorFrameworkFactory.builder().connectString("localhost:2181")
				.retryPolicy(new ExponentialBackoffRetry(1000, 3)).build();
		client.start();

		// Create a distributed lock at the specified path
		InterProcessMutex lock = new InterProcessMutex(client, "/my_lock");

		try {
			// Try to acquire the lock, waiting up to 30 seconds
			if (lock.acquire(30, TimeUnit.SECONDS)) {
				try {
					// Critical section: place your business logic here
					System.out.println("Lock acquired! Executing critical operation...");
					// Simulate some work with sleep
					Thread.sleep(5000);
				} finally {
					// Always release the lock in the finally block
					lock.release();
					System.out.println("Lock released.");
				}
			} else {
				System.out.println("Could not acquire lock within the specified time.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			client.close();
		}
	}
}
