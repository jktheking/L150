package l150.java.concurrent.distributedlock;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class ZKDistributedLock implements Lock, AutoCloseable {

	private final ZooKeeper zk;
	private final String lockBasePath;
	private final String lockName;
	// This will hold the full path of the ephemeral sequential node once created
	private String lockPath;
	// A local mutex for thread synchronization while waiting on ZooKeeper watch
	// events
	private final Object mutex = new Object();

	/**
	 * Constructs a distributed lock using ZooKeeper.
	 *
	 * @param zk           An established ZooKeeper client connection.
	 * @param lockBasePath The root path for all locks (e.g. "/locks").
	 * @param lockName     The name of the lock (all clients that want the same lock
	 *                     use the same name).
	 */
	public ZKDistributedLock(ZooKeeper zk, String lockBasePath, String lockName) {
		this.zk = zk;
		this.lockBasePath = lockBasePath;
		this.lockName = lockName;
	}

	/**
	 * Acquires the lock, blocking until it is available.
	 */
	@Override
	public void lock() {
		try {
			// Step 1: Create an ephemeral sequential node under the base path
			String path = lockBasePath + "/" + lockName + "_";
			lockPath = zk.create(path, new byte[0], ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);

			while (true) {
				// Step 2: Get all lock nodes under the base path and sort them
				List<String> children = zk.getChildren(lockBasePath, watchedEvent -> {
					// Notify waiting thread when a watched node is deleted
					if (watchedEvent.getType() == org.apache.zookeeper.Watcher.Event.EventType.NodeDeleted) {
						synchronized (mutex) {
							mutex.notifyAll();
						}
					}
				});
				Collections.sort(children);

				// Check if our node is the smallest
				if (lockPath.endsWith(children.get(0))) {
					// We have the lock
					return;
				} else {
					// Find the immediate predecessor and set a watch on it
					String predecessor = null;
					for (String child : children) {
						if (lockPath.endsWith(child)) {
							break;
						}
						predecessor = child;
					}
					if (predecessor != null) {
						// Watch the predecessor node
						String predecessorPath = lockBasePath + "/" + predecessor;
						if (zk.exists(predecessorPath, true) != null) {
							synchronized (mutex) {
								mutex.wait();
							}
						}
					}
				}
			}
		} catch (KeeperException | InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new RuntimeException("Failed to acquire ZooKeeper lock", e);
		}
	}

	/**
	 * Attempts to acquire the lock immediately without waiting.
	 *
	 * @return {@code true} if the lock was acquired, {@code false} otherwise.
	 */
	@Override
	public boolean tryLock() {
		try {
			return tryLock(0, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return false;
		}
	}

	/**
	 * Attempts to acquire the lock, waiting up to the specified time.
	 *
	 * @param timeout the maximum time to wait
	 * @param unit    the time unit of the timeout argument
	 * @return {@code true} if the lock was acquired, {@code false} otherwise.
	 * @throws InterruptedException if the current thread is interrupted
	 */
	@Override
	public boolean tryLock(long timeout, TimeUnit unit) throws InterruptedException {
		long waitMillis = unit.toMillis(timeout);
		long deadline = System.currentTimeMillis() + waitMillis;
		try {
			// Create lock node as in lock()
			String path = lockBasePath + "/" + lockName + "_";
			lockPath = zk.create(path, new byte[0], ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL_SEQUENTIAL);

			while (System.currentTimeMillis() < deadline) {
				List<String> children = zk.getChildren(lockBasePath, watchedEvent -> {
					if (watchedEvent.getType() == org.apache.zookeeper.Watcher.Event.EventType.NodeDeleted) {
						synchronized (mutex) {
							mutex.notifyAll();
						}
					}
				});
				Collections.sort(children);
				if (lockPath.endsWith(children.get(0))) {
					return true;
				} else {
					String predecessor = null;
					for (String child : children) {
						if (lockPath.endsWith(child)) {
							break;
						}
						predecessor = child;
					}
					if (predecessor != null) {
						String predecessorPath = lockBasePath + "/" + predecessor;
						if (zk.exists(predecessorPath, true) != null) {
							long remaining = deadline - System.currentTimeMillis();
							if (remaining <= 0) {
								break;
							}
							synchronized (mutex) {
								mutex.wait(remaining);
							}
						}
					}
				}
			}
		} catch (KeeperException e) {
			throw new RuntimeException("Error while trying to acquire ZooKeeper lock", e);
		}
		// Timeout reached; failed to acquire lock
		return false;
	}

	/**
	 * Releases the lock.
	 */
	@Override
	public void unlock() {
		try {
			if (lockPath != null) {
				zk.delete(lockPath, -1);
				lockPath = null;
			}
		} catch (KeeperException | InterruptedException e) {
			Thread.currentThread().interrupt();
			throw new RuntimeException("Failed to release ZooKeeper lock", e);
		}
	}

	/**
	 * Not supported.
	 */
	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException("newCondition is not supported by ZKDistributedLock");
	}

	/**
	 * Closes the ZooKeeper connection associated with this lock.
	 */
	@Override
	public void close() throws Exception {
		unlock();
		zk.close();
	}
}
