package asked.atlassian.lld;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAccumulator;
import java.util.concurrent.atomic.LongAdder;
import java.util.stream.Collectors;

/**
 * <pre>
 * File Hierarchy with Top K Collections
 * Problem Statement:
 * Design a system to manage a file hierarchy where each file belongs to a specific collection. 
 * The system should efficiently support:
 * - Adding files to the hierarchy.
 * - Updating file sizes.
 * - Retrieving the total size of any collection.
 * - Finding the top K collections by their total size.
 * 
 * 
 * Approach: Tree for Hierarchy + ConcurrentHashMap for Collection Sizes + Min-Heap for Top K
 * 
 * File Hierarchy: Represent the file system using a tree structure. 
 * A FileNode class can represent both directories and files. Directories would have children, 
 * and files would have a size and a collectionId.
 * 
 * Collection Sizes: A ConcurrentHashMap<String, LongAdder> to store the total size for each collectionId. 
 * LongAdder is used for thread-safe, high-throughput updates to counts.
 * 
 * Top K Collections: A PriorityQueue (min-heap) of size K will be used to maintain the top K collections.
 *  When a collection's size changes, we update its position in the heap.
 *  
 *  Production-Grade Considerations:
 *  
 *  Data Structures: Appropriate use of Map for hierarchy, ConcurrentHashMap and LongAdder for collection sizes, 
 *  and PriorityQueue for top K.
 *  
 *  Concurrency: ConcurrentHashMap and LongAdder ensure thread-safe updates to collection sizes.
 *  Efficiency: LongAdder for high-concurrency sum updates. PriorityQueue for O(log K) top K operations.
 *  Modularity: Clear separation of concerns between file hierarchy and collection management.
 *  Edge Cases: Handling empty collections, K=0, non-existent paths/collections, negative sizes.
 * 
 * </pre>
 * */




/**
 * Represents a node in the file hierarchy. Can be a directory or a file.
 */
 class FileNode {
    private final String name;
    private final boolean isDirectory;
    private long size; // Only relevant if isDirectory is false
    private String collectionId; // Only relevant if isDirectory is false
    private final Map<String, FileNode> children; // Only relevant if isDirectory is true

    // Constructor for a directory
    public FileNode(String name) {
        this.name = name;
        this.isDirectory = true;
        this.children = new ConcurrentHashMap<>(); // Concurrent for thread-safe access
        this.size = 0; // Directories don't have their own size in this model
    }

    // Constructor for a file
    public FileNode(String name, long size, String collectionId) {
        if (size < 0) {
            throw new IllegalArgumentException("File size cannot be negative.");
        }
        Objects.requireNonNull(collectionId, "Collection ID cannot be null for a file.");
        this.name = name;
        this.isDirectory = false;
        this.size = size;
        this.collectionId = collectionId;
        this.children = null; // Files don't have children
    }

    public String getName() {
    
        return name;
    }

    public boolean isDirectory() {
        return isDirectory;
    }

    public long getSize() {
        return size;
    }

    public String getCollectionId() {
        return collectionId;
    }

    public Map<String, FileNode> getChildren() {
        if (!isDirectory) {
            throw new UnsupportedOperationException("Files do not have children.");
        }
        return children;
    }

    // For internal use by FileHierarchyManager to update file size
    void setSize(long newSize) {
        if (isDirectory) {
            throw new UnsupportedOperationException("Cannot set size for a directory.");
        }
        if (newSize < 0) {
            throw new IllegalArgumentException("File size cannot be negative.");
        }
        this.size = newSize;
    }

    // For internal use by FileHierarchyManager to update collection ID
    void setCollectionId(String newCollectionId) {
        if (isDirectory) {
            throw new UnsupportedOperationException("Cannot set collection ID for a directory.");
        }
        Objects.requireNonNull(newCollectionId, "Collection ID cannot be null.");
        this.collectionId = newCollectionId;
    }
}

/**
 * Manages a file hierarchy and tracks collection sizes.
 * Provides thread-safe operations for adding/updating files and querying top K collections.
 */
public class FileHierarchyManager {

    private final FileNode root;
    // Stores collectionId -> totalSize (LongAdder for thread-safe, high-throughput sum updates)
    private final ConcurrentHashMap<String, LongAdder> collectionSizes;
    // Stores filePath -> FileNode (for quick lookup and updates)
    private final ConcurrentHashMap<String, FileNode> filePathToFileNodeMap;

    public FileHierarchyManager() {
        this.root = new FileNode("/"); // Root directory
        this.collectionSizes = new ConcurrentHashMap<>();
        
        this.filePathToFileNodeMap = new ConcurrentHashMap<>();
        filePathToFileNodeMap.put("/", root); // Add root to map
    }

    /**
     * Adds a file or directory to the hierarchy.
     *
     * @param path         The full path of the file/directory (e.g., "/docs/report.pdf").
     * @param isDirectory  True if it's a directory, false if a file.
     * @param size         Size of the file (ignored if isDirectory is true).
     * @param collectionId Collection ID for the file (ignored if isDirectory is true).
     */
    public boolean addNode(String path, boolean isDirectory, long size, String collectionId) {
        Objects.requireNonNull(path, "Path cannot be null.");
        
        if (!path.startsWith("/")) {
            throw new IllegalArgumentException("Path must start with '/'.");
        }
        if (path.equals("/")) { // Cannot re-add root
            return false;
        }
        if (!isDirectory && size < 0) {
            throw new IllegalArgumentException("File size cannot be negative.");
        }
        if (!isDirectory && collectionId == null) {
            throw new NullPointerException("Collection ID cannot be null for a file.");
        }

        String[] segments = path.substring(1).split("/");
        String parentPath = getParentPath(path);
        String nodeName = segments[segments.length - 1];

        FileNode parentNode = filePathToFileNodeMap.get(parentPath);
        if (parentNode == null ||!parentNode.isDirectory()) {
            System.err.println("Error: Parent directory does not exist or is not a directory: " + parentPath);
            return false;
        }

        // Check if node already exists
        if (parentNode.getChildren().containsKey(nodeName)) {
            System.err.println("Error: Node already exists at path: " + path);
            return false;
        }

        FileNode newNode;
        if (isDirectory) {
            newNode = new FileNode(nodeName);
        } else {
            newNode = new FileNode(nodeName, size, collectionId);
        }

        parentNode.getChildren().put(nodeName, newNode);
        filePathToFileNodeMap.put(path, newNode);

        if (!isDirectory) {
            // Update collection size for new file
            collectionSizes.computeIfAbsent(collectionId, k -> new LongAdder()).add(size);
        }
        return true;
    }

    /**
     * Updates the size of an existing file.
     *
     * @param filePath The full path of the file.
     * @param newSize  The new size of the file.
     * @return true if updated successfully, false if file not found or is a directory.
     * @throws IllegalArgumentException if newSize is negative.
     * @throws NullPointerException if filePath is null.
     */
    public boolean updateFileSize(String filePath, long newSize) {
        Objects.requireNonNull(filePath, "File path cannot be null.");
        if (newSize < 0) {
            throw new IllegalArgumentException("New file size cannot be negative.");
        }

        FileNode fileNode = filePathToFileNodeMap.get(filePath);

        if (fileNode == null || fileNode.isDirectory()) {
            System.err.println("Error: File not found or is a directory: " + filePath);
            return false;
        }

        long oldSize = fileNode.getSize();
        fileNode.setSize(newSize); // Update file node's size

        // Update collection size
        String collectionId = fileNode.getCollectionId();
        collectionSizes.computeIfAbsent(collectionId, k -> new LongAdder()).add(newSize - oldSize);
        return true;
    }

    /**
     * Retrieves the total size of a specific collection.
     *
     * @param collectionId The ID of the collection.
     * @return The total size of the collection, or 0 if the collection does not exist.
     * @throws NullPointerException if collectionId is null.
     */
    public long getCollectionTotalSize(String collectionId) {
        Objects.requireNonNull(collectionId, "Collection ID cannot be null.");
        LongAdder sizeAdder = collectionSizes.get(collectionId);
        return (sizeAdder!= null)? sizeAdder.sum() : 0;
    }

    /**
     * Returns the top K collections by their total size.
     *
     * @param k The number of top collections to retrieve.
     * @return A list of collection IDs, sorted by size (descending).
     */
    public List<String> getTopKCollections(int k) {
        if (k <= 0) {
            return List.of();
        }

        // Use a min-heap of size K to find the top K largest elements
        // The heap stores Map.Entry<CollectionId, Size>
        PriorityQueue<Map.Entry<String, Long>> minHeap = new PriorityQueue<>(
                Comparator.comparingLong(Map.Entry::getValue) // Min-heap based on size
        );

        for (Map.Entry<String, LongAdder> entry : collectionSizes.entrySet()) {
            String collectionId = entry.getKey();
            long totalSize = entry.getValue().sum(); // Get current sum

            if (minHeap.size() < k) {
                minHeap.offer(Map.entry(collectionId, totalSize));
            } else if (totalSize > minHeap.peek().getValue()) {
                minHeap.poll(); // Remove smallest
                minHeap.offer(Map.entry(collectionId, totalSize)); // Add current larger
            }
        }

        // Convert heap to list and sort in descending order for final result
        return minHeap.stream()
              .sorted(Comparator.comparingLong(Map.Entry::getValue).reversed() 
                      .thenComparing(Map.Entry::getKey)) 
              .map(Map.Entry::getKey)
              .collect(Collectors.toList());
    }

    private String getParentPath(String path) {
        int lastSlashIndex = path.lastIndexOf('/');
        if (lastSlashIndex == 0) { // Path is like "/file" or "/"
            return "/";
        }
        return path.substring(0, lastSlashIndex);
    }

    public static void main(String args) {
        FileHierarchyManager manager = new FileHierarchyManager();

        // Add directories
        manager.addNode("/documents", true, 0, null);
        manager.addNode("/images", true, 0, null);
        manager.addNode("/documents/reports", true, 0, null);

        // Add files
        manager.addNode("/documents/report.pdf", false, 100, "Finance");
        manager.addNode("/documents/reports/annual.docx", false, 200, "Finance");
        manager.addNode("/images/photo1.jpg", false, 150, "Marketing");
        manager.addNode("/images/photo2.png", false, 250, "Marketing");
        manager.addNode("/documents/memo.txt", false, 50, "HR");
        manager.addNode("/documents/budget.xlsx", false, 300, "Finance");

        System.out.println("--- Collection Sizes ---");
        System.out.println("Finance size: " + manager.getCollectionTotalSize("Finance"));   // Expected: 100 + 200 + 300 = 600
        System.out.println("Marketing size: " + manager.getCollectionTotalSize("Marketing")); // Expected: 150 + 250 = 400
        System.out.println("HR size: " + manager.getCollectionTotalSize("HR"));         // Expected: 50
        System.out.println("NonExistent size: " + manager.getCollectionTotalSize("NonExistent")); // Expected: 0

        System.out.println("\n--- Top K Collections ---");
        System.out.println("Top 2 collections: " + manager.getTopKCollections(2)); // Expected: [Finance, Marketing]
        System.out.println("Top 3 collections: " + manager.getTopKCollections(3)); // Expected: (order might vary for ties)
        System.out.println("Top 1 collection: " + manager.getTopKCollections(1));  // Expected: [Finance]
        System.out.println("Top 0 collections: " + manager.getTopKCollections(0));  // Expected:

        // Update file size
        System.out.println("\n--- Updating File Size ---");
        System.out.println("Updating /documents/report.pdf from 100 to 500...");
        manager.updateFileSize("/documents/report.pdf", 500); // Change from 100 to 500
        System.out.println("Finance size after update: " + manager.getCollectionTotalSize("Finance")); // Expected: 500 + 200 + 300 = 1000
        System.out.println("Top 2 collections after update: " + manager.getTopKCollections(2)); // Expected: [Finance, Marketing] (order might change if Marketing was higher)

        // Add another file to HR
        System.out.println("\n--- Adding another HR file ---");
        manager.addNode("/documents/hr_policy.docx", false, 150, "HR");
        System.out.println("HR size after new file: " + manager.getCollectionTotalSize("HR")); // Expected: 50 + 150 = 200
        System.out.println("Top 3 collections after HR update: " + manager.getTopKCollections(3)); // Expected: (order might depend on exact sizes)

        // Test invalid operations
        System.out.println("\n--- Invalid Operations ---");
        manager.addNode("/documents/report.pdf", false, 10, "Finance"); // Already exists
        manager.updateFileSize("/nonexistent.txt", 100); // File not found
        manager.updateFileSize("/documents", 100); // Is a directory
        manager.addNode("/nonexistent_parent/file.txt", false, 10, "Test"); // Parent not found
    }
}