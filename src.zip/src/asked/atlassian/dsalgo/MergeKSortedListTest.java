package asked.atlassian.dsalgo;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.TreeMap;

public class MergeKSortedListTest {

	public static void main(String[] args) {

	}

	private static class ListNode {

		private int val;
		private ListNode next;

		ListNode(int val, ListNode next) {
			super();
			this.val = val;
			this.next = next;
		}

		ListNode(int val) {
			super();
			this.val = val;
		}

	}
	
	private ListNode mergeKSortedListUsingTreeMap(ListNode[] list) {
		
		
		
		TreeMap<Integer, Deque<ListNode>> treeMap = new TreeMap<>();
		
		//seed the treeMap
		for(ListNode l : list) {
			treeMap.computeIfAbsent(l.val, k-> new ArrayDeque<>()).add(l);
		}
		
		
		ListNode dummyHead = new ListNode(0);
		ListNode tail = dummyHead;
		
		while(!treeMap.isEmpty()) {
			
			 Map.Entry<Integer,  Deque<ListNode>> entry = treeMap.firstEntry();
			 
			 
			 //if value  got exhausted remove from the tree
			 if(entry.getValue().isEmpty()) {
				 treeMap.remove(entry.getKey());
			 }
			 
			 ListNode  lnode =  entry.getValue().pollFirst();
			 
			 tail.next = lnode;
			 
			 if(lnode.next != null) {
				 treeMap.computeIfAbsent(lnode.val, ArrayDeque::new).offerLast(lnode.next);
			 }
			 
		}

		
		
		
		return dummyHead.next;
	}

}
