package asked.atlassian.dsalgo;

import java.util.ArrayDeque;
import java.util.Comparator;
import java.util.Deque;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * https://leetcode.com/problems/merge-k-sorted-lists/description/
 * 
 * 
 * Naive approach time-complexity: Let: k = number of lists N = total number of
 * nodes across all lists. Assume each list has roughly N/k nodes
 * 
 * Each merge takes O(m + n) time (where m and n are lengths of the lists being
 * merged).
 * 
 * Merge 1: N/k + N/k = 2N/k
 * 
 * Merge 2: 2N/k + N/k = 3N/k
 * 
 * Merge 3: 3N/k + N/k = 4N/k
 * 
 * ...
 * 
 * Merge (k - 1): (k)N/k = N
 * 
 * = (2N/k + 3N/k + ... + kN/k) = N/k * (2 + 3 + ... + k) = N/k * [ (k(k + 1)/2)
 * - 1 ] = N/k*[k^2] = O(Nk)
 * 
 * 
 * Time complexity of optimized approach is: N*logk
 */
public class MergeKSortedList {

	public static void main(String[] args) {

	}

	static class ListNode {
		int val;
		ListNode next;

		ListNode(int x) {
			val = x;
		}

		public int getVal() {
			return val;
		}

		public void setVal(int val) {
			this.val = val;
		}

		public ListNode getNext() {
			return next;
		}

		public void setNext(ListNode next) {
			this.next = next;
		}

	}

	public ListNode mergeKSortedLists(ListNode[] lists) {

		if (lists == null || lists.length == 0)
			return null;

		Queue<ListNode> pq = new PriorityQueue<>(lists.length, Comparator.comparingInt(ListNode::getVal));

		for (ListNode list : lists) {
			if (list != null) {
				pq.offer(list);
			}
		}

		// Think of the dummy node as a "starting peg" — you start attaching links to
		// it, but it's not part of the actual chain you care about. You throw it away
		// at the end. It is used for code simplicity, safety, and clarity. Like special
		// case for first node, null check etc
		ListNode dummyHead = new ListNode(0);
		ListNode tail = dummyHead;

		while (!pq.isEmpty()) {

			ListNode minNode = pq.poll();

			tail.setNext(minNode);
			tail = tail.getNext();

			if (minNode.getNext() != null) {
				pq.offer(minNode.getNext());
			}
		}

		return dummyHead.getNext();

	}

	/**
	 * 
	 * Duplicates not allowed in TreeSet/TreeMap by default – you'll need a custom
	 * comparator. By default TreeSet ignores the duplicate on add invocation.
	 * 
	 */
	public ListNode mergeKSortedListsUsingTreeSet(ListNode[] lists) {

		TreeSet<ListNode> set = new TreeSet<>((a, b) -> {
			if (a.val != b.val)
				return a.val - b.val;
			// for duplicate tie breaker we are using Object identityHashCode which is
			// unique for each object in JVM.
			return System.identityHashCode(a) - System.identityHashCode(b);
		});

		for (ListNode node : lists) {
			if (node != null) {
				set.add(node);
			}
		}

		ListNode dummyHead = new ListNode(0);
		ListNode tail = dummyHead;

		while (!set.isEmpty()) {
			ListNode smallest = set.pollFirst();
			tail.next = smallest;
			tail = tail.next;

			if (smallest.next != null) {
				set.add(smallest.next);
			}
		}

		return dummyHead.next;
	}

	// for Handling Duplicates we can use Value part of tree map
	public ListNode mergeKSortedListsUsingTreeMap(ListNode[] lists) {

		if (lists == null || lists.length == 0) {
			return null;
		}

		// key : node value
		// value: queue of nodes having this value (handles duplicates)
		TreeMap<Integer, Deque<ListNode>> map = new TreeMap<>();

		/* 1. Seed the TreeMap with the head node of every list. */
		for (ListNode node : lists) {
			if (node != null) {
				map.computeIfAbsent(node.val, k -> new ArrayDeque<>()).addLast(node);
			}
		}

		/* 2. Standard merge loop. */
		ListNode dummyHead = new ListNode(0);
		ListNode tail = dummyHead;

		while (!map.isEmpty()) {
			// Always extract the smallest available value
			Map.Entry<Integer, Deque<ListNode>> entry = map.firstEntry();

			Deque<ListNode> elements = entry.getValue();
			// Clean up elements if empty
			if (elements.isEmpty()) {
				map.remove(entry.getKey());
			}

			ListNode node = elements.pollFirst(); // remove one node

			/* Append the smallest node to the result list. */
			tail.next = node;
			tail = tail.next;

			/* Push the next node from this list (if any) back into the map. */
			if (node.next != null) {
				map.computeIfAbsent(node.next.val, k -> new ArrayDeque<>()).addLast(node.next);
			}
		}

		return dummyHead.next;

	}

	// Time complexity: Nlogk
	// Space complexity: O(log k) : which is the height of the recursion tree, as
	// recursion follows Euler tour and we just need to store elements as per tree
	// height on stack.
	public ListNode mergeSortedKListsRecursive(ListNode[] lists) {
		if (lists == null || lists.length == 0)
			return null;
		return partitionAndMergeRecursive(lists, 0, lists.length - 1);
	}

	private ListNode partitionAndMergeRecursive(ListNode[] lists, int left, int right) {
		if (left == right) {
			return lists[left];
		}
		int mid = left + (right - left) / 2;
		// partition stage, here at each leaf-node left becomes equal to right like
		// [0,0][1,1][2,2].
		// now post return of two branches, which represent return of partition stage;
		// merge need to be performed
		ListNode l1 = partitionAndMergeRecursive(lists, left, mid);
		ListNode l2 = partitionAndMergeRecursive(lists, mid + 1, right);

		// this location of recursive method represents post partition
		return mergeTwoLists(l1, l2);
	}

	private ListNode mergeTwoLists(ListNode l1, ListNode l2) {
		
		//base condition represent left-over situation that also comes in iterative approach.
		if (l1 == null)
			return l2;
		if (l2 == null)
			return l1;

		if (l1.val < l2.val) {
			l1.next = mergeTwoLists(l1.next, l2);
			return l1;
		} else {
			l2.next = mergeTwoLists(l1, l2.next);
			return l2;
		}
	}

	/**
	 * Start by merging lists in pairs.
	 * 
	 * After one full pass, number of lists becomes roughly k/2.
	 * 
	 * Repeat the process until only one list is left.
	 * 
	 * Time Complexity: N*logk Space complexity: O(1)
	 * 
	 */

	public ListNode mergeKListsPairWise(ListNode[] lists) {
		if (lists == null || lists.length == 0)
			return null;

		// this is interval doubling approach
		int interval = 1;
		int n = lists.length;
		while (interval < n) {
			for (int i = 0; i + interval < n; i += interval * 2) {
				lists[i] = mergeTwoListsIteratively(lists[i], lists[i + interval]);
			}
			interval *= 2;
		}

		return lists[0];
	}

	private ListNode mergeTwoListsIteratively(ListNode l1, ListNode l2) {

		ListNode dummyHead = new ListNode(0);
		ListNode tail = dummyHead;

		while (l1 != null && l2 != null) {

			if (l1.val < l2.val) {
				tail.next = l1;
				l1 = l1.next;
			} else {
				tail.next = l2;
				l2 = l2.next;
			}

			tail = tail.next;
		}

		// for left-overs
		if (l1 != null)
			tail.next = l1;
		else
			tail.next = l2;

		return dummyHead.next;
	}

	/**
	 * Two Iterative Styles for Divide-and-Conquer
	 * 
	 */

	private void divideAndConquerIntervalDoublingApproach(ListNode[] lists) {
		int n = lists.length;
		int interval = 1;
		while (interval < n) {
			for (int i = 0; i + interval < n; i += interval * 2) {
				lists[i] = mergeTwoLists(lists[i], lists[i + interval]);
			}
			interval *= 2;
		}

	}

	/**
	 * 
	 * Two-Pointer (start + end) Approach
	 */
	private void divideAndConquerTwoPointerApproach(ListNode[] lists) {
		
		int last = lists.length - 1;
		
		while (last > 0) {
			
			int i = 0, j = last;

			while (i < j) {
				lists[i] = mergeTwoLists(lists[i], lists[j]);
				i++;
				j--;

				if (i >= j) {
					last = j;
				}

			}
		}
	}

}
