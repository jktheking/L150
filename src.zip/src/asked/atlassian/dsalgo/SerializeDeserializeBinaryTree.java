package asked.atlassian.dsalgo;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;

/**
 * 
 * </pre>
 * Leetcode 297
 * 
 * https://leetcode.com/problems/serialize-and-deserialize-binary-tree/description/
 * 
 * CASE1 DFS: Without null marker
 * 
 * We need two traversal to deserialize the tree deterministically.
 * 
 * 1. pre-order + in-order : uniquely identifiable 2. post-order + in-order :
 * uniquely identifiable
 * 
 * 
 * CASE2 DFS: With null marker
 * 
 * 1. Preorder and Postorder are structure-aware as they alone define which node
 * is root, and in what order the nodes are constructed.
 * 
 * --pre-order + null-marker : uniquely identifiable --post-order + null-marker
 * : uniquely identifiable
 * 
 * 
 * 2. in-order is structure-ambiguous, even with nulls as we cannot be sure
 * about root.
 * 
 * so, in-order + null-marker tree is not uniquely identifiable.
 * 
 * 
 * CASE3 BFS:
 * 
 * - BFS with null-marker: uniquely identifiable - BFS without null-marker :
 * ambiguous - BFS without null-marker + in-oder : uniquely identifiable
 * 
 * </pre>
 * 
 */
public class SerializeDeserializeBinaryTree {

	public static void main(String[] args) {

	}

	static class TreeNode {

		int val;
		TreeNode left;
		TreeNode right;

		TreeNode(int x) {
			val = x;
		}
	}

	public String serialize(TreeNode root) {
		StringBuilder sb = new StringBuilder();
		serializeHelper(root, sb);
		return sb.toString();
	}

	private void serializeHelper(TreeNode root, StringBuilder sb) {
		if (root == null) {
			sb.append("#,");
			return;
		}
		sb.append(root.val).append(",");
		serializeHelper(root.left, sb);
		serializeHelper(root.right, sb);
	}

	// Deserialize from preorder using a queue
	public TreeNode deserialize(String data) {
		Queue<String> nodes = new LinkedList<>(Arrays.asList(data.split(",")));
		return deserializeHelper(nodes);
	}

	private TreeNode deserializeHelper(Queue<String> nodes) {
		String val = nodes.poll();
		if (val.equals("#"))
			return null;

		TreeNode root = new TreeNode(Integer.valueOf(val));
		root.left = deserializeHelper(nodes);
		root.right = deserializeHelper(nodes);
		return root;
	}
}
