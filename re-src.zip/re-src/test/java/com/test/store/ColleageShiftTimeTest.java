package com.test.store;

package com.test.store;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class ShiftMergeServiceImplTest {

	private ShiftMergeService shiftMergeService;

	@BeforeEach
	void setUp() {
		shiftMergeService = new ShiftMergeServiceImpl();
	}

	@Test
	void givenNonOverlappingShifts_whenMerged_thenReturnsSameShifts() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(14, 16));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 10), new ShiftTime(14, 16)), result);
	}

	@Test
	void givenOverlappingShifts_whenMerged_thenReturnsMergedShifts() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(9, 12));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}

	@Test
	void givenContiguousShifts_whenMerged_thenReturnsSingleShift() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 10), new ShiftTime(10, 12));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}

	@Test
	void givenShiftsAcrossMidnight_whenMerged_thenHandlesCorrectly() {
		List<ShiftTime> shifts = List.of(new ShiftTime(22, 2), new ShiftTime(1, 3));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(22, 3)), result);
	}

	@Test
	void givenShiftsAcrossMidnightNonContiguous_whenMerged_thenSeparates() {
		List<ShiftTime> shifts = List.of(new ShiftTime(22, 2), new ShiftTime(4, 6));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(22, 2), new ShiftTime(4, 6)), result);
	}

	@Test
	void givenFullyContainedShifts_whenMerged_thenIgnoresInnerShift() {
		List<ShiftTime> shifts = List.of(new ShiftTime(8, 12), new ShiftTime(9, 11));
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertEquals(List.of(new ShiftTime(8, 12)), result);
	}

	@Test
	void givenEmptyShifts_whenMerged_thenReturnsEmptyList() {
		List<ShiftTime> shifts = List.of();
		List<ShiftTime> result = shiftMergeService.merge(shifts);
		assertTrue(result.isEmpty());
	}
}
