package com.test.re;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.EnumMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.test.re.core.impl.CategoryRuleConfigGateway;
import com.test.re.entity.Category;

@ExtendWith(MockitoExtension.class)
class CategoryRuleConfigGatewayTest {

	private CategoryRuleConfigGateway categoryRuleConfigGateway;

	@BeforeEach
	void setUp() {
		Map<Category, Integer> config = new EnumMap<>(Category.class);
		config.put(Category.CHOCOLATE, 10);
		categoryRuleConfigGateway = new CategoryRuleConfigGateway(config, 5);
	}

	@Test
	void givenExistingCategory_whenGetConfiguredValue_thenReturnConfiguredValue() {
		assertEquals(10, categoryRuleConfigGateway.getConfiguredValue(Category.CHOCOLATE));
	}

	@Test
	void givenNonExistingCategory_whenGetConfiguredValue_thenReturnDefaultValue() {
		assertEquals(5, categoryRuleConfigGateway.getConfiguredValue(Category.PARACETAMOL));
	}
}
