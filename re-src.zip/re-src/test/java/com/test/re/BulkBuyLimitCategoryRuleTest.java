package com.test.re;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.test.re.core.RuleConfigGateway;
import com.test.re.core.impl.BulkBuyLimitCategoryRule;
import com.test.re.entity.Category;
import com.test.re.entity.Item;

@ExtendWith(MockitoExtension.class)
class BulkBuyLimitCategoryRuleTest {

	@Mock
	private RuleConfigGateway<Category, Integer> configGateway;

	@InjectMocks
	private BulkBuyLimitCategoryRule bulkBuyLimitCategoryRule;

	@Test
    void givenValidItems_whenEvaluate_thenReturnTrue() {
        when(configGateway.getConfiguredValue(Category.CHOCOLATE)).thenReturn(10);

        List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 3), new Item(2, Category.CHOCOLATE, 6));

        assertTrue(bulkBuyLimitCategoryRule.evaluate(items, Category.CHOCOLATE));
    }

	@Test
    void givenInvalidItems_whenEvaluate_thenReturnFalse() {
        when(configGateway.getConfiguredValue(Category.CHOCOLATE)).thenReturn(10);

        List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 5), new Item(2, Category.CHOCOLATE, 6));

        assertFalse(bulkBuyLimitCategoryRule.evaluate(items, Category.CHOCOLATE));
    }
}
