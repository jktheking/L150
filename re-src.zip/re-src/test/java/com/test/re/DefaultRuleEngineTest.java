package com.test.re;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.test.re.core.RestrictionAttribute;
import com.test.re.core.Rule;
import com.test.re.core.RuleEngine;
import com.test.re.core.impl.DefaultRuleEngine;
import com.test.re.entity.Category;
import com.test.re.entity.Item;
import com.test.re.entity.Order;

@ExtendWith(MockitoExtension.class)
class DefaultRuleEngineTest {

	@Mock
	private Rule<RestrictionAttribute> rule;

	@InjectMocks
	private DefaultRuleEngine ruleEngine;

	@BeforeEach
	void setUp() {
		ruleEngine = new DefaultRuleEngine(Map.of(Category.CHOCOLATE, List.of(rule)));
	}

	@Test
	void givenValidOrder_whenEvaluate_thenReturnMet() {
		List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 3), new Item(2, Category.CHOCOLATE, 6));
		Order order = new Order(items);

		when(rule.evaluate(anyList(), any(RestrictionAttribute.class))).thenReturn(true);

		assertEquals(RuleEngine.Status.MET, ruleEngine.evaluate(order));
	}

	@Test
	void givenInvalidOrder_whenEvaluate_thenReturnBreached() {
		List<Item> items = List.of(new Item(1, Category.CHOCOLATE, 3), new Item(2, Category.CHOCOLATE, 6));
		Order order = new Order(items);

		when(rule.evaluate(anyList(), any(RestrictionAttribute.class))).thenReturn(false);

		assertEquals(RuleEngine.Status.BREACHED, ruleEngine.evaluate(order));
	}
}
