package com.test.container;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.TreeMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.test.container.entity.Container;
import com.test.container.entity.ContainerOptimizer;
import com.test.container.entity.ContainerRepository;
import com.test.container.entity.ContainerServiceException;
import com.test.container.entity.ContainerServiceImpl;
import com.test.container.entity.Order;
import com.test.container.entity.Product;

/**
 * Tesco has a fleet of vehicles to deliver orders to the customer. Assigning
 * the right set of orders to different sized vehicles is crucial for efficient
 * delivery of orders. Different vehicle can fit different container sizes.
 *
 * Given c containers, along with their volumes [l,b,h], catalogue of product
 * with its volume requirement (l,b,h) and an order with p products and its
 * quantity.
 *
 * Example:
 *
 * Containers:
 *
 * SMALL -> id=1, length=10, breadth=20, height=30
 *
 * MEDIUM -> id=2, length=50, breadth=60, height=70
 *
 * LARGE -> id=3, length=100, breadth=200, height=300
 *
 * Product:
 *
 * productId=1, length=2, breadth=4, height=10
 *
 * productId=2, length=10, breadth=30, height=4
 *
 * productId=3, length=5, breadth=6, height=7
 *
 * Order:
 *
 * productId=1, quantity=3
 *
 * productId=3, quantity=7
 *
 * Determine if that order fits in any of the given c containers and return the
 * ID of the container that can be used. Given n orders, determine the maximum
 * number of orders that can be fit into a particular container.
 */

@ExtendWith(MockitoExtension.class)
public class ContainerServiceImplTest {

	@Mock
	private ContainerRepository containerRepository;

	@Mock
	private ContainerOptimizer containerOptimizer;

	@InjectMocks
	private ContainerServiceImpl containerService;

	@BeforeEach
	public void setUp() {

	}

	@Test
	public void givenOrder_whenResolveSuitableContainer_thenReturnContainerId() {
		// Arrange
		Product product = new Product("prod1", 2, 4, 10);
		Order order = new Order();
		order.addItem(product, 1);

		Container container = new Container("cont1", 10, 20, 30);
		TreeMap<Integer, Container> containers = new TreeMap<>();
		containers.put(container.getVolume(), container);

		when(containerRepository.getAvaiableContainers()).thenReturn(containers);
		when(containerOptimizer.canFitOrderInContainer(containers, order)).thenReturn(Optional.of(container));

		// Act
		String containerId = containerService.resolveSuitableContainer(order);

		// Assert
		assertEquals("cont1", containerId);
	}

	@Test
	public void givenOrder_whenResolveSuitableContainer_thenThrowExceptionIfNoContainerFound() {
		// Arrange
		Product product = new Product("prod1", 2, 4, 10);
		Order order = new Order();
		order.addItem(product, 1);

		TreeMap<Integer, Container> containers = new TreeMap<>();

		when(containerRepository.getAvaiableContainers()).thenReturn(containers);
		when(containerOptimizer.canFitOrderInContainer(containers, order)).thenReturn(Optional.empty());

		// Act & Assert
		assertThrows(ContainerServiceException.class, () -> containerService.resolveSuitableContainer(order));
	}

}
