package com.test.container;

import java.util.List;

import com.test.container.entity.Container;
import com.test.container.entity.Order;

public interface ContainerService {

	String resolveSuitableContainer(Order order);

	int computeMaxFillableOrders(List<Order> orders, Container container);

}
