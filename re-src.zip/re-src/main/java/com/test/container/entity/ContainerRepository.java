package com.test.container.entity;

import java.util.TreeMap;

public class ContainerRepository {

	public TreeMap<Integer, Container> getAvaiableContainers() {
		// TODO Auto-generated method stub
		return null;
	}

}
