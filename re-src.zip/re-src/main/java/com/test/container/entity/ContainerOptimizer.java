package com.test.container.entity;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

public class ContainerOptimizer {

	public Optional<Container> canFitOrderInContainer(TreeMap<Integer, Container> sortedOnVolumeContainers,
			Order order) {

//		int orderVolume = order.getItems().stream().mapToInt(item -> {
//			return item.getProduct().getVolume() * item.getQuantity();
//		}).sum();

		int orderVolume = order.getVolume();

		Map.Entry<Integer, Container> celiEntry = sortedOnVolumeContainers.ceilingEntry(orderVolume);

		return Optional.ofNullable(celiEntry).map(c -> c.getValue());

	}

	public int computeMaxFillableOrders(List<Order> orders, Container container) {

		Collections.sort(orders, Comparator.comparing(Order::getVolume));

		int orderVolumeSum = 0;
		int count = 0;
		for (Order order : orders) {
			if (orderVolumeSum >= container.getVolume()) {
				break;
			}
			orderVolumeSum = orderVolumeSum + order.getVolume();
			count++;

		}
		return count;

	}

}
