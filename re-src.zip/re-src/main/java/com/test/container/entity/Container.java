package com.test.container.entity;

public class Container {
	private final String id;
	private final int length;
	private final int breadth;
	private final int height;
	private final int volume;

	public Container(String id, int length, int breadth, int height) {
		this.id = id;
		this.length = length;
		this.breadth = breadth;
		this.height = height;
		this.volume = length * breadth * height;
	}

	public int getVolume() {
		return volume;
	}

	public String getId() {
		return id;
	}

	public int getLength() {
		return length;
	}

	public int getBreadth() {
		return breadth;
	}

	public int getHeight() {
		return height;
	}
}