package com.test.container.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Order {

	private final List<OrderItem> items;

	private int volume;

	public Order() {
		items = new ArrayList<>();
	}

	public List<OrderItem> getItems() {
		return Collections.unmodifiableList(items);
	}

	public void addItem(Product product, int quantity) {
		items.add(new OrderItem(product, quantity));
		volume += product.getVolume() * quantity;
	}

	public int getVolume() {
		return volume;
	}

}
