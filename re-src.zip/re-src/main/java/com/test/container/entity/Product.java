package com.test.container.entity;

public class Product {
	private String productId;
	private int length;
	private int breadth;
	private int height;
	private int volume;

	public Product(String productId, int length, int breadth, int height) {
		this.productId = productId;
		this.length = length;
		this.breadth = breadth;
		this.height = height;
		this.volume = length * breadth * height;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}
}
