package com.test.container.entity;

import java.util.List;
import java.util.Optional;
import java.util.TreeMap;

import com.test.container.ContainerService;

public class ContainerServiceImpl implements ContainerService {

	private ContainerRepository containerRepository;
	private ContainerOptimizer containerOptimizer;

	@Override
	public String resolveSuitableContainer(Order order) {
		TreeMap<Integer, Container> sortedOnVolumeContainers = containerRepository.getAvaiableContainers();
		Optional<Container> container = containerOptimizer.canFitOrderInContainer(sortedOnVolumeContainers, order);
		return container.map(Container::getId).orElseThrow(() -> {
			return new ContainerServiceException("no matching container found!");
		});
	}

	@Override
	public int computeMaxFillableOrders(List<Order> orders, Container container) {
		containerOptimizer.computeMaxFillableOrders(orders, container);
		return 0;
	}

}
