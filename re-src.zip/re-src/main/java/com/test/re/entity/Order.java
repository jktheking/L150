package com.test.re.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.test.re.core.RestrictionAttribute;

public class Order {

	/*
	 * Will extract all the restriction attribute from the order's items and group
	 * the items restriction attribute-wise
	 *
	 */
	private final Map<RestrictionAttribute, List<Item>> restrictionAttributeMap;

	public Order(List<Item> items) {
		this.restrictionAttributeMap = prepareRestrictionAttributeMap(items);
	}

	private Map<RestrictionAttribute, List<Item>> prepareRestrictionAttributeMap(final List<Item> items) {

		Map<Category, List<Item>> categoryItemMap = new EnumMap<>(Category.class);

		for (Item item : items) {
			extractCategoryRestrictionAttribute(categoryItemMap, item);
		}

		return Collections.unmodifiableMap(categoryItemMap);

	}

	public List<Item> getItems(RestrictionAttribute attribute) {
		return restrictionAttributeMap.get(attribute);
	}

	public Map<RestrictionAttribute, List<Item>> getRestrictionAttributeMap() {
		return restrictionAttributeMap;
	}

	private void extractCategoryRestrictionAttribute(Map<Category, List<Item>> categoryItemMap, Item item) {
		List<Item> itemList = categoryItemMap.getOrDefault(item.getCategory(), new ArrayList<>());
		itemList.add(item);
		categoryItemMap.put(item.getCategory(), itemList);
	}

}
