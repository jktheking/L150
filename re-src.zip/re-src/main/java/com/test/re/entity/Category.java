package com.test.re.entity;

import com.test.re.core.RestrictionAttribute;

public enum Category implements RestrictionAttribute {

	CHOCOLATE,

	PARACETAMOL,

	ANALGESIC,

	;

}
