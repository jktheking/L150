package com.test.re.entity;

public class Item {

	private int productId;
	private Category category;
	private int quantity;

	public Item(int productId, Category category, int quantity) {
		this.productId = productId;
		this.category = category;
		this.quantity = quantity;
	}

	public int getProductId() {
		return productId;
	}

	public Category getCategory() {
		return category;
	}

	public int getQuantity() {
		return quantity;
	}

}
