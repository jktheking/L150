package com.test.re.core;

import com.test.re.entity.Order;

public interface RuleEngine {

	enum Status {
		MET, BREACHED;
	}

	Status evaluate(Order order);

}
