package com.test.re.core.impl;

import java.util.List;

import com.test.re.core.Rule;
import com.test.re.core.RuleConfigGateway;
import com.test.re.entity.Category;
import com.test.re.entity.Item;

public class BulkBuyLimitCategoryRule implements Rule<Category> {

	private final RuleConfigGateway<Category, Integer> configGateway;

	public BulkBuyLimitCategoryRule(final RuleConfigGateway<Category, Integer> configGateway) {
		this.configGateway = configGateway;
	}

	@Override
	public boolean evaluate(List<Item> items, Category attribute) {
		return items.stream().mapToInt(Item::getQuantity).sum() <= configGateway.getConfiguredValue(attribute);
	}

}
