package com.test.re.core;

public interface RestrictionAttribute {

}
