package com.test.re.core.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.test.re.core.RestrictionAttribute;
import com.test.re.core.Rule;
import com.test.re.core.RuleEngine;
import com.test.re.entity.Item;
import com.test.re.entity.Order;

public class DefaultRuleEngine implements RuleEngine {

	private static final Logger logger = LoggerFactory.getLogger(DefaultRuleEngine.class);

	private Map<RestrictionAttribute, List<Rule<RestrictionAttribute>>> ruleResolverMap;

	public DefaultRuleEngine(Map<RestrictionAttribute, List<Rule<RestrictionAttribute>>> rules) {
		this.ruleResolverMap = rules;
	}

	@Override
	public Status evaluate(Order order) {

		Map<RestrictionAttribute, List<Item>> restrictionWiseOrder = order.getRestrictionAttributeMap();

		for (Map.Entry<RestrictionAttribute, List<Item>> restrictionWiseItems : restrictionWiseOrder.entrySet()) {

			RestrictionAttribute restrictionAttributeRuntime = restrictionWiseItems.getKey();
			List<Item> itemsRuntime = restrictionWiseItems.getValue();

			for (Rule<RestrictionAttribute> rule : resolveRules(restrictionAttributeRuntime)) {

				if (!rule.evaluate(itemsRuntime, restrictionAttributeRuntime)) {
					return Status.BREACHED;
				}
			}

		}
		return Status.MET;
	}

	public List<Rule<RestrictionAttribute>> resolveRules(RestrictionAttribute resAttribute) {
		return ruleResolverMap.getOrDefault(resAttribute, List.of());
	}
}
