package com.test.re.core.impl;

import java.util.Map;

import com.test.re.core.RuleConfigGateway;
import com.test.re.entity.Category;

public class CategoryRuleConfigGateway implements RuleConfigGateway<Category, Integer> {

	private final int defaultt;

	private final Map<Category, Integer> config;

	public CategoryRuleConfigGateway(final Map<Category, Integer> config, int defaultt) {
		this.config = config;
		this.defaultt = defaultt;
	}

	@Override
	public Integer getConfiguredValue(Category attribute) {
		return config.getOrDefault(attribute, defaultt);
	}

}
