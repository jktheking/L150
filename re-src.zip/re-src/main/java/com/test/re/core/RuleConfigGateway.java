package com.test.re.core;

public interface RuleConfigGateway<A extends RestrictionAttribute, R> {

	R getConfiguredValue(A attribute);

}
