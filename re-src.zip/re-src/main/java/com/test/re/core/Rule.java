package com.test.re.core;

import java.util.List;

import com.test.re.entity.Item;

@FunctionalInterface
public interface Rule<T extends RestrictionAttribute> {

	boolean evaluate(List<Item> items, T attribute);

}
