package com.test.store;

import java.util.List;

public interface ColleagueShiftTimeService {

	List<ShiftTime> fetchColleagueShifts(String empId, String storeId);

}
