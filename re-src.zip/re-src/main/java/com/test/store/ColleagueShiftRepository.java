package com.test.store;

import java.util.List;

public interface ColleagueShiftRepository {

	List<ShiftTime> getStoreShits(String empId, String storeId);

}
