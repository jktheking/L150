package com.test.store;

import java.util.List;

public interface ShiftMergeService {

	List<ShiftTime> merge(List<ShiftTime> shifts);

}
