package com.test.store;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ShiftMergeServiceImpl implements ShiftMergeService {

	public static void main(String[] args) {

	}

	// Helper inner class representing a normalized time interval.
	private static class Interval {
		int start;
		int end;

		Interval(int start, int end) {
			this.start = start;
			this.end = end;
		}
	}

	@Override
	public List<ShiftTime> merge(List<ShiftTime> shifts) {
		if (shifts == null || shifts.isEmpty()) {
			return List.of();
		}

		// Normalize shifts: if a shift "overflows" midnight, add 24 to its end.
		List<Interval> intervals = shifts.stream().map(shift -> {
			int start = shift.getStart();
			int end = shift.getEnd();
			// Shift spans midnight: e.g. 22 to 2 becomes 22 to (2+24)=26.
			if (start > end) {
				return new Interval(start, end + 24);
			} else {
				// Regular shift
				return new Interval(start, end);
			}
		}).sorted(Comparator.comparingInt(interval -> interval.start)).toList();

		// Merge overlapping or contiguous intervals.
		List<Interval> mergedIntervals = new ArrayList<>();

		Interval referenceInterval = intervals.get(0);
		mergedIntervals.add(referenceInterval);

		for (int i = 1; i < intervals.size(); i++) {
			Interval currentInterval = intervals.get(i);

			// Overlapping or touching intervals.
			if (currentInterval.start <= referenceInterval.end) {
				referenceInterval.end = Math.max(referenceInterval.end, currentInterval.end);
			} else {
				mergedIntervals.add(currentInterval);
				// now currentInterval will act as new referenceInterval
				referenceInterval = currentInterval;
			}
		}

		return mergedIntervals.stream().map(interval -> new ShiftTime(interval.start, interval.end % 24)).toList();

	}
}
