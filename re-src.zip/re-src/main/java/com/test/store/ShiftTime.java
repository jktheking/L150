package com.test.store;

public class ShiftTime {
	private final int start;
	private final int end;

	public ShiftTime(int start, int end) {
		// Validate that both times are between 0 and 23 (inclusive).
		if (start < 0 || start >= 24 || end < 0 || end >= 24) {
			throw new IllegalArgumentException("Shift times must be between 0 and 23 inclusive.");
		}
		this.start = start;
		this.end = end;
	}

	public static ShiftTime of(ShiftTime shiftTime) {
		return new ShiftTime(shiftTime.start, shiftTime.end);
	}

	public int getStart() {
		return start;
	}

	public int getEnd() {
		return end;
	}

	@Override
	public String toString() {
		return String.format("ShiftTime [start=%s, end=%s]", start, end);
	}

}
