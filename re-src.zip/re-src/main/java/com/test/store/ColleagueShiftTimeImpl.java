package com.test.store;

import java.util.List;

public class ColleagueShiftTimeImpl implements ColleagueShiftTimeService {

	private ColleagueShiftRepository colleagueShiftRepository;
	private ShiftMergeService shiftMergeService;

	@Override
	public List<ShiftTime> fetchColleagueShifts(String empId, String storeId) {

		List<ShiftTime> shifts = colleagueShiftRepository.getStoreShits(empId, storeId);

		return shiftMergeService.merge(shifts);

	}

}
